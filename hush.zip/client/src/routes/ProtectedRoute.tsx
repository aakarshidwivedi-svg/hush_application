import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { ErrorMessage, PageLoader } from '../components/ui/States';
import { useAuth } from '../hooks/useAuth';

/**
 * UX guard only. Every private API call is authorised again on the server,
 * so these redirects are conveniences, never security controls.
 */
export function ProtectedRoute({ allow = 'ready', allowIncomplete = false }: { allow?: 'ready' | 'onboarding'; allowIncomplete?: boolean }) {
  const { status, me, refresh, error } = useAuth();
  const loc = useLocation();

  if (status === 'loading') return <PageLoader />;
  if (status === 'error') {
    return (
      <div className="page py-16">
        <ErrorMessage message={error ?? 'Something went wrong'} onRetry={() => void refresh()} />
      </div>
    );
  }
  if (status === 'anonymous') return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  // The onboarding page decides for itself when it is finished (it shows a final preview step even
  // after the profile becomes complete), so signed-in people are always let in.
  if (allow === 'onboarding') return <Outlet />;
  if (status === 'needs-onboarding') return <Navigate to="/onboarding" replace />;
  // A profile needs a photo and enough interests before browsing, matching or chatting.
  if (!allowIncomplete && me && !me.profile.complete) return <Navigate to="/onboarding" replace />;
  return <Outlet />;
}

/** Login/signup pages bounce signed-in users onward. */
export function PublicOnlyRoute() {
  const { status } = useAuth();
  if (status === 'loading') return <PageLoader />;
  if (status === 'ready') return <Navigate to="/discover" replace />;
  if (status === 'needs-onboarding') return <Navigate to="/onboarding" replace />;
  return <Outlet />;
}
