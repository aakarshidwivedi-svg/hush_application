import { Navigate, Outlet } from 'react-router-dom';
import { PageLoader } from './ui/States';
import { useAuth } from '../hooks/useAuth';
import { useModerator } from '../hooks/useModerator';

/** UX guard only; the API enforces moderator access on every request. */
export function ModeratorRoute() {
  const { status } = useAuth();
  const isMod = useModerator();
  if (status === 'loading' || (status !== 'anonymous' && isMod === null)) return <PageLoader />;
  if (status === 'anonymous') return <Navigate to="/login" replace state={{ from: '/moderation' }} />;
  if (!isMod) return <Navigate to="/discover" replace />;
  return <Outlet />;
}
