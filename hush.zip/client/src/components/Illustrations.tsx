import type { SVGProps } from 'react';

type P = SVGProps<SVGSVGElement>;

export function Heart({ className = '', ...p }: P) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" focusable="false" {...p}>
      <path fill="currentColor" d="M12 21.2c-.3 0-.6-.1-.8-.3C6.6 17 2 13 2 8.7 2 6 4 4 6.6 4c1.9 0 3.8 1 5.4 3 1.6-2 3.5-3 5.4-3C20 4 22 6 22 8.7c0 4.3-4.600 8.300-9.200 12.200-.2.2-.5.300-.8.300Z" />
    </svg>
  );
}

export function Star({ className = '', ...p }: P) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" focusable="false" {...p}>
      <path fill="currentColor" d="m12 2.500 2.900 6 6.600.9-4.800 4.600 1.200 6.500L12 17.400 6.100 20.500l1.200-6.500L2.500 9.400l6.600-.9L12 2.500Z" strokeLinejoin="round" />
    </svg>
  );
}

export function Sparkle({ className = '', ...p }: P) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden="true" focusable="false" {...p}>
      <path fill="currentColor" d="M12 1c.6 5.800 2.200 9.600 11 11-8.800 1.400-10.400 5.200-11 11-.6-5.800-2.200-9.600-11-11C9.800 10.600 11.400 6.800 12 1Z" />
    </svg>
  );
}

/** Logo mark: a heart inside a speech-bubble that is "shushing". */
export function Logo({ className = '' }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 font-display text-2xl font-bold text-plum ${className}`}>
      <span className="grid h-9 w-9 place-items-center rounded-2xl bg-gradient-to-br from-bubblegum to-lavender shadow-soft">
        <Heart className="h-5 w-5 text-white" />
      </span>
      Hush
    </span>
  );
}

/** Decorative floating hearts and stars for hero backgrounds. */
export function FloatingDecor() {
  return (
    <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden" aria-hidden="true">
      <div className="absolute -left-20 -top-24 h-72 w-72 rounded-full bg-bubblegum/40 blur-3xl" />
      <div className="absolute -right-16 top-24 h-80 w-80 rounded-full bg-lavender/50 blur-3xl" />
      <Heart className="absolute left-[8%] top-[22%] h-8 w-8 animate-floaty text-bubblegum" />
      <Star className="absolute right-[12%] top-[14%] h-6 w-6 animate-floaty text-lavender-700/60 [animation-delay:1.2s]" />
      <Sparkle className="absolute left-[18%] bottom-[18%] h-6 w-6 animate-floaty text-lavender [animation-delay:2s]" />
      <Heart className="absolute right-[9%] bottom-[24%] h-10 w-10 animate-floaty text-bubblegum-600/50 [animation-delay:.6s]" />
    </div>
  );
}
