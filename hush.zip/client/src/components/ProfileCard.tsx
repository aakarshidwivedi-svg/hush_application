import { useState, type ReactNode } from 'react';
import type { PublicProfile } from '../types';

type CardProfile = PublicProfile & { sharedInterestIds?: string[]; reason?: string | null };
import { InitialTile } from './ui/Avatar';
import { Badge } from './ui/Badge';

/**
 * A person's approved public profile: primary photo, nickname, a few interests and a short bio.
 * Nothing here depends on who has crushed on whom. Photos are lazy-loaded and responsive (the card-size
 * thumbnail on small screens, the full size when the layout needs it).
 */
export function ProfileCard({
  profile,
  footer,
  size = 'large',
  maxChips = 4,
  as: Tag = 'article',
}: {
  profile: CardProfile;
  footer?: ReactNode;
  size?: 'large' | 'compact';
  maxChips?: number;
  as?: 'article' | 'div';
}) {
  const [broken, setBroken] = useState(false);
  const photo = profile.photo && !broken ? profile.photo : null;
  const shared = new Set(profile.sharedInterestIds ?? []);
  // Shared interests first, so the reason for the ranking is visible even when only a few chips fit.
  const ordered = [...profile.interests].sort((a, b) => Number(shared.has(b.id)) - Number(shared.has(a.id)));
  const chips = ordered.slice(0, maxChips);
  const extra = ordered.length - chips.length;
  const ratio = size === 'large' ? 'aspect-[4/5]' : 'aspect-[4/3]';

  return (
    <Tag className="card group flex h-full flex-col overflow-hidden p-0 transition hover:shadow-lift">
      <div className={`relative ${ratio} w-full overflow-hidden bg-lavender-200`}>
        {photo ? (
          <img
            src={photo.thumbUrl}
            srcSet={`${photo.thumbUrl} 480w, ${photo.url} 1280w`}
            sizes="(min-width: 1024px) 320px, (min-width: 640px) 45vw, 92vw"
            alt={`${profile.nickname}’s photo`}
            loading="lazy"
            decoding="async"
            onError={() => setBroken(true)}
            className="h-full w-full object-cover transition duration-500 motion-safe:group-hover:scale-[1.03]"
          />
        ) : (
          <InitialTile nickname={profile.nickname} textSize="text-7xl" className="h-full w-full" />
        )}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-plum/75 to-transparent px-4 pb-3 pt-12">
          <h3 className="break-words font-display text-2xl font-bold text-white drop-shadow">{profile.nickname}</h3>
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-3 p-4">
        {profile.bio ? <p className="line-clamp-3 whitespace-pre-line break-words text-plum-700">{profile.bio}</p> : <p className="italic text-plum-500">No bio yet.</p>}
        {profile.reason && <p className="text-sm font-semibold text-lavender-700">{profile.reason}</p>}
        {chips.length > 0 && (
          <ul className="flex flex-wrap gap-1.5" aria-label={`${profile.nickname}’s interests`}>
            {chips.map((i) => (
              <li key={i.id}><Badge tone={shared.has(i.id) ? 'plum' : 'lavender'}>{i.name}</Badge></li>
            ))}
            {extra > 0 && <li><Badge tone="pink">+{extra} more</Badge></li>}
          </ul>
        )}
        {footer && <div className="mt-auto pt-1">{footer}</div>}
      </div>
    </Tag>
  );
}
