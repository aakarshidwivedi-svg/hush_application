import { useState } from 'react';
import { Button } from './ui/Button';
import { ErrorMessage, Skeleton } from './ui/States';
import { useAsync } from '../hooks/useAsync';
import { inviteLink } from '../lib/invite';
import { api } from '../services/api';

/**
 * Consent-based invites: the person shares their own link themselves. Hush never reads contacts or sends
 * messages for them, and the person only ever sees how many friends joined — never who.
 */
export function InviteCard() {
  const invite = useAsync(() => api.myInvite(), []);
  const [note, setNote] = useState('');
  const link = invite.data ? inviteLink(invite.data.code) : '';

  async function copy() {
    try {
      await navigator.clipboard.writeText(link);
      setNote('Link copied!');
    } catch {
      setNote('Could not copy automatically — select the link and copy it.');
    }
  }
  async function share() {
    try {
      await navigator.share({ title: 'Join me on Hush', text: 'A campus-only app for secret crushes. Join with my link:', url: link });
    } catch { /* cancelled */ }
  }

  return (
    <section aria-labelledby="s-invite" className="card p-6 sm:p-8">
      <h2 id="s-invite" className="mb-1 text-2xl font-bold">Invite friends</h2>
      <p className="mb-4 text-plum-700">Hush works best when your campus is here. Share your personal link with friends you choose — we never read your contacts or message anyone for you.</p>
      {invite.loading && !invite.data ? (
        <Skeleton className="h-12 w-full" />
      ) : invite.error && !invite.data ? (
        <ErrorMessage message={invite.error} onRetry={() => void invite.reload()} />
      ) : invite.data ? (
        <>
          <label htmlFor="invite-link" className="mb-1 block text-sm font-bold">Your invite link</label>
          <input id="invite-link" readOnly value={link} onFocus={(e) => e.currentTarget.select()} className="w-full rounded-2xl border-0 bg-white px-4 py-3 text-sm shadow-sm ring-1 ring-plum/15 focus-visible:ring-2 focus-visible:ring-lavender-700" />
          <div className="mt-3 flex flex-wrap items-center gap-3">
            <Button onClick={() => void copy()}>Copy link</Button>
            {typeof navigator !== 'undefined' && 'share' in navigator && <Button variant="secondary" onClick={() => void share()}>Share…</Button>}
            <span role="status" aria-live="polite" className="text-sm text-plum-700">{note}</span>
          </div>
          <p className="mt-4 text-sm text-plum-700">
            {invite.data.joined === 0 ? 'No one has joined with your link yet.' : `${invite.data.joined} ${invite.data.joined === 1 ? 'friend has' : 'friends have'} joined with your link.`} Invites never affect who you see or match with.
          </p>
        </>
      ) : null}
    </section>
  );
}
