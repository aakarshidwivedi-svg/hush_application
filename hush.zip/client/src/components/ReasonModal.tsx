import { useEffect, useState } from 'react';
import { Button } from './ui/Button';
import { TextArea } from './ui/Fields';
import { Modal } from './ui/Modal';
import { ErrorMessage } from './ui/States';

/** Confirmation dialog for moderation decisions: nothing is sent without a written reason (kept in the audit log). */
export function ReasonModal({ open, title, body, confirmLabel, busy, error, onConfirm, onClose }: {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  busy?: boolean;
  error?: string | null;
  onConfirm: (reason: string) => void;
  onClose: () => void;
}) {
  const [reason, setReason] = useState('');
  const [touched, setTouched] = useState(false);
  useEffect(() => { if (open) { setReason(''); setTouched(false); } }, [open]);
  const trimmed = reason.trim();

  return (
    <Modal open={open} onClose={onClose} title={title}>
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          setTouched(true);
          if (trimmed) onConfirm(trimmed);
        }}
      >
        <p className="text-plum-700">{body}</p>
        <TextArea
          label="Reason (recorded in the audit log)"
          value={reason}
          maxLength={500}
          rows={3}
          onChange={(e) => setReason(e.target.value)}
          error={touched && !trimmed ? 'Please give a reason' : undefined}
          hint={`${reason.length}/500`}
        />
        {error && <ErrorMessage message={error} />}
        <div className="flex gap-3">
          <Button variant="secondary" className="flex-1" onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="danger" className="flex-1" loading={busy}>{confirmLabel}</Button>
        </div>
      </form>
    </Modal>
  );
}
