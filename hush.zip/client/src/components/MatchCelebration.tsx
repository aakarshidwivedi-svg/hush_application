import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useNotifications } from '../hooks/useNotifications';
import { api } from '../services/api';
import type { MatchView } from '../types';
import { Heart, Sparkle } from './Illustrations';
import { Avatar } from './ui/Avatar';
import { Badge } from './ui/Badge';
import { Button } from './ui/Button';
import { Modal } from './ui/Modal';

/** Mounted once for signed-in users. A notification exists only for a *committed* match. */
export function MatchCelebrationHost() {
  const { items, markRead: markNotificationsRead } = useNotifications();
  const { me } = useAuth();
  const [matches, setMatches] = useState<MatchView[]>([]);
  const navigate = useNavigate();

  // Only match notifications are celebrated; unread-message notifications are for the inbox and chat badges.
  const matchNotes = items.filter((i) => i.type === 'MATCH');
  const markRead = () => markNotificationsRead({ ids: matchNotes.map((n) => n.id) });
  const ids = matchNotes.map((i) => i.matchId).join(',');
  useEffect(() => {
    if (!ids) return setMatches([]);
    let alive = true;
    api.matches().then((all) => {
      if (!alive) return;
      const wanted = new Set(ids.split(','));
      const fresh = all.filter((m) => wanted.has(m.id));
      setMatches(fresh);
      // Lets open pages react: the Matches list refreshes and Discover drops people you just matched with.
      window.dispatchEvent(new CustomEvent('hush:match', { detail: { partnerIds: fresh.map((m) => m.partner.id) } }));
    }).catch(() => undefined);
    return () => { alive = false; };
  }, [ids]);

  const first = matches[0];
  if (!first || !me) return null;
  const others = matches.length - 1;
  const partner = first.partner;
  return (
    <Modal open onClose={() => void markRead()} title="It's a match!">
      <div className="relative text-center">
        <div className="pointer-events-none absolute inset-x-0 -top-2 flex justify-around" aria-hidden="true">
          {[0, 1, 2, 3, 4].map((n) => <Heart key={n} className="h-5 w-5 animate-rise text-bubblegum-600 opacity-0" style={{ animationDelay: `${n * 0.18}s` }} />)}
        </div>
        <p className="font-display text-3xl font-bold">It&apos;s mutual! <span aria-hidden="true">💗</span></p>
        <div className="mx-auto my-5 flex w-fit animate-pop items-center">
          <Avatar nickname={me.nickname} photo={me.photo} size="h-28 w-28" textSize="text-4xl" />
          <span className="z-10 -mx-3 grid h-10 w-10 place-items-center rounded-full bg-white shadow-soft" aria-hidden="true"><Heart className="h-6 w-6 text-bubblegum-600" /></span>
          <Avatar nickname={partner.nickname} photo={partner.photo} size="h-28 w-28" textSize="text-4xl" />
        </div>
        <p className="text-lg">You and <strong>{partner.nickname}</strong> both liked each other.</p>
        {partner.bio && <p className="mx-auto mt-2 line-clamp-2 max-w-xs text-sm text-plum-700">{partner.bio}</p>}
        {partner.interests.length > 0 && (
          <ul className="mt-3 flex flex-wrap justify-center gap-1.5" aria-label={`${partner.nickname}’s interests`}>
            {partner.interests.slice(0, 4).map((i) => <li key={i.id}><Badge>{i.name}</Badge></li>)}
          </ul>
        )}
        {others > 0 && <p className="mt-3 flex items-center justify-center gap-1 text-sm text-plum-700"><Sparkle className="h-4 w-4 text-lavender-700" />…and {others} more new match{others > 1 ? 'es' : ''}!</p>}
        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
          <Button variant="secondary" className="flex-1" onClick={() => { void markRead(); navigate('/discover'); }}>Continue discovering</Button>
          <Button className="flex-1" onClick={() => { void markRead(); navigate(`/matches/${first.id}`); }}>Start chatting</Button>
        </div>
      </div>
    </Modal>
  );
}
