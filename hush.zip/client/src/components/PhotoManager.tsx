import { useCallback, useEffect, useRef, useState, type ChangeEvent } from 'react';
import { ACCEPTED_TYPES, ImageError, MAX_PHOTOS, prepareImage, type PreparedImage } from '../lib/image';
import { api, ApiError } from '../services/api';
import type { OwnPhoto } from '../types';
import { ConfirmModal } from './ConfirmModal';
import { Button } from './ui/Button';
import { ErrorMessage, Skeleton } from './ui/States';

interface Staged {
  key: string;
  name: string;
  status: 'preparing' | 'ready' | 'uploading' | 'error';
  progress: number;
  error?: string;
  prepared?: PreparedImage;
}

const errorText = (e: unknown) => (e instanceof ApiError || e instanceof ImageError || e instanceof Error ? e.message : 'Something went wrong');

/**
 * Photo manager used by onboarding and Settings. Pick photos → check the previews in the tray →
 * upload. Every change goes through the API, which enforces ownership, the 6-photo limit and
 * format/size/dimension rules; this component only makes that pleasant.
 */
export function PhotoManager({ onChange }: { onChange?: (photos: OwnPhoto[]) => void }) {
  const [photos, setPhotos] = useState<OwnPhoto[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [staged, setStaged] = useState<Staged[]>([]);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<OwnPhoto | null>(null);
  const [uploading, setUploading] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const stagedRef = useRef<Staged[]>([]);
  // Only one edit (main/reorder/delete) may be in flight: a second click fired before React re-renders the
  // disabled buttons must not act on a stale list, so the lock lives in a ref, not in state.
  const busy = useRef(false);
  const photosRef = useRef<OwnPhoto[] | null>(null);
  stagedRef.current = staged;
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  const apply = useCallback((list: OwnPhoto[]) => {
    photosRef.current = list;
    setPhotos(list);
    onChangeRef.current?.(list);
  }, []);

  const load = useCallback(async () => {
    setLoadError(null);
    try {
      apply(await api.photos());
    } catch (e) {
      setLoadError(errorText(e));
    }
  }, [apply]);

  useEffect(() => { void load(); }, [load]);
  // Free preview memory when leaving the page.
  useEffect(() => () => { stagedRef.current.forEach((s) => s.prepared && URL.revokeObjectURL(s.prepared.previewUrl)); }, []);

  const count = photos?.length ?? 0;
  const room = MAX_PHOTOS - count - staged.length;

  async function onPick(e: ChangeEvent<HTMLInputElement>) {
    const files = [...(e.target.files ?? [])];
    e.target.value = ''; // allow picking the same file again later
    if (files.length === 0) return;
    setError(null);
    const take = files.slice(0, Math.max(0, room));
    if (files.length > take.length) setError(`You can have up to ${MAX_PHOTOS} photos, so ${files.length - take.length} wasn't added.`);
    const items: Staged[] = take.map((f) => ({ key: crypto.randomUUID(), name: f.name, status: 'preparing', progress: 0 }));
    setStaged((s) => [...s, ...items]);
    await Promise.all(
      take.map(async (file, i) => {
        const key = items[i]!.key;
        try {
          const prepared = await prepareImage(file);
          setStaged((s) => s.map((x) => (x.key === key ? { ...x, status: 'ready', prepared } : x)));
        } catch (err) {
          setStaged((s) => s.map((x) => (x.key === key ? { ...x, status: 'error', error: errorText(err) } : x)));
        }
      }),
    );
  }

  function discard(key: string) {
    setStaged((s) => {
      const gone = s.find((x) => x.key === key);
      if (gone?.prepared) URL.revokeObjectURL(gone.prepared.previewUrl);
      return s.filter((x) => x.key !== key);
    });
  }

  async function uploadAll() {
    setUploading(true);
    setError(null);
    let uploaded = 0;
    for (const item of stagedRef.current.filter((s) => s.status === 'ready' || (s.status === 'error' && s.prepared))) {
      const prepared = item.prepared!;
      setStaged((s) => s.map((x) => (x.key === item.key ? { ...x, status: 'uploading', progress: 0, error: '' } : x)));
      try {
        await api.uploadPhoto(prepared.blob, (f) => setStaged((s) => s.map((x) => (x.key === item.key ? { ...x, progress: f } : x))));
        URL.revokeObjectURL(prepared.previewUrl);
        setStaged((s) => s.filter((x) => x.key !== item.key));
        uploaded += 1;
      } catch (err) {
        setStaged((s) => s.map((x) => (x.key === item.key ? { ...x, status: 'error', error: errorText(err) } : x)));
        if (err instanceof ApiError && (err.code === 'PHOTO_LIMIT' || err.status === 429)) break;
      }
    }
    if (uploaded > 0) {
      await load();
      setNotice(`${uploaded} photo${uploaded > 1 ? 's' : ''} uploaded.`);
    }
    setUploading(false);
  }

  async function run(id: string, label: string, op: () => Promise<OwnPhoto[]>) {
    if (busy.current) return;
    busy.current = true;
    setBusyId(id);
    setError(null);
    try {
      apply(await op());
      setNotice(label);
    } catch (e) {
      setError(errorText(e));
      await load();
    } finally {
      busy.current = false;
      setBusyId(null);
    }
  }

  function move(index: number, dir: -1 | 1) {
    const current = photosRef.current;
    if (!current || busy.current) return;
    const ids = current.map((p) => p.id);
    const j = index + dir;
    if (j < 0 || j >= ids.length) return;
    [ids[index], ids[j]] = [ids[j]!, ids[index]!];
    void run(current[index]!.id, `Photo moved to position ${j + 1}.`, () => api.reorderPhotos(ids));
  }

  async function confirmDelete() {
    if (!deleting) return;
    const gone = deleting;
    setDeleting(null);
    await run(gone.id, 'Photo deleted.', () => api.deletePhoto(gone.id));
  }

  const readyCount = staged.filter((s) => s.status === 'ready' || (s.status === 'error' && s.prepared)).length;
  const preparing = staged.some((s) => s.status === 'preparing');

  return (
    <div className="space-y-5">
      <p className="sr-only" role="status" aria-live="polite">{notice}</p>

      {loadError ? (
        <ErrorMessage message={loadError} onRetry={() => void load()} />
      ) : photos === null ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3" aria-busy="true" aria-label="Loading your photos">
          {[0, 1, 2].map((n) => <Skeleton key={n} className="aspect-[4/5] w-full" />)}
        </div>
      ) : (
        <>
          {photos.length > 0 && (
            <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3" aria-label="Your photos">
              {photos.map((p, i) => (
                <li key={p.id} className="card overflow-hidden p-0">
                  <div className="relative aspect-[4/5] bg-lavender-200">
                    <img src={p.thumbUrl} alt={`Your photo ${i + 1}${p.isPrimary ? ' (main photo)' : ''}`} loading="lazy" decoding="async" className="h-full w-full object-cover" />
                    {p.isPrimary && <span className="absolute left-2 top-2 rounded-full bg-plum px-2.5 py-1 text-xs font-bold text-white shadow">★ Main</span>}
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 p-2">
                    {!p.isPrimary && (
                      <Button size="sm" variant="secondary" loading={busyId === p.id} onClick={() => void run(p.id, `Photo ${i + 1} is now your main photo.`, () => api.setPrimaryPhoto(p.id))} aria-label={`Make photo ${i + 1} your main photo`}>Make main</Button>
                    )}
                    <span className="ml-auto flex gap-1">
                      <button type="button" disabled={i === 0 || busyId !== null} onClick={() => move(i, -1)} aria-label={`Move photo ${i + 1} earlier`} className="grid h-9 w-9 place-items-center rounded-full bg-white ring-1 ring-plum/15 hover:bg-lavender-200/60 disabled:opacity-40">←</button>
                      <button type="button" disabled={i === photos.length - 1 || busyId !== null} onClick={() => move(i, 1)} aria-label={`Move photo ${i + 1} later`} className="grid h-9 w-9 place-items-center rounded-full bg-white ring-1 ring-plum/15 hover:bg-lavender-200/60 disabled:opacity-40">→</button>
                      <button type="button" disabled={busyId !== null} onClick={() => setDeleting(p)} aria-label={`Delete photo ${i + 1}`} className="grid h-9 w-9 place-items-center rounded-full bg-white ring-1 ring-plum/15 hover:bg-bubblegum/30 disabled:opacity-40">🗑</button>
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}

          {staged.length > 0 && (
            <section aria-label="Photos ready to upload" className="rounded-3xl bg-cream p-4 ring-1 ring-plum/10">
              <h3 className="mb-3 font-sans text-base font-bold">Preview — not saved yet</h3>
              <ul className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {staged.map((s) => (
                  <li key={s.key} className="overflow-hidden rounded-2xl bg-white ring-1 ring-plum/10">
                    <div className="relative aspect-[4/5] bg-lavender-200">
                      {s.prepared ? <img src={s.prepared.previewUrl} alt={`Preview of ${s.name}`} className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center text-sm text-plum-700">{s.status === 'error' ? '⚠️' : 'Preparing…'}</div>}
                      {s.status === 'uploading' && (
                        <div className="absolute inset-x-0 bottom-0 bg-plum/70 p-2">
                          <div role="progressbar" aria-label={`Uploading ${s.name}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(s.progress * 100)} className="h-2 overflow-hidden rounded-full bg-white/30">
                            <div className="h-full rounded-full bg-bubblegum transition-[width]" style={{ width: `${Math.round(s.progress * 100)}%` }} />
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="space-y-1 p-2">
                      <p className="truncate text-xs text-plum-700">{s.name}</p>
                      {s.error && <p role="alert" className="text-xs font-semibold text-bubblegum-700">{s.error}</p>}
                      {s.status !== 'uploading' && (
                        <button type="button" onClick={() => discard(s.key)} className="text-xs font-bold underline">Remove</button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <Button onClick={() => void uploadAll()} loading={uploading} disabled={readyCount === 0 || preparing}>
                  Upload {readyCount} photo{readyCount === 1 ? '' : 's'}
                </Button>
              </div>
            </section>
          )}

          <div className="flex flex-wrap items-center gap-3">
            <input ref={input} type="file" accept={ACCEPTED_TYPES.join(',')} multiple className="sr-only" id="photo-input" onChange={(e) => void onPick(e)} aria-label="Choose photos to add" tabIndex={-1} />
            <Button variant="secondary" disabled={room <= 0 || uploading} onClick={() => input.current?.click()}>
              + Add photos
            </Button>
            <p className="text-sm text-plum-700">{count} of {MAX_PHOTOS} photos · JPEG, PNG or WebP · at least 300×300 px</p>
          </div>
          {room <= 0 && count >= MAX_PHOTOS && <p className="text-sm text-plum-700">That&rsquo;s the maximum. Delete a photo to add a different one.</p>}
        </>
      )}

      {error && <ErrorMessage message={error} />}

      <ConfirmModal
        open={deleting !== null}
        title="Delete this photo?"
        body={deleting?.isPrimary && count > 1 ? 'This is your main photo. Your next photo will become the main one.' : count === 1 ? "This is your only photo. You'll need at least one photo to appear in Discover." : 'It will be removed from your profile for good.'}
        confirmLabel="Delete"
        busy={false}
        onConfirm={() => void confirmDelete()}
        onClose={() => setDeleting(null)}
      />
    </div>
  );
}
