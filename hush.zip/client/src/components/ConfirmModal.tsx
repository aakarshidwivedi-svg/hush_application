import { Button } from './ui/Button';
import { Modal } from './ui/Modal';

export function ConfirmModal({ open, title, body, confirmLabel, busy, onConfirm, onClose }: { open: boolean; title: string; body: string; confirmLabel: string; busy?: boolean; onConfirm: () => void; onClose: () => void }) {
  return (
    <Modal open={open} onClose={onClose} title={title}>
      <p className="mb-5 text-plum-700">{body}</p>
      <div className="flex gap-3">
        <Button variant="secondary" className="flex-1" onClick={onClose}>Cancel</Button>
        <Button variant="danger" className="flex-1" loading={busy} onClick={onConfirm}>{confirmLabel}</Button>
      </div>
    </Modal>
  );
}
