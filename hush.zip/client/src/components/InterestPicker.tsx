import { useId, useMemo, useState } from 'react';
import type { InterestCategory } from '../types';

export const MIN_INTERESTS = 3;
export const MAX_INTERESTS = 10;

/**
 * Searchable, grouped interest chips. Values are canonical interest ids from the server catalog
 * (the API rejects anything else), not free text. Selected state is shown with a ✓ and a filled
 * chip, never colour alone.
 */
export function InterestPicker({
  catalog,
  value,
  onChange,
  error,
}: {
  catalog: InterestCategory[];
  value: string[];
  onChange: (ids: string[]) => void;
  error?: string | undefined;
}) {
  const searchId = useId();
  const [query, setQuery] = useState('');
  const selected = useMemo(() => new Set(value), [value]);
  const names = useMemo(() => new Map(catalog.flatMap((c) => c.interests.map((i) => [i.id, i.name] as const))), [catalog]);
  const atMax = value.length >= MAX_INTERESTS;
  const q = query.trim().toLowerCase();

  const groups = useMemo(
    () =>
      catalog
        .map((c) => ({ category: c.category, interests: q ? c.interests.filter((i) => i.name.toLowerCase().includes(q) || c.category.toLowerCase().includes(q)) : c.interests }))
        .filter((c) => c.interests.length > 0),
    [catalog, q],
  );

  const toggle = (id: string) => {
    if (selected.has(id)) onChange(value.filter((v) => v !== id));
    else if (!atMax) onChange([...value, id]);
  };

  const counter =
    value.length < MIN_INTERESTS
      ? `${value.length} of ${MAX_INTERESTS} selected · pick ${MIN_INTERESTS - value.length} more to continue`
      : `${value.length} of ${MAX_INTERESTS} selected${atMax ? ' · that’s the max' : ''}`;

  return (
    <div className="space-y-4">
      <div>
        <label htmlFor={searchId} className="mb-1.5 block text-sm font-bold">Search interests</label>
        <input
          id={searchId}
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Try “coffee”, “anime” or “coding”"
          autoComplete="off"
          className="w-full rounded-2xl border-0 bg-white px-4 py-3 text-plum shadow-sm ring-1 ring-plum/15 placeholder:text-plum-500/70 focus-visible:ring-2 focus-visible:ring-lavender-700"
        />
      </div>

      <p role="status" aria-live="polite" className={`text-sm font-bold ${value.length < MIN_INTERESTS ? 'text-plum-700' : 'text-lavender-700'}`}>{counter}</p>

      {value.length > 0 && (
        <ul className="flex flex-wrap gap-2" aria-label="Your picks">
          {value.map((id) => (
            <li key={id} className="inline-flex items-center rounded-full bg-bubblegum/40 py-1 pl-3 pr-1 text-sm font-bold">
              {names.get(id) ?? id}
              <button type="button" onClick={() => toggle(id)} aria-label={`Remove ${names.get(id) ?? id}`} className="ml-1 grid h-6 w-6 place-items-center rounded-full hover:bg-plum/10">×</button>
            </li>
          ))}
        </ul>
      )}

      {groups.length === 0 ? (
        <p className="rounded-2xl bg-cream p-4 text-sm text-plum-700">Nothing matches “{query}”. Try another word — or clear the search.</p>
      ) : (
        groups.map((g) => (
          <fieldset key={g.category}>
            <legend className="mb-2 font-sans text-sm font-bold uppercase tracking-wide text-plum-700">{g.category}</legend>
            <div className="flex flex-wrap gap-2">
              {g.interests.map((i) => {
                const on = selected.has(i.id);
                const locked = !on && atMax;
                return (
                  <button
                    key={i.id}
                    type="button"
                    aria-pressed={on}
                    aria-disabled={locked || undefined}
                    onClick={() => toggle(i.id)}
                    className={`rounded-full px-4 py-2 text-sm font-bold transition ${on ? 'bg-plum text-white shadow-soft' : 'bg-white text-plum ring-1 ring-plum/20 hover:bg-lavender-200/60'} ${locked ? 'cursor-not-allowed opacity-50' : ''}`}
                  >
                    {on && <span aria-hidden="true">✓ </span>}
                    {i.name}
                  </button>
                );
              })}
            </div>
          </fieldset>
        ))
      )}

      {error && <p role="alert" className="text-sm font-semibold text-bubblegum-700">{error}</p>}
    </div>
  );
}
