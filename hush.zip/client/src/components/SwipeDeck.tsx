import { useEffect, useRef, useState, type ReactNode } from 'react';

const THRESHOLD = 110; // px of horizontal drag that counts as a decision
const FLING = 0.6; // px/ms: a quick flick also counts

export type SwipeDirection = 'left' | 'right';

/**
 * One card at a time that can be dragged (touch, mouse or pen) to the right ("yes") or left ("not now").
 * Dragging is only a shortcut: every swipe has a button or an arrow key doing the same thing, so nothing
 * depends on being able to drag. Vertical movement is left to the browser, so scrolling the page still works.
 * With reduced motion the card simply goes, without flying off the screen.
 */
export function SwipeDeck({
  current,
  next,
  onSwipe,
  disabled = false,
  rightLabel,
  leftLabel,
  children,
}: {
  /** Identity of the top card; the deck resets whenever it changes. */
  current: string;
  /** Peek of what comes next (decoration only). */
  next?: ReactNode;
  onSwipe: (direction: SwipeDirection) => void;
  disabled?: boolean;
  rightLabel: string;
  leftLabel: string;
  children: ReactNode;
}) {
  const [dx, setDx] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [leaving, setLeaving] = useState<SwipeDirection | null>(null);
  const start = useRef<{ x: number; y: number; t: number; id: number } | null>(null);
  const axis = useRef<'x' | 'y' | null>(null);
  const reduced = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

  useEffect(() => { setDx(0); setLeaving(null); setDragging(false); }, [current]);

  const commit = (dir: SwipeDirection) => {
    if (disabled || leaving) return;
    if (reduced) return onSwipe(dir);
    setLeaving(dir);
    setDx(dir === 'right' ? 520 : -520);
    window.setTimeout(() => onSwipe(dir), 220);
  };

  // Arrow keys act on the deck whenever the focus is not inside a text field or on another control.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey) return;
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable)) return;
      if (document.querySelector('[role="dialog"]')) return;
      if (e.key === 'ArrowRight') { e.preventDefault(); commit('right'); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); commit('left'); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  function down(e: React.PointerEvent) {
    if (disabled || leaving || (e.target as HTMLElement).closest('button, a, input, textarea, select')) return;
    start.current = { x: e.clientX, y: e.clientY, t: performance.now(), id: e.pointerId };
    axis.current = null;
  }
  function move(e: React.PointerEvent) {
    const s = start.current;
    if (!s || s.id !== e.pointerId) return;
    const mx = e.clientX - s.x;
    const my = e.clientY - s.y;
    if (!axis.current) {
      if (Math.abs(mx) < 8 && Math.abs(my) < 8) return;
      axis.current = Math.abs(mx) > Math.abs(my) ? 'x' : 'y';
      if (axis.current === 'x') { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); setDragging(true); }
    }
    if (axis.current === 'x') setDx(mx);
  }
  function up(e: React.PointerEvent) {
    const s = start.current;
    if (!s || s.id !== e.pointerId) return;
    start.current = null;
    const wasX = axis.current === 'x';
    axis.current = null;
    setDragging(false);
    if (!wasX) return;
    const mx = e.clientX - s.x;
    const speed = Math.abs(mx) / Math.max(1, performance.now() - s.t);
    if (Math.abs(mx) > THRESHOLD || (speed > FLING && Math.abs(mx) > 40)) commit(mx > 0 ? 'right' : 'left');
    else setDx(0);
  }
  function cancel() { start.current = null; axis.current = null; setDragging(false); setDx(0); }

  const progress = Math.min(1, Math.abs(dx) / THRESHOLD);
  const style: React.CSSProperties = {
    transform: `translateX(${dx}px) rotate(${dx / 24}deg)`,
    transition: dragging ? 'none' : reduced ? 'none' : 'transform .22s ease-out',
    touchAction: 'pan-y', // vertical scrolling stays with the browser
  };

  return (
    <div className="relative mx-auto w-full max-w-sm select-none">
      {next && <div aria-hidden="true" className="pointer-events-none absolute inset-0 origin-bottom scale-[0.95] opacity-60 [&_*]:!pointer-events-none"><div className="h-full overflow-hidden rounded-3xl">{next}</div></div>}
      <div
        className="relative cursor-grab active:cursor-grabbing"
        style={style}
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={cancel}
      >
        {children}
        {dx > 12 && <span aria-hidden="true" style={{ opacity: progress }} className="pointer-events-none absolute left-4 top-4 rotate-[-8deg] rounded-xl border-4 border-bubblegum-700 bg-white/90 px-3 py-1 text-lg font-extrabold uppercase text-bubblegum-700">{rightLabel}</span>}
        {dx < -12 && <span aria-hidden="true" style={{ opacity: progress }} className="pointer-events-none absolute right-4 top-4 rotate-[8deg] rounded-xl border-4 border-plum bg-white/90 px-3 py-1 text-lg font-extrabold uppercase text-plum">{leftLabel}</span>}
      </div>
    </div>
  );
}
