import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useModerator } from '../hooks/useModerator';
import { useNotifications } from '../hooks/useNotifications';
import { Heart } from './Illustrations';
import { Logo } from './Illustrations';
import { MatchCelebrationHost } from './MatchCelebration';
import { buttonClass } from './ui/Button';

const appLinks: { to: string; label: string; badge?: number }[] = [
  { to: '/discover', label: 'Discover' },
  { to: '/matches', label: 'Matches' },
  { to: '/notifications', label: 'Notifications' },
  { to: '/settings', label: 'Settings' },
];

export function Layout() {
  const { status, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  const isMod = useModerator();
  const { items, unreadCount } = useNotifications();
  const unreadChats = items.filter((n) => n.type === 'MESSAGE').length;
  const signedIn = status === 'ready' || status === 'needs-onboarding';

  useEffect(() => setOpen(false), [loc.pathname]);
  // Move focus to the page heading region on navigation so keyboard/screen-reader users land on new content.
  // Move focus to <main> only when the route actually changes (never on first paint, and robust to
  // React StrictMode's double-invoked effects), so the skip link stays the first Tab stop on load.
  const lastPath = useRef(loc.pathname);
  useEffect(() => {
    if (lastPath.current === loc.pathname) return;
    lastPath.current = loc.pathname;
    document.getElementById('main')?.focus({ preventScroll: true });
    window.scrollTo(0, 0);
  }, [loc.pathname]);

  const badges: Record<string, number> = { '/matches': unreadChats, '/notifications': unreadCount };
  const links = (isMod ? [...appLinks, { to: '/moderation', label: 'Moderation' }] : appLinks).map((l) => ({ ...l, badge: badges[l.to] ?? 0 }));
  const renderLink = (l: (typeof links)[number]) => (
    <NavLink key={l.to} to={l.to} className={linkClass}>
      {l.label}
      {l.badge > 0 && (
        <span className="ml-1.5 inline-grid min-w-[1.25rem] place-items-center rounded-full bg-bubblegum-700 px-1.5 text-xs font-bold leading-5 text-white">
          <span aria-hidden="true">{l.badge > 99 ? '99+' : l.badge}</span>
          <span className="sr-only">{l.badge} unread</span>
        </span>
      )}
    </NavLink>
  );
  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `rounded-full px-4 py-2 font-bold transition hover:bg-lavender-200/70 ${isActive ? 'bg-lavender-200 text-plum' : 'text-plum-700'}`;

  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="sr-only z-[60] rounded-full bg-plum px-4 py-2 font-bold text-white focus:not-sr-only focus:fixed focus:left-4 focus:top-4">
        Skip to content
      </a>
      <header className="sticky top-0 z-40 border-b border-plum/5 bg-cream/85 backdrop-blur">
        <div className="page flex h-16 items-center justify-between">
          <Link to={status === 'ready' ? '/discover' : '/'} aria-label="Hush home">
            <Logo />
          </Link>

          <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
            {status === 'ready' && links.map(renderLink)}
            {status === 'anonymous' && (
              <>
                <a href="/#how" className="rounded-full px-4 py-2 font-bold text-plum-700 hover:bg-lavender-200/70">How it works</a>
                <a href="/#safety" className="rounded-full px-4 py-2 font-bold text-plum-700 hover:bg-lavender-200/70">Safety</a>
                <Link to="/login" className={buttonClass('ghost', 'sm')}>Log in</Link>
                <Link to="/signup" className={buttonClass('primary', 'sm')}>Sign up</Link>
              </>
            )}
            {signedIn && (
              <button type="button" onClick={() => void signOut()} className={buttonClass('ghost', 'sm')}>
                Log out
              </button>
            )}
          </nav>

          <button
            type="button"
            className="grid h-11 w-11 place-items-center rounded-full bg-white shadow-soft md:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            aria-label={open ? 'Close menu' : 'Open menu'}
            onClick={() => setOpen((o) => !o)}
          >
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" aria-hidden="true">
              {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 7h16M4 12h16M4 17h16" />}
            </svg>
          </button>
        </div>

        {open && (
          <nav id="mobile-nav" aria-label="Mobile" className="page flex flex-col gap-1 pb-4 md:hidden">
            {status === 'ready' && links.map(renderLink)}
            {status === 'anonymous' && (
              <>
                <a href="/#how" className="rounded-full px-4 py-2 font-bold">How it works</a>
                <a href="/#safety" className="rounded-full px-4 py-2 font-bold">Safety</a>
                <Link to="/login" className={buttonClass('secondary')}>Log in</Link>
                <Link to="/signup" className={buttonClass('primary')}>Sign up</Link>
              </>
            )}
            {signedIn && <button type="button" onClick={() => void signOut()} className={buttonClass('secondary')}>Log out</button>}
          </nav>
        )}
      </header>

      {status === 'ready' && <MatchCelebrationHost />}
      <main id="main" tabIndex={-1} className="flex-1 outline-none">
        <Outlet />
      </main>

      <footer className="mt-16 border-t border-plum/10 bg-white/60">
        <div className="page flex flex-col gap-6 py-10 md:flex-row md:items-center md:justify-between">
          <div>
            <Logo className="!text-xl" />
            <p className="mt-2 flex items-center gap-1 text-sm text-plum-700">
              Made with <Heart className="h-3.5 w-3.5 text-bubblegum-600" /> for campus crushes. 18+ only.
            </p>
          </div>
          <nav aria-label="Legal" className="flex flex-wrap gap-x-6 gap-y-2 text-sm font-bold">
            <Link to="/terms" className="hover:underline">Terms</Link>
            <Link to="/privacy" className="hover:underline">Privacy Policy</Link>
            <Link to="/guidelines" className="hover:underline">Community Guidelines</Link>
            <Link to="/contact" className="hover:underline">Contact</Link>
          </nav>
        </div>
      </footer>
    </div>
  );
}
