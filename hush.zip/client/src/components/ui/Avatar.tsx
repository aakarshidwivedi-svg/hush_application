import { useState } from 'react';
import type { PhotoRef } from '../../types';

const GRADIENTS = [
  'from-bubblegum to-lavender',
  'from-lavender to-bubblegum-300',
  'from-bubblegum-300 to-lavender-200',
  'from-lavender-200 to-bubblegum',
];

/** Gradient + initial placeholder, used when someone has no (loadable) photo. */
export function InitialTile({ nickname, className = '', textSize = 'text-2xl' }: { nickname: string; className?: string; textSize?: string }) {
  const g = GRADIENTS[[...nickname].reduce((n, c) => n + c.charCodeAt(0), 0) % GRADIENTS.length];
  return (
    <span aria-hidden="true" className={`${className} ${textSize} grid place-items-center bg-gradient-to-br ${g} font-display font-bold text-plum`}>
      {nickname.charAt(0).toUpperCase()}
    </span>
  );
}

/** Round photo (the small signed thumbnail), falling back to the initial tile. */
export function Avatar({ nickname, photo, size = 'h-16 w-16', textSize = 'text-2xl' }: { nickname: string; photo: PhotoRef | null; size?: string; textSize?: string }) {
  const [broken, setBroken] = useState(false);
  if (photo && !broken) {
    return <img src={photo.thumbUrl} alt="" loading="lazy" decoding="async" onError={() => setBroken(true)} className={`${size} shrink-0 rounded-full object-cover ring-2 ring-white`} />;
  }
  return <InitialTile nickname={nickname} textSize={textSize} className={`${size} shrink-0 rounded-full ring-2 ring-white`} />;
}
