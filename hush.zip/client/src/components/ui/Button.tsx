import { Link, type LinkProps } from 'react-router-dom';
import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { Spinner } from './States';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
type Size = 'sm' | 'md' | 'lg';

const base =
  'inline-flex items-center justify-center gap-2 rounded-full font-bold transition active:scale-[.98] disabled:cursor-not-allowed disabled:opacity-60 select-none';
const variants: Record<Variant, string> = {
  primary: 'bg-gradient-to-br from-bubblegum to-bubblegum-600 text-plum shadow-soft hover:shadow-lift hover:brightness-105',
  secondary: 'bg-white text-plum ring-1 ring-plum/15 hover:bg-lavender-200/60',
  ghost: 'text-plum hover:bg-plum/5',
  danger: 'bg-plum text-white hover:bg-plum-700',
};
const sizes: Record<Size, string> = { sm: 'px-4 py-2 text-sm', md: 'px-5 py-2.5 text-base', lg: 'px-7 py-3.5 text-lg' };

export const buttonClass = (v: Variant = 'primary', s: Size = 'md', extra = '') => `${base} ${variants[v]} ${sizes[s]} ${extra}`;

interface BtnProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  children: ReactNode;
}

export function Button({ variant = 'primary', size = 'md', loading, disabled, className = '', children, type = 'button', ...rest }: BtnProps) {
  return (
    <button type={type} disabled={disabled || loading} aria-busy={loading || undefined} className={buttonClass(variant, size, className)} {...rest}>
      {loading && <Spinner className="h-4 w-4" />}
      {children}
    </button>
  );
}

export function LinkButton({ variant = 'primary', size = 'md', className = '', ...rest }: LinkProps & { variant?: Variant; size?: Size }) {
  return <Link className={buttonClass(variant, size, className)} {...rest} />;
}
