import type { ReactNode } from 'react';
import { Heart } from '../Illustrations';
import { Button } from './Button';

export function Spinner({ className = 'h-6 w-6' }: { className?: string }) {
  return (
    <svg className={`animate-spin ${className}`} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity=".25" strokeWidth="3" />
      <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export function PageLoader({ label = 'Loading…' }: { label?: string }) {
  return (
    <div role="status" className="grid min-h-[50vh] place-items-center text-plum-700">
      <div className="flex flex-col items-center gap-3">
        <Heart className="h-10 w-10 animate-floaty text-bubblegum" />
        <span className="text-sm font-semibold">{label}</span>
      </div>
    </div>
  );
}

export function Skeleton({ className = '' }: { className?: string }) {
  return (
    <div aria-hidden="true" className={`relative overflow-hidden rounded-2xl bg-plum/10 ${className}`}>
      <div className="absolute inset-0 -translate-x-full animate-shimmer bg-gradient-to-r from-transparent via-white/60 to-transparent [animation-duration:1.6s] [animation-iteration-count:infinite]" />
    </div>
  );
}

export function CardSkeleton() {
  return (
    <div className="card overflow-hidden" aria-hidden="true">
      <Skeleton className="aspect-[4/5] w-full !rounded-none" />
      <div className="space-y-3 p-4">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-2/3" />
        <div className="flex gap-2">
          <Skeleton className="h-6 w-16 !rounded-full" />
          <Skeleton className="h-6 w-20 !rounded-full" />
          <Skeleton className="h-6 w-14 !rounded-full" />
        </div>
        <Skeleton className="h-11 w-full !rounded-full" />
      </div>
    </div>
  );
}

export function ErrorMessage({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="rounded-2xl border border-bubblegum-700/30 bg-bubblegum/20 p-4 text-sm text-plum">
      <p className="font-semibold">Oops — {message}</p>
      {onRetry && (
        <Button variant="secondary" size="sm" className="mt-3" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}

export function EmptyState({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="card mx-auto flex max-w-md flex-col items-center gap-3 p-8 text-center">
      <span className="grid h-14 w-14 place-items-center rounded-full bg-lavender-200">
        <Heart className="h-7 w-7 text-bubblegum-600" />
      </span>
      <h2 className="text-xl font-bold">{title}</h2>
      {children && <p className="text-plum-700">{children}</p>}
      {action}
    </div>
  );
}
