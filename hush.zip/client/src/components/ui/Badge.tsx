import type { ReactNode } from 'react';

export function Badge({ children, tone = 'lavender' }: { children: ReactNode; tone?: 'lavender' | 'pink' | 'plum' }) {
  const tones = { lavender: 'bg-lavender-200 text-plum', pink: 'bg-bubblegum/40 text-plum', plum: 'bg-plum text-white' };
  return <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-bold ${tones[tone]}`}>{children}</span>;
}
