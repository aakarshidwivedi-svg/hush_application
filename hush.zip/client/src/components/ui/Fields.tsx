import { useId, type InputHTMLAttributes, type ReactNode, type TextareaHTMLAttributes } from 'react';

const control =
  'w-full rounded-2xl border-0 bg-white px-4 py-3 text-plum shadow-sm ring-1 ring-plum/15 placeholder:text-plum-500/70 focus-visible:ring-2 focus-visible:ring-lavender-700 aria-[invalid=true]:ring-2 aria-[invalid=true]:ring-bubblegum-700';

interface Common {
  label: string;
  hint?: ReactNode;
  error?: string | undefined;
}

export function Field({ label, hint, error, className = '', ...rest }: Common & InputHTMLAttributes<HTMLInputElement>) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-bold">
        {label}
      </label>
      <input id={id} className={control} aria-invalid={!!error} aria-describedby={`${id}-d`} {...rest} />
      <p id={`${id}-d`} className={`mt-1.5 text-sm ${error ? 'font-semibold text-bubblegum-700' : 'text-plum-700'}`} role={error ? 'alert' : undefined}>
        {error ?? hint}
      </p>
    </div>
  );
}

export function TextArea({ label, hint, error, className = '', ...rest }: Common & TextareaHTMLAttributes<HTMLTextAreaElement>) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-bold">
        {label}
      </label>
      <textarea id={id} rows={4} className={`${control} resize-y`} aria-invalid={!!error} aria-describedby={`${id}-d`} {...rest} />
      <p id={`${id}-d`} className={`mt-1.5 text-sm ${error ? 'font-semibold text-bubblegum-700' : 'text-plum-700'}`} role={error ? 'alert' : undefined}>
        {error ?? hint}
      </p>
    </div>
  );
}

export function Select({ label, error, children, className = '', ...rest }: Common & React.SelectHTMLAttributes<HTMLSelectElement>) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-bold">
        {label}
      </label>
      <select id={id} className={control} aria-invalid={!!error} {...rest}>
        {children}
      </select>
      {error && (
        <p role="alert" className="mt-1.5 text-sm font-semibold text-bubblegum-700">
          {error}
        </p>
      )}
    </div>
  );
}

export function Toggle({ label, description, checked, onChange }: { label: string; description?: string; checked: boolean; onChange: (v: boolean) => void }) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <label htmlFor={id} className="font-bold">
          {label}
        </label>
        {description && <p className="text-sm text-plum-700">{description}</p>}
      </div>
      <button
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative mt-1 h-7 w-12 shrink-0 rounded-full transition ${checked ? 'bg-lavender-700' : 'bg-plum/25'}`}
      >
        <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-all ${checked ? 'left-[1.375rem]' : 'left-0.5'}`} />
      </button>
    </div>
  );
}
