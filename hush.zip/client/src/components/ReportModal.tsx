import { useState } from 'react';
import { api, ApiError } from '../services/api';
import type { ReportReason } from '../types';
import { Button } from './ui/Button';
import { Select, TextArea } from './ui/Fields';
import { Modal } from './ui/Modal';
import { ErrorMessage } from './ui/States';

const REASONS: { value: ReportReason; label: string }[] = [
  { value: 'HARASSMENT', label: 'Harassment or bullying' },
  { value: 'INAPPROPRIATE_CONTENT', label: 'Inappropriate content' },
  { value: 'FAKE_PROFILE', label: 'Fake or impersonating profile' },
  { value: 'SPAM', label: 'Spam or scams' },
  { value: 'UNDERAGE', label: 'May be under 18' },
  { value: 'OTHER', label: 'Something else' },
];

export function ReportModal({ target, onClose }: { target: { id: string; nickname: string } | null; onClose: () => void }) {
  const [reason, setReason] = useState<ReportReason>('HARASSMENT');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const close = () => {
    setDone(false);
    setError(null);
    setDetails('');
    onClose();
  };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!target) return;
    setBusy(true);
    setError(null);
    try {
      await api.report({ targetId: target.id, reason, ...(details.trim() ? { details: details.trim() } : {}) });
      setDone(true);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not send your report');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={target !== null} onClose={close} title={done ? 'Report received' : `Report ${target?.nickname ?? ''}`}>
      {done ? (
        <div className="space-y-4">
          <p className="text-plum-700">Thank you. Our moderators will review this. You can also block this person so they can no longer interact with you.</p>
          <Button onClick={close} className="w-full">Done</Button>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <Select label="What's going on?" value={reason} onChange={(e) => setReason(e.target.value as ReportReason)}>
            {REASONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
          </Select>
          <TextArea label="Details (optional)" value={details} maxLength={1000} onChange={(e) => setDetails(e.target.value)} hint={`${details.length}/1000 — reports are read only by moderators.`} />
          {error && <ErrorMessage message={error} />}
          <div className="flex gap-3">
            <Button variant="secondary" onClick={close} className="flex-1">Cancel</Button>
            <Button type="submit" loading={busy} className="flex-1">Send report</Button>
          </div>
        </form>
      )}
    </Modal>
  );
}
