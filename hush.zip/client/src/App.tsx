import { Route, Routes, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { captureInviteFromUrl } from './lib/invite';
import { ProtectedRoute, PublicOnlyRoute } from './routes/ProtectedRoute';
import { Login, Signup } from './pages/Auth';
import Chat from './pages/Chat';
import Discover from './pages/Discover';
import Landing from './pages/Landing';
import { Contact, Guidelines, Privacy, Terms } from './pages/Legal';
import Matches from './pages/Matches';
import Moderation from './pages/Moderation';
import ModerationReport from './pages/ModerationReport';
import { ModeratorRoute } from './components/ModeratorRoute';
import Notifications from './pages/Notifications';
import Onboarding from './pages/Onboarding';
import Settings from './pages/Settings';
import { Heart } from './components/Illustrations';
import { LinkButton } from './components/ui/Button';

function NotFound() {
  return (
    <div className="page grid min-h-[50vh] place-items-center text-center">
      <div>
        <Heart className="mx-auto h-12 w-12 text-bubblegum" />
        <h1 className="mt-3 text-4xl font-bold">Page not found</h1>
        <p className="mb-5 mt-2 text-plum-700">That page doesn&rsquo;t exist, or you may not have access to it.</p>
        <LinkButton to="/">Go home</LinkButton>
      </div>
    </div>
  );
}

captureInviteFromUrl(); // remember ?invite=CODE from a friend's link before any redirect can drop it

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Landing />} />
        <Route path="terms" element={<Terms />} />
        <Route path="privacy" element={<Privacy />} />
        <Route path="guidelines" element={<Guidelines />} />
        <Route path="contact" element={<Contact />} />
        <Route element={<PublicOnlyRoute />}>
          <Route path="login" element={<Login />} />
          <Route path="signup" element={<Signup />} />
        </Route>
        <Route element={<ProtectedRoute allow="onboarding" />}>
          <Route path="onboarding" element={<Onboarding />} />
        </Route>
        <Route element={<ProtectedRoute />}>
          <Route path="discover" element={<Discover />} />
          <Route path="matches" element={<Matches />} />
          <Route path="matches/:matchId" element={<Chat />} />
          <Route path="notifications" element={<Notifications />} />
        </Route>
        <Route element={<ProtectedRoute allowIncomplete />}>
          <Route path="settings" element={<Settings />} />
        </Route>
        <Route element={<ModeratorRoute />}>
          <Route path="moderation" element={<Moderation />} />
          <Route path="moderation/reports/:id" element={<ModerationReport />} />
        </Route>
        <Route path="home" element={<Navigate to="/" replace />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
