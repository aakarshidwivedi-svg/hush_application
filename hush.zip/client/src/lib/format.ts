export const fmtDateTime = (iso: string) =>
  new Date(iso).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });

export const REASON_LABEL: Record<string, string> = {
  HARASSMENT: 'Harassment',
  SPAM: 'Spam',
  FAKE_PROFILE: 'Fake profile',
  INAPPROPRIATE_CONTENT: 'Inappropriate content',
  UNDERAGE: 'May be under 18',
  OTHER: 'Other',
};

export const STATUS_LABEL: Record<string, string> = {
  OPEN: 'Open',
  REVIEWING: 'Reviewing',
  ACTIONED: 'Actioned',
  DISMISSED: 'Dismissed',
};

export const ACTION_LABEL: Record<string, string> = {
  REPORT_REVIEWING: 'Marked under review',
  REPORT_ACTIONED: 'Report actioned',
  REPORT_DISMISSED: 'Report dismissed',
  SUSPEND: 'Suspended account',
  REINSTATE: 'Reinstated account',
  VERIFY_AGE: 'Verified age',
  VERIFY_CAMPUS: 'Verified campus',
};
