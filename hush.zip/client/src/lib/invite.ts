/**
 * Invite links: https://<site>/?invite=ABCDEFGHJK. The code is remembered in this browser until the person finishes
 * onboarding, so it survives sign-up, email confirmation and the Google redirect. It is only a hint for the server,
 * which ignores unknown codes; nothing here reveals who owns a code.
 */
const KEY = 'hush:invite';
export const INVITE_RE = /^[A-Z2-7]{10}$/;

export const normaliseInvite = (raw: unknown): string | null => {
  if (typeof raw !== 'string') return null;
  const c = raw.trim().toUpperCase();
  return INVITE_RE.test(c) ? c : null;
};

export function storedInvite(): string | null {
  try { return normaliseInvite(localStorage.getItem(KEY)); } catch { return null; }
}

export function clearInvite(): void {
  try { localStorage.removeItem(KEY); } catch { /* storage unavailable */ }
}

/** Remember a valid `?invite=` code and take it out of the address bar. Safe to call on every page load. */
export function captureInviteFromUrl(): void {
  try {
    const url = new URL(window.location.href);
    const code = normaliseInvite(url.searchParams.get('invite'));
    if (!url.searchParams.has('invite')) return;
    if (code) localStorage.setItem(KEY, code);
    url.searchParams.delete('invite');
    window.history.replaceState(null, '', url.pathname + (url.search || '') + url.hash);
  } catch { /* ignore */ }
}

export const inviteLink = (code: string): string => `${window.location.origin}/?invite=${code}`;
