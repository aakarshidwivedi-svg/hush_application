/**
 * Client-side image checks and compression. These make uploads fast and give friendly errors early,
 * but they are conveniences only: the server re-checks the real bytes, size and dimensions and
 * re-encodes every image, so nothing here is a security control.
 */
export const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp'] as const;
export const MAX_INPUT_BYTES = 20 * 1024 * 1024; // what we are willing to decode in the browser
export const MAX_UPLOAD_BYTES = 6 * 1024 * 1024; // the API's raw upload ceiling
export const MIN_SIDE = 300; // same minimum as the API
export const MAX_PHOTOS = 6;
const BOX = { width: 1280, height: 1600 }; // same box the API resizes into

export class ImageError extends Error {}

export interface PreparedImage {
  blob: Blob;
  previewUrl: string; // object URL — revoke with URL.revokeObjectURL when done
  width: number;
  height: number;
}

function decode(file: Blob): Promise<{ source: CanvasImageSource; width: number; height: number; close: () => void }> {
  // createImageBitmap honours EXIF orientation with imageOrientation: 'from-image'.
  if (typeof createImageBitmap === 'function') {
    return createImageBitmap(file, { imageOrientation: 'from-image' }).then(
      (bmp) => ({ source: bmp, width: bmp.width, height: bmp.height, close: () => bmp.close() }),
      () => { throw new ImageError("That image couldn't be read. Try a different file."); },
    );
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => resolve({ source: img, width: img.naturalWidth, height: img.naturalHeight, close: () => URL.revokeObjectURL(url) });
    img.onerror = () => { URL.revokeObjectURL(url); reject(new ImageError("That image couldn't be read. Try a different file.")); };
    img.src = url;
  });
}

function toBlob(canvas: HTMLCanvasElement, type: string, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob(resolve, type, quality));
}

/** Validate type, size and dimensions, then resize to the API's box and re-encode (WebP, or JPEG where WebP is unsupported). */
export async function prepareImage(file: File): Promise<PreparedImage> {
  if (!(ACCEPTED_TYPES as readonly string[]).includes(file.type)) {
    throw new ImageError('Only JPEG, PNG and WebP photos are accepted.');
  }
  if (file.size > MAX_INPUT_BYTES) throw new ImageError('That photo is too large. Choose one under 20 MB.');
  const img = await decode(file);
  try {
    if (Math.min(img.width, img.height) < MIN_SIDE) {
      throw new ImageError(`Photos must be at least ${MIN_SIDE}×${MIN_SIDE} pixels. This one is ${img.width}×${img.height}.`);
    }
    const scale = Math.min(1, BOX.width / img.width, BOX.height / img.height);
    const w = Math.max(1, Math.round(img.width * scale));
    const h = Math.max(1, Math.round(img.height * scale));
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new ImageError("Your browser couldn't process this photo.");
    ctx.drawImage(img.source, 0, 0, w, h);
    let blob = await toBlob(canvas, 'image/webp', 0.85);
    if (!blob || blob.type !== 'image/webp') blob = await toBlob(canvas, 'image/jpeg', 0.88); // browsers without WebP encoding
    if (!blob) throw new ImageError("Your browser couldn't process this photo.");
    if (blob.size > MAX_UPLOAD_BYTES) throw new ImageError('That photo is still too large after compression. Try a smaller one.');
    return { blob, previewUrl: URL.createObjectURL(blob), width: w, height: h };
  } finally {
    img.close();
  }
}
