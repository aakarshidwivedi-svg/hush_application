import type { Session } from '@supabase/supabase-js';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { api, ApiError } from '../services/api';
import { supabase } from '../services/supabase';
import type { Me } from '../types';

export type AuthStatus = 'loading' | 'anonymous' | 'needs-onboarding' | 'ready' | 'error';

interface AuthValue {
  status: AuthStatus;
  session: Session | null;
  me: Me | null;
  error: string | null;
  refresh: () => Promise<void>;
  setMe: (m: Me) => void;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [status, setStatus] = useState<AuthStatus>('loading');
  const [error, setError] = useState<string | null>(null);
  const sessionRef = useRef<Session | null>(null);

  const loadProfile = useCallback(async (s: Session | null) => {
    sessionRef.current = s;
    setSession(s);
    if (!s) {
      setMe(null);
      setStatus('anonymous');
      return;
    }
    try {
      setMe(await api.me());
      setError(null);
      setStatus('ready');
    } catch (e) {
      if (e instanceof ApiError && e.code === 'ONBOARDING_REQUIRED') {
        setMe(null);
        setStatus('needs-onboarding');
      } else if (e instanceof ApiError && e.status === 401) {
        // The API rejected the token (expired, revoked, or a deleted account): end the session.
        await supabase.auth.signOut();
      } else {
        setError(e instanceof Error ? e.message : 'Something went wrong');
        setStatus('error');
      }
    }
  }, []);

  useEffect(() => {
    let alive = true;
    void supabase.auth.getSession().then(({ data }) => {
      if (alive) void loadProfile(data.session);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      // Token refreshes keep the same user; no need to reload the profile.
      if (event === 'TOKEN_REFRESHED' && sessionRef.current?.user.id === s?.user.id) return;
      if (event === 'INITIAL_SESSION') return;
      void loadProfile(s);
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const value = useMemo<AuthValue>(
    () => ({
      status,
      session,
      me,
      error,
      refresh: () => loadProfile(sessionRef.current),
      setMe: (m) => {
        setMe(m);
        setStatus('ready');
      },
      signOut: async () => {
        await supabase.auth.signOut();
      },
    }),
    [status, session, me, error, loadProfile],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside <AuthProvider>');
  return v;
}
