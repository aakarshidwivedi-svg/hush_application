import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { api } from '../services/api';
import type { AppNotification } from '../types';
import { useAuth } from './useAuth';
import { useRealtime, useSocketEvent } from './useRealtime';

interface NotificationsValue {
  /** Unread notifications, newest first. */
  items: AppNotification[];
  unreadCount: number;
  refresh: () => Promise<void>;
  markRead: (sel?: { ids?: string[]; type?: 'MATCH' | 'MESSAGE' }) => Promise<void>;
}
const Ctx = createContext<NotificationsValue | null>(null);

/**
 * The inbox. Live updates arrive over the socket (`notifications:changed`); a slow poll remains as the
 * safety net, and speeds up whenever the socket is down. Reads are optimistic and re-synced from the server.
 */
export function NotificationsProvider({ children }: { children: ReactNode }) {
  const { status, me } = useAuth();
  const { connected } = useRealtime();
  const [items, setItems] = useState<AppNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const enabled = status === 'ready' && me?.account.eligible === true;

  const refresh = useCallback(async () => {
    if (document.hidden) return;
    try {
      const r = await api.notifications('unread');
      setItems(r.items);
      setUnreadCount(r.unreadCount);
    } catch {
      /* transient: the next tick or event tries again */
    }
  }, []);

  useEffect(() => {
    if (!enabled) { setItems([]); setUnreadCount(0); return; }
    void refresh();
    const t = window.setInterval(refresh, connected ? 60_000 : 15_000);
    const onVisible = () => void refresh();
    document.addEventListener('visibilitychange', onVisible);
    // Sending a crush may complete a match; check right away so the celebration is instant.
    window.addEventListener('hush:crush', onVisible);
    return () => {
      window.clearInterval(t);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('hush:crush', onVisible);
    };
  }, [enabled, connected, refresh]);

  // Anything that happened while the socket was down is picked up as soon as it is back.
  useEffect(() => { if (enabled && connected) void refresh(); }, [enabled, connected, refresh]);
  useSocketEvent('notifications:changed', () => void refresh());

  const markRead = useCallback(async (sel: { ids?: string[]; type?: 'MATCH' | 'MESSAGE' } = {}) => {
    if (sel.ids && sel.ids.length === 0) return;
    const hit = (n: AppNotification) => (!sel.ids || sel.ids.includes(n.id)) && (!sel.type || n.type === sel.type);
    setItems((prev) => prev.filter((n) => !hit(n)));
    setUnreadCount((c) => Math.max(0, c - items.filter(hit).length));
    try {
      await api.markNotificationsRead(sel);
    } catch {
      /* reappears on the next refresh if it did not go through */
    }
    void refresh();
  }, [items, refresh]);

  const value = useMemo(() => ({ items, unreadCount, refresh, markRead }), [items, unreadCount, refresh, markRead]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useNotifications(): NotificationsValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useNotifications must be used inside <NotificationsProvider>');
  return v;
}
