import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { io, type Socket } from 'socket.io-client';
import { BASE } from '../services/api';
import { supabase } from '../services/supabase';
import { useAuth } from './useAuth';

interface RealtimeValue {
  socket: Socket | null;
  /** True while the live connection is up. When false the app falls back to periodic refreshes. */
  connected: boolean;
}
const Ctx = createContext<RealtimeValue>({ socket: null, connected: false });

/** The socket server lives on the API's origin. */
const SOCKET_ORIGIN = new URL(BASE, window.location.href).origin;
/** Codes the server sends when it will never accept this account (retrying would be pointless). */
const FINAL = new Set(['NOT_ELIGIBLE']);

/**
 * One live connection per signed-in, eligible person. The access token is fetched fresh for every
 * (re)connect, so a refreshed session is picked up automatically. This is a convenience layer: if the
 * connection is down, pages keep working through the normal REST endpoints and periodic refreshes.
 */
export function RealtimeProvider({ children }: { children: ReactNode }) {
  const { status, me } = useAuth();
  const enabled = status === 'ready' && me?.account.eligible === true;
  const [socket, setSocket] = useState<Socket | null>(null);
  const [connected, setConnected] = useState(false);
  const retry = useRef<number>();

  useEffect(() => {
    if (!enabled) return;
    let stopped = false;
    let attempts = 0;
    const s = io(SOCKET_ORIGIN, {
      path: '/socket.io',
      transports: ['websocket', 'polling'],
      auth: (cb) => {
        void supabase.auth.getSession().then(({ data }) => cb({ token: data.session?.access_token ?? '' }));
      },
      reconnectionDelayMax: 15_000,
    });
    const later = (ms: number) => {
      window.clearTimeout(retry.current);
      retry.current = window.setTimeout(() => !stopped && s.connect(), ms);
    };
    s.on('connect', () => { attempts = 0; setConnected(true); });
    s.on('disconnect', (reason) => {
      setConnected(false);
      // The server ended it (token expired, account changed): reconnect with a fresh token. If the
      // account is no longer allowed, the handshake is refused and `connect_error` stops the retries.
      if (reason === 'io server disconnect') later(1000);
    });
    s.on('connect_error', (err: Error & { data?: { code?: string } }) => {
      setConnected(false);
      if (err.data?.code && FINAL.has(err.data.code)) return;
      attempts += 1;
      later(Math.min(30_000, 1000 * 2 ** Math.min(attempts, 5))); // middleware refusals are not auto-retried by socket.io
    });
    setSocket(s);
    return () => {
      stopped = true;
      window.clearTimeout(retry.current);
      s.close();
      setSocket(null);
      setConnected(false);
    };
  }, [enabled]);

  const value = useMemo(() => ({ socket, connected }), [socket, connected]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useRealtime = () => useContext(Ctx);

/** Subscribe to a server event for as long as the component is mounted. */
export function useSocketEvent<T = unknown>(event: string, handler: (payload: T) => void): void {
  const { socket } = useRealtime();
  const ref = useRef(handler);
  ref.current = handler;
  useEffect(() => {
    if (!socket) return;
    const h = (p: T) => ref.current(p);
    socket.on(event, h);
    return () => void socket.off(event, h);
  }, [socket, event]);
}
