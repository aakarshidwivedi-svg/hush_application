import { useEffect, useState } from 'react';
import { api, ApiError } from '../services/api';
import { useAuth } from './useAuth';

const cache = new Map<string, Promise<boolean>>();

/**
 * Asks the server whether the signed-in person is a moderator. This only decides whether to *show*
 * the dashboard link; every /moderation/* request is authorised again on the server, which answers
 * 404 to anyone who is not on the moderator list. Nothing here is a security boundary.
 */
export function useModerator(): boolean | null {
  const { session, status } = useAuth();
  const uid = session?.user.id ?? null;
  const [value, setValue] = useState<boolean | null>(null);

  useEffect(() => {
    if (!uid || (status !== 'ready' && status !== 'needs-onboarding')) {
      setValue(uid ? null : false);
      return;
    }
    let alive = true;
    let p = cache.get(uid);
    if (!p) {
      p = api.modMe().then(
        () => true,
        (e: unknown) => {
          if (!(e instanceof ApiError) || e.status !== 404) cache.delete(uid); // transient failure: ask again later
          return false;
        },
      );
      cache.set(uid, p);
    }
    void p.then((v) => alive && setValue(v));
    return () => { alive = false; };
  }, [uid, status]);

  return value;
}
