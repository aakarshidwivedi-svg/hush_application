import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ReasonModal } from '../components/ReasonModal';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { ErrorMessage, PageLoader } from '../components/ui/States';
import { useAsync } from '../hooks/useAsync';
import { ACTION_LABEL, REASON_LABEL, STATUS_LABEL, fmtDateTime } from '../lib/format';
import { api, ApiError } from '../services/api';
import type { ModUserAction } from '../types';

type Pending =
  | { kind: 'review'; status: 'ACTIONED' | 'DISMISSED' }
  | { kind: 'user'; action: ModUserAction };

const COPY: Record<string, { title: string; body: string; confirm: string; done: string }> = {
  'review:DISMISSED': { title: 'Dismiss this report?', body: 'Nothing will change for the reported person. The report is closed and your reason is logged.', confirm: 'Dismiss report', done: 'Report dismissed.' },
  'review:ACTIONED': { title: 'Mark this report as actioned?', body: 'Use this once you have taken the steps the report called for. Your reason is logged.', confirm: 'Mark actioned', done: 'Report marked as actioned.' },
  'user:suspend': { title: 'Suspend this account?', body: 'They are signed out of live chat, hidden from Discover, and their matches stop working until you reinstate them.', confirm: 'Suspend account', done: 'Account suspended.' },
  'user:reinstate': { title: 'Reinstate this account?', body: 'The person can use Hush again, and their active matches resume.', confirm: 'Reinstate account', done: 'Account reinstated.' },
  'user:verify-campus': { title: 'Verify this person’s campus?', body: 'Only do this after you have confirmed they belong to the campus they chose.', confirm: 'Verify campus', done: 'Campus verified.' },
  'user:verify-age': { title: 'Mark age as verified?', body: 'Only do this after you have checked their age off-platform.', confirm: 'Verify age', done: 'Age marked as verified.' },
};
const keyOf = (p: Pending) => (p.kind === 'review' ? `review:${p.status}` : `user:${p.action}`);

function Fact({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-sm font-bold text-plum-700">{label}</dt>
      <dd className="font-semibold">{children}</dd>
    </div>
  );
}

export default function ModerationReport() {
  const { id = '' } = useParams();
  const detail = useAsync(() => api.modReport(id), [id]);
  const [pending, setPending] = useState<Pending | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  if (detail.loading && !detail.data) return <PageLoader label="Loading report…" />;
  if (detail.error || !detail.data) {
    return (
      <div className="page py-10 space-y-4">
        <ErrorMessage message={detail.error ?? 'Report not found'} onRetry={() => void detail.reload()} />
        <Link to="/moderation" className="font-bold underline">Back to reports</Link>
      </div>
    );
  }

  const { report, history } = detail.data;
  const t = report.target;
  const closed = report.status === 'ACTIONED' || report.status === 'DISMISSED';
  const live = t.accountStatus !== 'DELETED';

  async function run(p: Pending, reason?: string) {
    setBusy(true);
    setError(null);
    try {
      if (p.kind === 'review') await api.modReview(report.id, { status: p.status, ...(reason ? { note: reason } : {}) });
      else await api.modUser(t.id, p.action, { reason: reason!, reportId: report.id });
      setPending(null);
      setNotice(COPY[keyOf(p)]!.done);
      await detail.reload();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'That did not work. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  const copy = pending ? COPY[keyOf(pending)]! : null;

  return (
    <div className="page py-8">
      <Link to="/moderation" className="text-sm font-bold underline">← All reports</Link>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <h1 className="text-3xl font-bold">{REASON_LABEL[report.reason] ?? report.reason}</h1>
        <Badge tone={report.status === 'OPEN' ? 'pink' : report.status === 'REVIEWING' ? 'lavender' : 'plum'}>{STATUS_LABEL[report.status]}</Badge>
      </div>
      <p className="mt-1 text-plum-700">Filed {fmtDateTime(report.createdAt)} by {report.reporter.nickname ?? 'a deleted profile'}</p>

      <div role="status" aria-live="polite" className="mt-4">
        {notice && <p className="rounded-2xl bg-lavender-200 p-3 font-semibold">{notice}</p>}
      </div>

      <div className="mt-4 grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <div className="space-y-5">
          <section className="card p-5" aria-labelledby="det-h">
            <h2 id="det-h" className="mb-2 text-xl font-bold">What was reported</h2>
            <p className="whitespace-pre-wrap rounded-2xl bg-cream p-3">{report.details ?? 'No details were provided.'}</p>
            {report.resolutionNote && (
              <p className="mt-3 text-sm text-plum-700">
                {STATUS_LABEL[report.status]} {report.reviewedAt ? fmtDateTime(report.reviewedAt) : ''} by <code>{report.reviewedBy}</code>: “{report.resolutionNote}”
              </p>
            )}
          </section>

          <section className="card p-5" aria-labelledby="tgt-h">
            <h2 id="tgt-h" className="mb-3 text-xl font-bold">Reported person</h2>
            <dl className="grid grid-cols-2 gap-4">
              <Fact label="Nickname">{t.nickname ?? '—'}</Fact>
              <Fact label="Account">{t.accountStatus === 'ACTIVE' ? 'Active' : t.accountStatus === 'SUSPENDED' ? 'Suspended' : 'Deleted'}</Fact>
              <Fact label="Campus">{t.campusStatus === 'VERIFIED' ? 'Verified' : 'Unverified'}</Fact>
              <Fact label="Age">{t.ageStatus === 'VERIFIED' ? 'Verified' : t.ageStatus === 'SELF_ATTESTED' ? 'Self-attested' : 'Unverified'}</Fact>
              <Fact label="Reports received">{t.reportsReceived}</Fact>
              <Fact label="Blocked by">{t.blockedByCount} {t.blockedByCount === 1 ? 'person' : 'people'}</Fact>
            </dl>
            {t.bio && <p className="mt-4 whitespace-pre-wrap rounded-2xl bg-cream p-3 text-sm">{t.bio}</p>}
          </section>
        </div>

        <div className="space-y-5">
          <section className="card p-5" aria-labelledby="act-h">
            <h2 id="act-h" className="mb-3 text-xl font-bold">Actions</h2>
            <div className="flex flex-col gap-2">
              {report.status === 'OPEN' && (
                <Button
                  variant="secondary"
                  loading={busy && !pending}
                  onClick={async () => {
                    setBusy(true); setError(null);
                    try { await api.modReview(report.id, { status: 'REVIEWING' }); setNotice('Marked as under review.'); await detail.reload(); }
                    catch (e) { setError(e instanceof ApiError ? e.message : 'That did not work. Please try again.'); }
                    finally { setBusy(false); }
                  }}
                >
                  Start review
                </Button>
              )}
              {!closed && <Button variant="secondary" onClick={() => { setError(null); setPending({ kind: 'review', status: 'DISMISSED' }); }}>Dismiss report</Button>}
              {!closed && <Button variant="secondary" onClick={() => { setError(null); setPending({ kind: 'review', status: 'ACTIONED' }); }}>Mark actioned</Button>}
              {live && t.accountStatus === 'ACTIVE' && <Button onClick={() => { setError(null); setPending({ kind: 'user', action: 'suspend' }); }}>Suspend account</Button>}
              {live && t.accountStatus === 'SUSPENDED' && <Button onClick={() => { setError(null); setPending({ kind: 'user', action: 'reinstate' }); }}>Reinstate account</Button>}
              {live && t.campusStatus !== 'VERIFIED' && <Button variant="secondary" onClick={() => { setError(null); setPending({ kind: 'user', action: 'verify-campus' }); }}>Verify campus</Button>}
              {live && t.ageStatus !== 'VERIFIED' && <Button variant="secondary" onClick={() => { setError(null); setPending({ kind: 'user', action: 'verify-age' }); }}>Verify age</Button>}
              {!live && closed && <p className="text-sm text-plum-700">This account was deleted and this report is closed. Nothing more to do.</p>}
            </div>
            {error && !pending && <div className="mt-3"><ErrorMessage message={error} /></div>}
          </section>

          <section className="card p-5" aria-labelledby="hist-h">
            <h2 id="hist-h" className="mb-3 text-xl font-bold">Decision history</h2>
            {history.length === 0 ? <p className="text-plum-700">No decisions recorded for this person yet.</p> : (
              <ol className="space-y-3">
                {history.map((h) => (
                  <li key={h.id} className="text-sm">
                    <p className="font-bold">{ACTION_LABEL[h.action] ?? h.action}</p>
                    <p className="text-plum-700">{fmtDateTime(h.createdAt)} · <code>{h.moderator}</code></p>
                    <p>“{h.reason}”</p>
                  </li>
                ))}
              </ol>
            )}
          </section>
        </div>
      </div>

      <ReasonModal
        open={pending !== null}
        title={copy?.title ?? ''}
        body={copy?.body ?? ''}
        confirmLabel={copy?.confirm ?? ''}
        busy={busy}
        error={error}
        onClose={() => setPending(null)}
        onConfirm={(reason) => pending && void run(pending, reason)}
      />
    </div>
  );
}
