import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';

/** Replace before launch: the address that receives user and legal contact. */
export const CONTACT_EMAIL = 'hello@hush.example';

function Doc({ title, children }: { title: string; children: ReactNode }) {
  return (
    <article className="page max-w-3xl py-12">
      <h1 className="text-4xl font-bold">{title}</h1>
      <p className="mt-2 rounded-2xl bg-lavender-200 px-4 py-2 text-sm font-semibold">Draft for the operator to review with legal counsel before launch. Last updated: October 2026.</p>
      <div className="mt-6 space-y-4 text-plum-700 [&_h2]:mt-8 [&_h2]:text-2xl [&_h2]:font-bold [&_h2]:text-plum [&_li]:ml-5 [&_li]:list-disc [&_strong]:text-plum">{children}</div>
    </article>
  );
}

export function Terms() {
  return (
    <Doc title="Terms of Service">
      <h2>Who can use Hush</h2>
      <p>Hush is for people aged 18 or older who belong to a participating campus community. You must give accurate information and keep one account only.</p>
      <h2>How Hush works</h2>
      <p>You can send secret crushes. We tell no one about a crush unless the other person has also sent you one, in which case you both become a match and can chat.</p>
      <h2>Your responsibilities</h2>
      <ul><li>Follow the <Link to="/guidelines" className="underline">Community Guidelines</Link>.</li><li>Do not harass, impersonate, spam or share anyone&rsquo;s private information.</li><li>Do not attempt to learn who has sent you a crush by any means other than a mutual match.</li></ul>
      <h2>Moderation</h2>
      <p>We may suspend or remove accounts that break these terms or put others at risk. You can delete your account at any time in Settings.</p>
      <h2>No guarantees</h2>
      <p>Hush is provided &ldquo;as is&rdquo;. We cannot promise matches, and we cannot verify every person&rsquo;s claims. Use good judgment when meeting anyone.</p>
      <h2>Contact</h2>
      <p>Questions: <a className="underline" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>.</p>
    </Doc>
  );
}

export function Privacy() {
  return (
    <Doc title="Privacy Policy">
      <p><strong>Hush cannot promise absolute anonymity.</strong> Here is exactly what we store and who can see it.</p>
      <h2>What we store</h2>
      <ul>
        <li><strong>Account:</strong> your email address and sign-in credentials are held by our authentication provider (Supabase). We keep an internal account id, your campus, and your verification and account status.</li>
        <li><strong>Profile:</strong> nickname, bio, interests, optional picture link and your discoverability choice.</li>
        <li><strong>Crushes:</strong> the secret crushes you send are stored privately until they become a match, you withdraw them, or you delete your account. When a match is created, the crush records for that pair are deleted.</li>
        <li><strong>Matches and messages:</strong> who matched, and the messages you exchange. Messages are not end-to-end encrypted.</li>
        <li><strong>Safety records:</strong> blocks, and reports you file or that are filed about you.</li>
        <li><strong>Technical logs:</strong> request method, path and status. We do not log message text, request bodies or access tokens.</li>
      </ul>
      <h2>Who can see it</h2>
      <ul>
        <li><strong>Other students:</strong> only your nickname, bio, interests and optional picture. Never your email, campus verification or crushes. Other students never see who has sent them a crush, or how many.</li>
        <li><strong>Moderators:</strong> reports, including the reporter, the person reported and any details written. Access is limited to authorised reviewers.</li>
        <li><strong>Operators with database access:</strong> because crushes must be stored to detect mutual interest, people who administer our systems can technically access them. We limit this access.</li>
      </ul>
      <h2>Verification</h2>
      <p>We check that your verified email belongs to your campus. A campus email alone does not prove your age or enrollment, so campuses may require an additional age check done by a moderator. Verification details are kept private.</p>
      <h2>How reports are handled</h2>
      <p>Reports go to moderators, who may dismiss them, warn, suspend or remove an account. The person reported is not told who reported them.</p>
      <h2>Deleting your data and retention</h2>
      <p>When you delete your account we immediately erase your profile, conversations, crushes, notifications and blocks, and end your matches. A minimal placeholder record (an internal id, your campus and the deletion date) remains so safety reports stay intact and the same account cannot silently re-register. Reports about or by a deleted account are kept for <strong>90 days after they are resolved</strong>, then the placeholder and those reports are permanently deleted. Open reports are kept until resolved. Deleting your Hush account does not delete your authentication-provider record: ask us to remove it at <a className="underline" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>.</p>
    </Doc>
  );
}

export function Guidelines() {
  return (
    <Doc title="Community Guidelines">
      <p>Hush works because people feel safe. Please be kind, honest and respectful.</p>
      <h2>Do</h2>
      <ul><li>Use a nickname and photo that represent you.</li><li>Respect a &ldquo;no&rdquo; — unmatching, ignoring or blocking is always okay.</li><li>Report anything that makes you uncomfortable.</li></ul>
      <h2>Don&rsquo;t</h2>
      <ul><li>Harass, threaten, bully or pressure anyone.</li><li>Share sexual content without consent, or any content involving minors.</li><li>Impersonate others or run fake profiles.</li><li>Spam, advertise or run scams.</li><li>Share someone else&rsquo;s private information, or screenshots of their chats, without consent.</li></ul>
      <h2>If something goes wrong</h2>
      <p><strong>Block</strong> to end all contact. <strong>Unmatch</strong> to end a conversation. <strong>Report</strong> to alert moderators. If you are in danger, contact local emergency services or campus security first.</p>
    </Doc>
  );
}

export function Contact() {
  return (
    <Doc title="Contact us">
      <p>We&rsquo;re happy to help with account questions, privacy requests and safety concerns.</p>
      <ul><li>General and privacy requests: <a className="underline" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></li><li>Safety: use the in-app <strong>Report</strong> button so moderators can act quickly.</li></ul>
    </Doc>
  );
}
