import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ConfirmModal } from '../components/ConfirmModal';
import { ProfileCard } from '../components/ProfileCard';
import { LinkButton } from '../components/ui/Button';
import { CardSkeleton, EmptyState, ErrorMessage } from '../components/ui/States';
import { Badge } from '../components/ui/Badge';
import { useAsync } from '../hooks/useAsync';
import { useSocketEvent } from '../hooks/useRealtime';
import { api } from '../services/api';
import type { MatchView } from '../types';

export default function Matches() {
  const matches = useAsync(() => api.matches(), []);
  const [unmatching, setUnmatching] = useState<MatchView | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { reload } = matches;

  // A new match celebration (mounted globally) tells us to refresh the list.
  useEffect(() => {
    const h = () => void reload();
    window.addEventListener('hush:match', h);
    return () => window.removeEventListener('hush:match', h);
  }, [reload]);

  // Live: a new match, an ended conversation or a new message refreshes the list.
  useSocketEvent('matches:changed', () => void reload());
  useSocketEvent('message:new', () => void reload());

  const confirm = useCallback(async () => {
    if (!unmatching) return;
    setBusy(true);
    try {
      await api.unmatch(unmatching.id);
      matches.setData((matches.data ?? []).filter((m) => m.id !== unmatching.id));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not unmatch');
    } finally {
      setBusy(false);
      setUnmatching(null);
    }
  }, [unmatching, matches]);

  return (
    <div className="page py-8">
      <h1 className="text-4xl font-bold">Your matches</h1>
      <p className="mb-6 mt-1 text-plum-700">Everyone here liked you back. Say hello!</p>
      {error && <div className="mb-4"><ErrorMessage message={error} /></div>}
      {matches.loading && !matches.data ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" aria-busy="true">{[0, 1, 2].map((n) => <CardSkeleton key={n} />)}</div>
      ) : matches.error && !matches.data ? (
        <ErrorMessage message={matches.error} onRetry={() => void matches.reload()} />
      ) : (matches.data ?? []).length === 0 ? (
        <EmptyState title="No matches yet" action={<LinkButton to="/discover">Find people</LinkButton>}>
          When you and someone else both send a secret crush, they&rsquo;ll appear here. Keep exploring!
        </EmptyState>
      ) : (
        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {(matches.data ?? []).map((m) => (
            <li key={m.id}>
              <ProfileCard
                size="compact"
                profile={m.partner}
                footer={
                  <div className="space-y-3">
                    {m.unreadCount > 0 && <p><Badge tone="pink">{m.unreadCount} new message{m.unreadCount === 1 ? '' : 's'}</Badge></p>}
                    {m.lastMessage && <p className="truncate rounded-2xl bg-cream px-3 py-2 text-sm text-plum-700">{m.lastMessage.mine ? 'You: ' : ''}{m.lastMessage.preview}</p>}
                    <LinkButton to={`/matches/${m.id}`} className="w-full">{m.lastMessage ? 'Open chat' : 'Start chatting'}</LinkButton>
                    <button type="button" onClick={() => setUnmatching(m)} className="block w-full text-center text-sm font-semibold text-plum-700 hover:underline">Unmatch</button>
                  </div>
                }
              />
            </li>
          ))}
        </ul>
      )}
      <p className="mt-10 text-center text-sm text-plum-700">Something wrong? You can unmatch, block or report from any chat. See our <Link to="/guidelines" className="font-bold underline">Community Guidelines</Link>.</p>
      <ConfirmModal open={unmatching !== null} title={`Unmatch ${unmatching?.partner.nickname ?? ''}?`} body="The conversation will be removed from your matches and you won't be able to message each other. This can't be undone." confirmLabel="Unmatch" busy={busy} onConfirm={() => void confirm()} onClose={() => setUnmatching(null)} />
    </div>
  );
}
