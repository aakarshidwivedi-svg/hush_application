import { Link } from 'react-router-dom';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { EmptyState, ErrorMessage, Skeleton } from '../components/ui/States';
import { useAsync } from '../hooks/useAsync';
import { useNotifications } from '../hooks/useNotifications';
import { useSocketEvent } from '../hooks/useRealtime';
import { fmtDateTime } from '../lib/format';
import { api } from '../services/api';
import type { AppNotification } from '../types';

function text(n: AppNotification): string {
  if (n.type === 'MATCH') return `You and ${n.partner.nickname} matched!`;
  return n.count === 1 ? `${n.partner.nickname} sent you a new message` : `${n.partner.nickname} sent you ${n.count} new messages`;
}

export default function Notifications() {
  const list = useAsync(() => api.notifications('all'), []);
  const { refresh, unreadCount } = useNotifications();
  const { reload } = list;
  useSocketEvent('notifications:changed', () => void reload());

  async function readOne(n: AppNotification) {
    if (n.read) return;
    list.setData(list.data && { ...list.data, items: list.data.items.map((x) => (x.id === n.id ? { ...x, read: true } : x)), unreadCount: Math.max(0, list.data.unreadCount - 1) });
    try { await api.markNotificationRead(n.id); } catch { void reload(); }
    void refresh();
  }
  async function readAll() {
    try { await api.markNotificationsRead({}); } finally { await reload(); void refresh(); }
  }

  return (
    <div className="page max-w-2xl py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-4xl font-bold">Notifications</h1>
          <p className="mt-1 text-plum-700" aria-live="polite">{unreadCount === 0 ? 'You’re all caught up.' : `${unreadCount} unread`}</p>
        </div>
        <Button variant="secondary" size="sm" disabled={unreadCount === 0} onClick={() => void readAll()}>Mark all as read</Button>
      </div>

      <div className="mt-6">
        {list.loading && !list.data ? (
          <div className="space-y-3" role="status" aria-label="Loading">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 w-full" />)}</div>
        ) : list.error && !list.data ? (
          <ErrorMessage message={list.error} onRetry={() => void list.reload()} />
        ) : (list.data?.items.length ?? 0) === 0 ? (
          <EmptyState title="Nothing here yet">New matches and messages will show up here.</EmptyState>
        ) : (
          <ul className="space-y-3">
            {list.data!.items.map((n) => (
              <li key={n.id}>
                <Link
                  to={`/matches/${n.matchId}`}
                  onClick={() => void readOne(n)}
                  className={`card flex items-center justify-between gap-3 p-4 transition hover:shadow-lift ${n.read ? 'bg-white/60' : ''}`}
                >
                  <div className="min-w-0">
                    <p className={n.read ? 'font-semibold' : 'font-bold'}>{text(n)}</p>
                    <p className="text-sm text-plum-700">{fmtDateTime(n.createdAt)}</p>
                  </div>
                  {!n.read && <Badge tone="pink">New</Badge>}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
