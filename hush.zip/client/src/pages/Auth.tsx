import { useState, type FormEvent } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Heart } from '../components/Illustrations';
import { Button } from '../components/ui/Button';
import { Field } from '../components/ui/Fields';
import { ErrorMessage } from '../components/ui/States';
import { storedInvite } from '../lib/invite';
import { supabase } from '../services/supabase';

function Shell({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="page grid min-h-[70vh] place-items-center py-12">
      <div className="card w-full max-w-md p-7 sm:p-9">
        <Heart className="mb-3 h-9 w-9 text-bubblegum-600" />
        <h1 className="text-3xl font-bold">{title}</h1>
        <p className="mb-6 mt-1 text-plum-700">{subtitle}</p>
        {children}
      </div>
    </div>
  );
}

function GoogleButton({ label }: { label: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function go() {
    setBusy(true);
    setError(null);
    // Supabase handles the Google redirect; we land back on /onboarding (or the app if already set up).
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${window.location.origin}/onboarding` },
    });
    if (error) {
      setError('Google sign-in is not available right now. Please try again or use email.');
      setBusy(false);
    }
  }

  return (
    <div className="mb-5">
      <Button type="button" variant="secondary" size="lg" loading={busy} onClick={() => void go()} className="w-full">
        <svg aria-hidden="true" viewBox="0 0 48 48" className="mr-2 h-5 w-5">
          <path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 8 3l5.7-5.7C34 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.6-.4-3.9z" />
          <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 8 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
          <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-7.9l-6.5 5C9.5 39.6 16.2 44 24 44z" />
          <path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.9z" />
        </svg>
        {label}
      </Button>
      {error && <div className="mt-3"><ErrorMessage message={error} /></div>}
      <div className="my-5 flex items-center gap-3 text-xs font-semibold uppercase tracking-wide text-plum-700" aria-hidden="true">
        <span className="h-px flex-1 bg-plum-700/20" />or<span className="h-px flex-1 bg-plum-700/20" />
      </div>
    </div>
  );
}

export function Login() {
  const loc = useLocation();
  const notice = (loc.state as { notice?: string } | null)?.notice;
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
    // One generic message: do not reveal whether an email is registered.
    if (error) setError(error.message.toLowerCase().includes('confirm') ? 'Please confirm your email first — check your inbox.' : 'Incorrect email or password.');
    setBusy(false);
  }

  return (
    <Shell title="Welcome back" subtitle="Log in to see who's around.">
      {notice && <p role="status" className="mb-4 rounded-2xl bg-lavender-200 p-3 text-sm font-semibold">{notice}</p>}
      <GoogleButton label="Continue with Google" />
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Field label="Email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <Field label="Password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <ErrorMessage message={error} />}
        <Button type="submit" loading={busy} className="w-full" size="lg">Log in</Button>
      </form>
      <p className="mt-6 text-center text-sm">New here? <Link to="/signup" className="font-bold text-lavender-700 underline">Create an account</Link></p>
    </Shell>
  );
}

export function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const invited = storedInvite() !== null;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (password.length < 10) return setError('Use a password with at least 10 characters.');
    setBusy(true);
    setError(null);
    const { error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: { emailRedirectTo: `${window.location.origin}/onboarding` },
    });
    setBusy(false);
    if (error && !/already|registered/i.test(error.message)) return setError(error.message);
    // Identical screen whether or not the address was already registered.
    setSent(true);
  }

  if (sent) {
    return (
      <Shell title="Check your inbox" subtitle="We sent a confirmation link.">
        <p role="status" className="text-plum-700">
          Open the link we emailed to <strong>{email}</strong> to verify your address, then come back to finish your profile. If you already have an account, try{' '}
          <Link to="/login" className="font-bold text-lavender-700 underline">logging in</Link>.
        </p>
      </Shell>
    );
  }

  return (
    <Shell title="Join Hush" subtitle="Sign up with Google or email. A campus email gets you in right away.">
      {invited && <p className="mb-4 rounded-2xl bg-lavender-200 px-4 py-2 text-sm font-semibold" role="note">A friend invited you to Hush 💌 They won&rsquo;t see anything about you except that someone joined.</p>}
      <GoogleButton label="Sign up with Google" />
      <form onSubmit={submit} className="space-y-4" noValidate>
        <Field label="Email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} hint="A campus email verifies you instantly. Other emails work too, but your campus must be verified before you appear in Discover. Never shown to other students." />
        <Field label="Password" type="password" autoComplete="new-password" required minLength={10} value={password} onChange={(e) => setPassword(e.target.value)} hint="At least 10 characters." />
        {error && <ErrorMessage message={error} />}
        <Button type="submit" loading={busy} className="w-full" size="lg">Create account</Button>
      </form>
      <p className="mt-4 text-xs text-plum-700">By signing up you confirm you are 18 or older and agree to our <Link to="/terms" className="underline">Terms</Link>, <Link to="/privacy" className="underline">Privacy Policy</Link> and <Link to="/guidelines" className="underline">Community Guidelines</Link>.</p>
      <p className="mt-4 text-center text-sm">Already have an account? <Link to="/login" className="font-bold text-lavender-700 underline">Log in</Link></p>
    </Shell>
  );
}
