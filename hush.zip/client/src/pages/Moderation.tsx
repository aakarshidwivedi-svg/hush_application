import { useSearchParams, Link } from 'react-router-dom';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Field, Select } from '../components/ui/Fields';
import { EmptyState, ErrorMessage, Skeleton } from '../components/ui/States';
import { useAsync } from '../hooks/useAsync';
import { ACTION_LABEL, REASON_LABEL, STATUS_LABEL, fmtDateTime } from '../lib/format';
import { api } from '../services/api';
import type { ModAuditEntry, ModPage, ModReport } from '../types';

const PAGE_SIZE = 20;

const statusTone = (s: string) => (s === 'OPEN' ? 'pink' : s === 'REVIEWING' ? 'lavender' : 'plum');

function Pager({ page, onOffset, label }: { page: ModPage<unknown>; onOffset: (o: number) => void; label: string }) {
  const from = page.total === 0 ? 0 : page.offset + 1;
  const to = Math.min(page.offset + page.limit, page.total);
  return (
    <nav aria-label={`${label} pagination`} className="mt-4 flex items-center justify-between gap-3">
      <p className="text-sm text-plum-700" aria-live="polite">{from}–{to} of {page.total}</p>
      <div className="flex gap-2">
        <Button variant="secondary" size="sm" disabled={page.offset === 0} onClick={() => onOffset(Math.max(0, page.offset - PAGE_SIZE))}>Previous</Button>
        <Button variant="secondary" size="sm" disabled={to >= page.total} onClick={() => onOffset(page.offset + PAGE_SIZE)}>Next</Button>
      </div>
    </nav>
  );
}

function ListSkeleton() {
  return (
    <div className="space-y-3" role="status" aria-label="Loading">
      {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full" />)}
    </div>
  );
}

function Reports() {
  const [sp, setSp] = useSearchParams();
  const status = sp.get('status') ?? '';
  const reason = sp.get('reason') ?? '';
  const from = sp.get('from') ?? '';
  const to = sp.get('to') ?? '';
  const offset = Math.max(0, Number(sp.get('offset') ?? 0) || 0);
  const bad = !!from && !!to && from > to;

  const list = useAsync(
    () => (bad ? Promise.resolve(null) : api.modReports({ status, reason, from, to, limit: PAGE_SIZE, offset })),
    [status, reason, from, to, offset, bad],
  );

  const set = (k: string, v: string) => {
    const next = new URLSearchParams(sp);
    if (v) next.set(k, v); else next.delete(k);
    if (k !== 'offset') next.delete('offset');
    setSp(next, { replace: true });
  };

  return (
    <section aria-labelledby="reports-h">
      <h2 id="reports-h" className="sr-only">Reports</h2>
      <form className="card mb-5 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4" onSubmit={(e) => e.preventDefault()} aria-label="Filter reports">
        <Select label="Status" value={status} onChange={(e) => set('status', e.target.value)}>
          <option value="">All statuses</option>
          {Object.entries(STATUS_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </Select>
        <Select label="Category" value={reason} onChange={(e) => set('reason', e.target.value)}>
          <option value="">All categories</option>
          {Object.entries(REASON_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </Select>
        <Field label="From" type="date" value={from} onChange={(e) => set('from', e.target.value)} />
        <Field label="To" type="date" value={to} error={bad ? '“To” must not be before “From”' : undefined} onChange={(e) => set('to', e.target.value)} />
      </form>

      {list.loading && !list.data ? <ListSkeleton /> : list.error ? (
        <ErrorMessage message={list.error} onRetry={() => void list.reload()} />
      ) : !list.data || list.data.items.length === 0 ? (
        <EmptyState title="No reports here">{status || reason || from || to ? 'Nothing matches these filters.' : 'The queue is clear. Nice work.'}</EmptyState>
      ) : (
        <>
          <ul className="space-y-3" aria-busy={list.loading}>
            {list.data.items.map((r: ModReport) => (
              <li key={r.id}>
                <Link to={`/moderation/reports/${r.id}`} className="card flex flex-col gap-2 p-4 transition hover:shadow-lift sm:flex-row sm:items-center sm:justify-between">
                  <div className="min-w-0">
                    <p className="truncate font-bold">{r.target.nickname ?? 'Deleted profile'} <span className="font-normal text-plum-700">· {REASON_LABEL[r.reason] ?? r.reason}</span></p>
                    <p className="text-sm text-plum-700">{fmtDateTime(r.createdAt)} · {r.target.reportsReceived} report{r.target.reportsReceived === 1 ? '' : 's'} on this person</p>
                  </div>
                  <div className="flex shrink-0 flex-wrap gap-2">
                    {r.target.accountStatus !== 'ACTIVE' && <Badge tone="plum">{r.target.accountStatus === 'SUSPENDED' ? 'Suspended' : 'Deleted'}</Badge>}
                    <Badge tone={statusTone(r.status)}>{STATUS_LABEL[r.status]}</Badge>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
          <Pager page={list.data} onOffset={(o) => set('offset', o ? String(o) : '')} label="Reports" />
        </>
      )}
    </section>
  );
}

function Audit() {
  const [sp, setSp] = useSearchParams();
  const offset = Math.max(0, Number(sp.get('offset') ?? 0) || 0);
  const list = useAsync(() => api.modAudit({ limit: PAGE_SIZE, offset }), [offset]);
  return (
    <section aria-labelledby="audit-h">
      <h2 id="audit-h" className="sr-only">Audit log</h2>
      {list.loading && !list.data ? <ListSkeleton /> : list.error ? (
        <ErrorMessage message={list.error} onRetry={() => void list.reload()} />
      ) : !list.data || list.data.items.length === 0 ? (
        <EmptyState title="No decisions recorded yet">Every moderation action will appear here with who took it and why.</EmptyState>
      ) : (
        <>
          <ul className="space-y-3" aria-busy={list.loading}>
            {list.data.items.map((a: ModAuditEntry) => (
              <li key={a.id} className="card p-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-bold">{ACTION_LABEL[a.action] ?? a.action}</p>
                  <p className="text-sm text-plum-700">{fmtDateTime(a.createdAt)} · moderator <code>{a.moderator}</code></p>
                </div>
                <p className="mt-1 text-plum-700">“{a.reason}”</p>
                {a.reportId && <Link className="mt-1 inline-block text-sm font-bold underline" to={`/moderation/reports/${a.reportId}`}>View report</Link>}
              </li>
            ))}
          </ul>
          <Pager page={list.data} onOffset={(o) => { const n = new URLSearchParams(sp); if (o) n.set('offset', String(o)); else n.delete('offset'); setSp(n, { replace: true }); }} label="Audit log" />
        </>
      )}
    </section>
  );
}

export default function Moderation() {
  const [sp, setSp] = useSearchParams();
  const tab = sp.get('tab') === 'audit' ? 'audit' : 'reports';
  const pick = (t: 'reports' | 'audit') => setSp(t === 'audit' ? { tab: 'audit' } : {}, { replace: true });
  return (
    <div className="page py-8">
      <h1 className="text-3xl font-bold">Moderation</h1>
      <p className="mb-5 mt-1 text-plum-700">Review reports and keep the community safe. Every decision is recorded with your reason.</p>
      <div role="tablist" aria-label="Moderation sections" className="mb-5 flex gap-2">
        {(['reports', 'audit'] as const).map((t) => (
          <button
            key={t}
            role="tab"
            id={`tab-${t}`}
            aria-selected={tab === t}
            aria-controls="mod-panel"
            type="button"
            onClick={() => pick(t)}
            className={`rounded-full px-5 py-2 font-bold transition ${tab === t ? 'bg-lavender-200 text-plum' : 'text-plum-700 hover:bg-lavender-200/60'}`}
          >
            {t === 'reports' ? 'Reports' : 'Audit log'}
          </button>
        ))}
      </div>
      <div id="mod-panel" role="tabpanel" aria-labelledby={`tab-${tab}`}>{tab === 'reports' ? <Reports /> : <Audit />}</div>
    </div>
  );
}
