import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { InterestPicker, MAX_INTERESTS, MIN_INTERESTS } from '../components/InterestPicker';
import { InviteCard } from '../components/InviteCard';
import { PhotoManager } from '../components/PhotoManager';
import { Button } from '../components/ui/Button';
import { Field, TextArea, Toggle } from '../components/ui/Fields';
import { Modal } from '../components/ui/Modal';
import { ErrorMessage, Skeleton } from '../components/ui/States';
import { useAsync } from '../hooks/useAsync';
import { useAuth } from '../hooks/useAuth';
import { api, ApiError } from '../services/api';

export default function Settings() {
  const { me, setMe, signOut, session } = useAuth();
  const navigate = useNavigate();
  const [nickname, setNickname] = useState(me?.nickname ?? '');
  const [bio, setBio] = useState(me?.bio ?? '');
  const [interestIds, setInterestIds] = useState<string[]>(me?.interests.map((i) => i.id) ?? []);
  const catalog = useAsync(() => api.interestCatalog(), []);
  const [savingInterests, setSavingInterests] = useState(false);
  const [interestsSaved, setInterestsSaved] = useState(false);
  const [interestError, setInterestError] = useState<string | null>(null);
  const [discoverable, setDiscoverable] = useState(me?.discoverable ?? true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});

  const blocked = useAsync(() => api.blocked(), []);
  const [unblocking, setUnblocking] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [delBusy, setDelBusy] = useState(false);
  const [delError, setDelError] = useState<string | null>(null);

  if (!me) return null;

  async function save(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSaved(false);
    setError(null);
    setFields({});
    try {
      setMe(await api.updateMe({ nickname: nickname.trim(), bio, discoverable }));
      setSaved(true);
    } catch (err) {
      if (err instanceof ApiError) {
        setFields(err.fieldErrors);
        if (err.code === 'NICKNAME_TAKEN') setFields({ nickname: err.message });
        else if (Object.keys(err.fieldErrors).length === 0) setError(err.message);
      } else setError('Something went wrong');
    } finally {
      setSaving(false);
    }
  }

  async function saveInterests() {
    setInterestsSaved(false);
    setInterestError(null);
    if (interestIds.length < MIN_INTERESTS || interestIds.length > MAX_INTERESTS) return setInterestError(`Pick between ${MIN_INTERESTS} and ${MAX_INTERESTS} interests.`);
    setSavingInterests(true);
    try {
      setMe(await api.setInterests(interestIds));
      setInterestsSaved(true);
    } catch (e) {
      setInterestError(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setSavingInterests(false);
    }
  }

  async function unblock(id: string) {
    setUnblocking(id);
    try {
      await api.unblock(id);
      blocked.setData((blocked.data ?? []).filter((b) => b.id !== id));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not unblock');
    } finally {
      setUnblocking(null);
    }
  }

  async function deleteAccount() {
    setDelBusy(true);
    setDelError(null);
    try {
      await api.deleteAccount();
      await signOut();
      navigate('/', { replace: true, state: { notice: 'Your account was deleted.' } });
    } catch (e) {
      setDelError(e instanceof Error ? e.message : 'Could not delete your account');
    } finally {
      setDelBusy(false);
    }
  }

  return (
    <div className="page max-w-2xl space-y-8 py-8">
      <h1 className="text-4xl font-bold">Settings</h1>

      <section aria-labelledby="s-profile" className="card p-6 sm:p-8">
        <h2 id="s-profile" className="mb-4 text-2xl font-bold">Your profile</h2>
        {!me.profile.complete && (
          <p role="status" className="mb-4 rounded-2xl bg-lavender-200 p-3 text-sm font-semibold">
            Your profile isn&rsquo;t in Discover yet — it still needs {me.profile.missing.includes('photos') ? 'a photo' : ''}{me.profile.missing.length === 2 ? ' and ' : ''}{me.profile.missing.includes('interests') ? `at least ${MIN_INTERESTS} interests` : ''}.
          </p>
        )}
        <form onSubmit={save} className="space-y-5" noValidate>
          <Field label="Nickname" value={nickname} maxLength={24} autoComplete="off" onChange={(e) => setNickname(e.target.value)} error={fields.nickname} />
          <TextArea label="Short bio" value={bio} maxLength={280} onChange={(e) => setBio(e.target.value)} error={fields.bio} hint={`${bio.length}/280`} />
          <Toggle label="Show me in Discover" description="Off = you can still browse and match, but you won't be shown to others." checked={discoverable} onChange={setDiscoverable} />
          {error && <ErrorMessage message={error} />}
          <div className="flex items-center gap-3">
            <Button type="submit" loading={saving}>Save changes</Button>
            <span role="status" className="text-sm font-semibold text-lavender-700">{saved ? 'Saved ✓' : ''}</span>
          </div>
        </form>
      </section>

      <section aria-labelledby="s-photos" className="card p-6 sm:p-8">
        <h2 id="s-photos" className="mb-1 text-2xl font-bold">Photos</h2>
        <p className="mb-4 text-plum-700">Show us your vibe ✨ Up to 6 photos. Your main photo is what shows on cards.</p>
        <PhotoManager onChange={() => void api.me().then(setMe).catch(() => undefined)} />
      </section>

      <section aria-labelledby="s-interests" className="card p-6 sm:p-8">
        <h2 id="s-interests" className="mb-1 text-2xl font-bold">Interests</h2>
        <p className="mb-4 text-plum-700">Pick at least {MIN_INTERESTS} things you love.</p>
        {catalog.error && !catalog.data ? <ErrorMessage message={catalog.error} onRetry={() => void catalog.reload()} /> : catalog.loading && !catalog.data ? <Skeleton className="h-24 w-full" /> : (
          <InterestPicker catalog={catalog.data ?? []} value={interestIds} onChange={(v) => { setInterestIds(v); setInterestsSaved(false); }} error={interestError ?? undefined} />
        )}
        <div className="mt-5 flex items-center gap-3">
          <Button loading={savingInterests} onClick={() => void saveInterests()}>Save interests</Button>
          <span role="status" className="text-sm font-semibold text-lavender-700">{interestsSaved ? 'Saved ✓' : ''}</span>
        </div>
      </section>

      <InviteCard />

      <section aria-labelledby="s-privacy" className="card space-y-3 p-6 sm:p-8">
        <h2 id="s-privacy" className="text-2xl font-bold">Privacy</h2>
        <p className="text-plum-700">Other students see only your nickname, bio, interests and photos — and only if you're discoverable. Your email ({session?.user.email}) and campus verification are never shown to them. Your crushes are stored privately and are never shown to anyone.</p>
        <p className="text-plum-700">Hush can&rsquo;t promise perfect anonymity — read exactly what we store in the <Link to="/privacy" className="font-bold underline">Privacy Policy</Link> and our <Link to="/guidelines" className="font-bold underline">Community Guidelines</Link>.</p>
      </section>

      <section aria-labelledby="s-blocked" className="card p-6 sm:p-8">
        <h2 id="s-blocked" className="mb-3 text-2xl font-bold">Blocked people</h2>
        {blocked.loading && !blocked.data ? <Skeleton className="h-12 w-full" /> : blocked.error && !blocked.data ? <ErrorMessage message={blocked.error} onRetry={() => void blocked.reload()} /> : (blocked.data ?? []).length === 0 ? (
          <p className="text-plum-700">You haven&rsquo;t blocked anyone.</p>
        ) : (
          <ul className="divide-y divide-plum/10">
            {(blocked.data ?? []).map((b) => (
              <li key={b.id} className="flex items-center justify-between gap-3 py-3">
                <span className="font-bold">{b.nickname}</span>
                <Button size="sm" variant="secondary" loading={unblocking === b.id} onClick={() => void unblock(b.id)}>Unblock</Button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section aria-labelledby="s-account" className="card space-y-4 p-6 sm:p-8">
        <h2 id="s-account" className="text-2xl font-bold">Account</h2>
        <Button variant="secondary" onClick={() => void signOut()}>Log out</Button>
        <div className="rounded-2xl border border-bubblegum-700/30 bg-bubblegum/10 p-4">
          <h3 className="font-sans text-lg font-bold">Delete account</h3>
          <p className="mb-3 mt-1 text-sm text-plum-700">Permanently erases your profile, chats, crushes and blocks. This can&rsquo;t be undone. See the <Link to="/privacy" className="font-bold underline">retention policy</Link>.</p>
          <Button variant="danger" onClick={() => { setConfirmText(''); setDelError(null); setDeleting(true); }}>Delete my account…</Button>
        </div>
      </section>

      <Modal open={deleting} onClose={() => setDeleting(false)} title="Delete your account?">
        <p className="mb-4 text-plum-700">Everyone you matched with will lose the conversation. Type <strong>DELETE</strong> to confirm.</p>
        <Field label="Confirmation" value={confirmText} onChange={(e) => setConfirmText(e.target.value)} autoComplete="off" />
        {delError && <div className="mb-3"><ErrorMessage message={delError} /></div>}
        <div className="flex gap-3">
          <Button variant="secondary" className="flex-1" onClick={() => setDeleting(false)}>Keep my account</Button>
          <Button variant="danger" className="flex-1" disabled={confirmText !== 'DELETE'} loading={delBusy} onClick={() => void deleteAccount()}>Delete forever</Button>
        </div>
      </Modal>
    </div>
  );
}
