import { useCallback, useEffect, useRef, useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { InterestPicker, MAX_INTERESTS, MIN_INTERESTS } from '../components/InterestPicker';
import { PhotoManager } from '../components/PhotoManager';
import { ProfileCard } from '../components/ProfileCard';
import { Sparkle } from '../components/Illustrations';
import { Button } from '../components/ui/Button';
import { Field, Select, TextArea, Toggle } from '../components/ui/Fields';
import { ErrorMessage, PageLoader } from '../components/ui/States';
import { useAsync } from '../hooks/useAsync';
import { useAuth } from '../hooks/useAuth';
import { clearInvite, storedInvite } from '../lib/invite';
import { api, ApiError } from '../services/api';
import type { Me } from '../types';

const STEPS = ['Campus', 'About you', 'Photos', 'Interests', 'Preview'] as const;
const NICKNAME = /^[A-Za-z0-9_.]{3,24}$/;

/** Where a returning person should resume: everything saved on the server counts as done. */
function resumeStep(me: Me | null): number {
  if (!me) return 0;
  if (me.photoCount < 1) return 2;
  if (me.interests.length < MIN_INTERESTS) return 3;
  return 4;
}

function Progress({ step }: { step: number }) {
  return (
    <nav aria-label="Profile setup progress" className="mb-8">
      <p className="mb-2 text-sm font-bold text-plum-700">Step {step + 1} of {STEPS.length} · {STEPS[step]}</p>
      <ol className="grid grid-cols-5 gap-2">
        {STEPS.map((label, i) => (
          <li key={label} aria-current={i === step ? 'step' : undefined}>
            <span className={`block h-2 rounded-full transition-colors ${i < step ? 'bg-lavender-700' : i === step ? 'bg-bubblegum-600' : 'bg-plum/15'}`} />
            <span className="sr-only">{label}{i < step ? ' (done)' : i === step ? ' (current)' : ''}</span>
          </li>
        ))}
      </ol>
    </nav>
  );
}

export default function Onboarding() {
  const { me, setMe, session, status } = useAuth();
  const navigate = useNavigate();
  // Decided once, on arrival: someone with a finished profile has nothing to do here, but a person
  // who *becomes* complete mid-flow must still reach the final preview step.
  const [needed] = useState(() => status === 'needs-onboarding' || !me || !me.profile.complete);
  const accountExists = me !== null;

  const campuses = useAsync(() => api.campuses(), []);
  const catalog = useAsync(() => api.interestCatalog(), []);

  const [step, setStep] = useState(() => resumeStep(me));
  const [campusId, setCampusId] = useState(me?.campus.id ?? '');
  const [adult, setAdult] = useState(accountExists);
  const [nickname, setNickname] = useState(me?.nickname ?? '');
  const [bio, setBio] = useState(me?.bio ?? '');
  const [interestIds, setInterestIds] = useState<string[]>(me?.interests.map((i) => i.id) ?? []);
  const [discoverable, setDiscoverable] = useState(me?.discoverable ?? true);
  const [photoCount, setPhotoCount] = useState(me?.photoCount ?? 0);

  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});
  const heading = useRef<HTMLHeadingElement>(null);

  // Move focus to the step heading when the step changes (keyboard and screen-reader users).
  const first = useRef(true);
  useEffect(() => {
    if (first.current) { first.current = false; return; }
    heading.current?.focus();
  }, [step]);

  const reloadMe = useCallback(async () => {
    try {
      const fresh = await api.me();
      setMe(fresh);
      setPhotoCount(fresh.photoCount);
    } catch { /* the next action will surface a real problem */ }
  }, [setMe]);

  if (!needed) return <Navigate to="/discover" replace />;
  if (campuses.loading || catalog.loading) return <PageLoader label="Getting things ready…" />;

  const fail = (err: unknown) => {
    if (err instanceof ApiError) {
      setFields(err.fieldErrors);
      if (err.code === 'NICKNAME_TAKEN') setFields({ nickname: err.message });
      else if (Object.keys(err.fieldErrors).length === 0) setError(err.message);
    } else setError('Something went wrong');
  };
  const reset = () => { setError(null); setFields({}); };
  const goto = (n: number) => { reset(); setStep(n); };

  function campusStep() {
    reset();
    if (!campusId) return setFields({ campusId: 'Choose your campus.' });
    if (!adult) return setFields({ ageAttestation: 'Please confirm that you are 18 or older.' });
    setStep(1);
  }

  async function aboutStep() {
    reset();
    const nick = nickname.trim();
    if (!NICKNAME.test(nick)) return setFields({ nickname: '3–24 characters: letters, numbers, "_" or "."' });
    setBusy(true);
    try {
      if (!me) {
        // First write: this creates the account record. The server derives campus status from the verified token.
        const inviteCode = storedInvite();
        setMe(await api.completeProfile({ campusId, nickname: nick, bio, discoverable, ageAttestation: true, ...(inviteCode ? { inviteCode } : {}) }));
        clearInvite(); // credited once, at account creation
      } else if (me && (nick !== me.nickname || bio !== me.bio)) {
        setMe(await api.updateMe({ nickname: nick, bio }));
      }
      setStep(2);
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  }

  function photosStep() {
    reset();
    if (photoCount < 1) return setError('Add at least one photo to continue.');
    setStep(3);
  }

  async function interestsStep() {
    reset();
    if (interestIds.length < MIN_INTERESTS) return setFields({ interestIds: `Pick at least ${MIN_INTERESTS} interests.` });
    setBusy(true);
    try {
      setMe(await api.setInterests(interestIds));
      setStep(4);
    } catch (e) {
      if (e instanceof ApiError && e.fieldErrors.interestIds) setFields({ interestIds: e.fieldErrors.interestIds });
      else fail(e);
    } finally {
      setBusy(false);
    }
  }

  async function finish() {
    reset();
    setBusy(true);
    try {
      let current = me;
      if (me && discoverable !== me.discoverable) current = await api.updateMe({ discoverable });
      else current = await api.me();
      setMe(current);
      if (!current.profile.complete) {
        const missing = current.profile.missing;
        setError(`Almost there — you still need ${missing.includes('photos') ? 'a photo' : ''}${missing.length === 2 ? ' and ' : ''}${missing.includes('interests') ? `at least ${MIN_INTERESTS} interests` : ''}.`);
        setStep(missing.includes('photos') ? 2 : 3);
        return;
      }
      navigate('/discover', { replace: true });
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  }

  const chosen = campuses.data?.find((c) => c.id === campusId);
  const previewInterests = (catalog.data ?? []).flatMap((c) => c.interests).filter((i) => interestIds.includes(i.id));

  return (
    <div className="page max-w-2xl py-10">
      <Progress step={step} />

      {step === 0 && (
        <section aria-labelledby="ob-h" className="card space-y-6 p-6 sm:p-8">
          <header>
            <h1 id="ob-h" ref={heading} tabIndex={-1} className="text-3xl font-bold outline-none sm:text-4xl">Welcome to Hush</h1>
            <p className="mt-2 text-plum-700">Signed in as <strong>{session?.user.email}</strong>. This stays private — others only ever see what you choose on your profile.</p>
          </header>
          {campuses.error && <ErrorMessage message={campuses.error} onRetry={() => void campuses.reload()} />}
          <Select label="Your campus" required value={campusId} disabled={accountExists} onChange={(e) => setCampusId(e.target.value)} error={fields.campusId}>
            <option value="" disabled>Choose your campus…</option>
            {campuses.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          {chosen && <p className="-mt-3 text-sm text-plum-700">A campus email ({chosen.emailDomains.map((d) => `@${d}`).join(' or ') || 'an approved domain'}) verifies you instantly. Other emails can still join, but a moderator has to verify your campus before you appear in Discover.</p>}
          <div>
            <label className="flex items-start gap-3 font-semibold">
              <input type="checkbox" checked={adult} disabled={accountExists} onChange={(e) => setAdult(e.target.checked)} className="mt-1 h-5 w-5 rounded accent-lavender-700" aria-invalid={!!fields.ageAttestation} />
              <span>I confirm that I am 18 or older.</span>
            </label>
            {fields.ageAttestation && <p role="alert" className="mt-1 text-sm font-semibold text-bubblegum-700">{fields.ageAttestation}</p>}
            <p className="mt-1 pl-8 text-sm text-plum-700">Some campuses require extra age verification before you can appear in Discover.</p>
          </div>
          {error && <ErrorMessage message={error} />}
          <Button size="lg" className="w-full" onClick={campusStep}>Continue</Button>
        </section>
      )}

      {step === 1 && (
        <section aria-labelledby="ob-h" className="card space-y-6 p-6 sm:p-8">
          <header>
            <h1 id="ob-h" ref={heading} tabIndex={-1} className="text-3xl font-bold outline-none sm:text-4xl">A little more you, a little more Hush.</h1>
            <p className="mt-2 text-plum-700">Pick a nickname that isn&rsquo;t your real name, and say something about yourself.</p>
          </header>
          <Field label="Nickname" required value={nickname} maxLength={24} autoComplete="off" onChange={(e) => setNickname(e.target.value)} error={fields.nickname} hint="3–24 characters: letters, numbers, _ or ." />
          <TextArea label="Short bio" value={bio} maxLength={280} onChange={(e) => setBio(e.target.value)} error={fields.bio} hint={`${bio.length}/280 · optional`} />
          {error && <ErrorMessage message={error} />}
          <div className="flex gap-3">
            <Button variant="secondary" onClick={() => goto(0)}>Back</Button>
            <Button size="lg" className="flex-1" loading={busy} onClick={() => void aboutStep()}>Continue</Button>
          </div>
        </section>
      )}

      {step === 2 && (
        <section aria-labelledby="ob-h" className="card space-y-6 p-6 sm:p-8">
          <header>
            <h1 id="ob-h" ref={heading} tabIndex={-1} className="text-3xl font-bold outline-none sm:text-4xl">Show us your vibe ✨</h1>
            <p className="mt-2 text-plum-700">Add 1–6 photos. Your first photo is your main one — you can change that any time. Only people who can see your profile ever see them.</p>
          </header>
          <PhotoManager onChange={(list) => { setPhotoCount(list.length); void reloadMe(); }} />
          {error && <ErrorMessage message={error} />}
          <div className="flex gap-3">
            <Button variant="secondary" onClick={() => goto(1)}>Back</Button>
            <Button size="lg" className="flex-1" onClick={photosStep}>Continue</Button>
          </div>
        </section>
      )}

      {step === 3 && (
        <section aria-labelledby="ob-h" className="card space-y-6 p-6 sm:p-8">
          <header>
            <h1 id="ob-h" ref={heading} tabIndex={-1} className="text-3xl font-bold outline-none sm:text-4xl">Pick at least {MIN_INTERESTS} things you love.</h1>
            <p className="mt-2 text-plum-700">Up to {MAX_INTERESTS}. They help the right people say hi.</p>
          </header>
          {catalog.error && <ErrorMessage message={catalog.error} onRetry={() => void catalog.reload()} />}
          <InterestPicker catalog={catalog.data ?? []} value={interestIds} onChange={setInterestIds} error={fields.interestIds} />
          {error && <ErrorMessage message={error} />}
          <div className="flex gap-3">
            <Button variant="secondary" onClick={() => goto(2)}>Back</Button>
            <Button size="lg" className="flex-1" loading={busy} onClick={() => void interestsStep()}>Continue</Button>
          </div>
        </section>
      )}

      {step === 4 && me && (
        <section aria-labelledby="ob-h" className="space-y-6">
          <header>
            <h1 id="ob-h" ref={heading} tabIndex={-1} className="text-3xl font-bold outline-none sm:text-4xl">Your profile, your rules.</h1>
            <p className="mt-2 text-plum-700">This is how other students on {me.campus.name} will see you. Your email and your crushes are never shown.</p>
          </header>
          <div className="mx-auto max-w-sm">
            <ProfileCard profile={{ nickname: nickname.trim() || me.nickname, bio, interests: previewInterests, photo: me.photo }} maxChips={6} />
          </div>
          <div className="card space-y-4 p-6">
            <Toggle label="Show me in Discover" description="Turn this off to browse and match without being shown to others. You can change it any time in Settings." checked={discoverable} onChange={setDiscoverable} />
            {!me.account.eligible && (
              <p className="flex gap-2 rounded-2xl bg-lavender-200 p-3 text-sm font-semibold"><Sparkle className="mt-0.5 h-4 w-4 shrink-0 text-lavender-700" />
                {me.account.missing.includes('campus_verification') ? "You'll show up in Discover once a moderator verifies your campus (a campus email does it instantly)." : "You'll show up in Discover once your account verification is complete."}
              </p>
            )}
          </div>
          {error && <ErrorMessage message={error} />}
          <div className="flex gap-3">
            <Button variant="secondary" onClick={() => goto(3)}>Back</Button>
            <Button size="lg" className="flex-1" loading={busy} onClick={() => void finish()}>Finish &amp; start discovering</Button>
          </div>
        </section>
      )}
    </div>
  );
}
