import { FloatingDecor, Heart, Sparkle, Star } from '../components/Illustrations';
import { LinkButton } from '../components/ui/Button';
import { useAuth } from '../hooks/useAuth';

const steps = [
  { icon: Star, title: 'Make a nickname', text: 'Create a pseudonymous profile with a bio and a few interests. No real name needed.' },
  { icon: Heart, title: 'Send a secret crush', text: 'Browse students on your campus and tap the heart. They are never told.' },
  { icon: Sparkle, title: 'Match only if mutual', text: 'If they crushed on you too, you both get a match and can start chatting.' },
];

const safety = [
  ['One-sided stays secret', 'Nobody can see who likes them — not in the app, not in the API. No “likes you” counts or hints.'],
  ['Your campus only', 'You are only shown verified, active students from your own campus community.'],
  ['18+ only', 'Hush is for adults. Campuses can require extra age verification.'],
  ['Block, report, unmatch', 'Blocked people cannot contact you in any way. Reports go to human moderators.'],
  ['Delete anytime', 'Delete your account and your profile, chats and crushes are erased.'],
  ['Honest about privacy', 'We never promise perfect anonymity. We explain exactly what we store.'],
];

export default function Landing() {
  const { status } = useAuth();
  const signedIn = status === 'ready';
  const needsProfile = status === 'needs-onboarding';
  return (
    <>
      <section className="relative isolate overflow-hidden">
        <FloatingDecor />
        <div className="page grid gap-10 py-16 sm:py-24 lg:grid-cols-[1.1fr_.9fr] lg:items-center">
          <div>
            <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-white px-4 py-1.5 text-sm font-bold shadow-soft">
              <Heart className="h-4 w-4 text-bubblegum-600" /> Anonymous college dating
            </p>
            <h1 className="text-5xl font-bold leading-[1.05] sm:text-6xl">
              Someone might like you.
              <span className="mt-2 block bg-gradient-to-r from-bubblegum-700 to-lavender-700 bg-clip-text text-transparent">You&rsquo;ll never know until it&rsquo;s mutual.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-plum-700">
              Send secret crushes to people on your campus. Nothing is revealed unless they feel the same — then it&rsquo;s a match, and you can say hi.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              {signedIn ? (
                <LinkButton to="/discover" size="lg">Go to Discover</LinkButton>
              ) : needsProfile ? (
                <LinkButton to="/onboarding" size="lg">Finish setting up your profile</LinkButton>
              ) : (
                <>
                  <LinkButton to="/signup" size="lg">Create your profile</LinkButton>
                  <LinkButton to="/login" variant="secondary" size="lg">Log in</LinkButton>
                </>
              )}
            </div>
          </div>

          <div className="relative mx-auto w-full max-w-sm" aria-hidden="true">
            <div className="card rotate-3 space-y-3 p-5">
              <div className="flex items-center gap-3">
                <span className="grid h-14 w-14 place-items-center rounded-full bg-gradient-to-br from-bubblegum to-lavender font-display text-xl font-bold">M</span>
                <div><p className="font-bold">moonlit_maya</p><p className="text-sm text-plum-700">Loves night swims & lo-fi</p></div>
              </div>
              <div className="flex gap-2"><span className="rounded-full bg-lavender-200 px-3 py-1 text-xs font-bold">film</span><span className="rounded-full bg-lavender-200 px-3 py-1 text-xs font-bold">climbing</span></div>
              <div className={`grid h-11 place-items-center rounded-full bg-gradient-to-br from-bubblegum to-bubblegum-600 font-bold`}>♥ Secret crush</div>
            </div>
            <div className="card absolute -bottom-10 -left-4 w-60 -rotate-3 animate-pop p-4 text-center">
              <Heart className="mx-auto h-8 w-8 text-bubblegum-600" />
              <p className="mt-1 font-display text-xl font-bold">It&rsquo;s a match!</p>
              <p className="text-sm text-plum-700">Only when you both said yes.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="how" className="page scroll-mt-20 py-16">
        <h2 className="text-center text-4xl font-bold">How it works</h2>
        <ol className="mt-10 grid gap-6 md:grid-cols-3">
          {steps.map((s, i) => (
            <li key={s.title} className="card p-6">
              <span className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-bubblegum to-lavender">
                <s.icon className="h-6 w-6 text-white" />
              </span>
              <h3 className="text-xl font-bold"><span className="text-bubblegum-700">{i + 1}.</span> {s.title}</h3>
              <p className="mt-2 text-plum-700">{s.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section id="safety" className="scroll-mt-20 bg-white/60 py-16">
        <div className="page">
          <h2 className="text-center text-4xl font-bold">Privacy &amp; safety, by design</h2>
          <ul className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {safety.map(([t, d]) => (
              <li key={t} className="rounded-3xl bg-cream p-6 ring-1 ring-plum/10">
                <h3 className="text-lg font-bold">{t}</h3>
                <p className="mt-1 text-plum-700">{d}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {!signedIn && !needsProfile && (
        <section className="page py-16 text-center">
          <h2 className="text-4xl font-bold">Ready to hush?</h2>
          <p className="mx-auto mt-3 max-w-md text-plum-700">It takes a minute. Use your campus email and pick a nickname.</p>
          <LinkButton to="/signup" size="lg" className="mt-6">Get started</LinkButton>
        </section>
      )}
    </>
  );
}
