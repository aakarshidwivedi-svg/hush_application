import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ConfirmModal } from '../components/ConfirmModal';
import { ReportModal } from '../components/ReportModal';
import { Avatar } from '../components/ui/Avatar';
import { Button, LinkButton } from '../components/ui/Button';
import { EmptyState, ErrorMessage, PageLoader, Skeleton } from '../components/ui/States';
import { useRealtime, useSocketEvent } from '../hooks/useRealtime';
import { api, ApiError } from '../services/api';
import type { MatchView, Message } from '../types';

const MAX = 1000;
/** Without a live connection the chat falls back to checking for new messages this often. */
const FALLBACK_POLL_MS = 5000;
const TYPING_REFRESH_MS = 2500;
const TYPING_IDLE_MS = 3000;
const TYPING_SHOW_MS = 5000;
const ACK_TIMEOUT_MS = 8000;

const fmt = new Intl.DateTimeFormat(undefined, { hour: 'numeric', minute: '2-digit', month: 'short', day: 'numeric' });

const byTime = (a: Message, b: Message) => (a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : a.id < b.id ? -1 : a.id > b.id ? 1 : 0);

/**
 * Merge confirmed messages into the list: duplicates (same id) are dropped, an optimistic message is
 * replaced by its confirmed twin (matched by clientId), confirmed messages stay in server order, and
 * anything still pending or failed stays at the bottom in the order it was typed.
 */
function merge(prev: Message[], incoming: Message[]): Message[] {
  const confirmed = new Map(prev.filter((m) => !m.pending && !m.failed).map((m) => [m.id, m]));
  const settled = new Set(incoming.map((m) => m.clientId).filter(Boolean));
  for (const m of incoming) confirmed.set(m.id, { ...m, pending: false, failed: false });
  const open = prev.filter((m) => (m.pending || m.failed) && !(m.clientId && settled.has(m.clientId)));
  return [...[...confirmed.values()].sort(byTime), ...open];
}

export default function Chat() {
  const { matchId = '' } = useParams();
  const navigate = useNavigate();
  const { socket, connected } = useRealtime();
  const [match, setMatch] = useState<MatchView | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [older, setOlder] = useState<string | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'gone' | 'error'>('loading');
  const [error, setError] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [sendError, setSendError] = useState<string | null>(null);
  const [partnerTyping, setPartnerTyping] = useState(false);
  const [offline, setOffline] = useState(false);
  const [dialog, setDialog] = useState<'unmatch' | 'block' | 'report' | null>(null);
  const [busy, setBusy] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const messagesRef = useRef<Message[]>([]);
  messagesRef.current = messages;
  const typingSent = useRef(0);
  const typingIdle = useRef<number>();
  const typingShow = useRef<number>();
  const readTimer = useRef<number>();

  const lastConfirmedId = () => [...messagesRef.current].reverse().find((m) => !m.pending && !m.failed)?.id ?? null;
  const receive = useCallback((incoming: Message[]) => {
    if (incoming.length) setMessages((prev) => merge(prev, incoming));
  }, []);

  /** Tell the server this conversation has been seen (clears the unread badge everywhere). */
  const markSeen = useCallback(() => {
    window.clearTimeout(readTimer.current);
    readTimer.current = window.setTimeout(() => {
      if (!document.hidden) void api.markConversationRead(matchId).catch(() => undefined);
    }, 400);
  }, [matchId]);

  /** Fetch everything after the newest confirmed message: used after a reconnect and by the offline fallback. */
  const catchUp = useCallback(async () => {
    try {
      for (let i = 0; i < 10; i++) {
        const after = lastConfirmedId();
        const page = after ? await api.messages(matchId, { after }) : await api.messages(matchId);
        receive(page.items);
        setOffline(false);
        if (page.items.length < 50) break;
      }
    } catch (e) {
      if (e instanceof ApiError && e.status === 404) setState('gone');
    }
  }, [matchId, receive]);

  // Initial load.
  useEffect(() => {
    let alive = true;
    setState('loading');
    setMessages([]);
    Promise.all([api.match(matchId), api.messages(matchId)])
      .then(([m, page]) => {
        if (!alive) return;
        setMatch(m);
        setMessages(page.items);
        setOlder(page.nextCursor);
        setState('ready');
        markSeen();
      })
      .catch((e) => {
        if (!alive) return;
        if (e instanceof ApiError && (e.status === 404 || e.status === 422)) setState('gone');
        else { setError(e instanceof Error ? e.message : 'Something went wrong'); setState('error'); }
      });
    return () => { alive = false; window.clearTimeout(readTimer.current); };
  }, [matchId, markSeen]);

  // Live messages for this conversation (including ones sent from this person's other tabs).
  useSocketEvent<{ matchId: string; message: Message; clientId?: string | null }>('message:new', (p) => {
    if (p.matchId !== matchId || state !== 'ready') return;
    receive([{ ...p.message, ...(p.clientId ? { clientId: p.clientId } : {}) }]);
    if (!p.message.mine) { setPartnerTyping(false); markSeen(); }
    else setSendError(null); // my own message was confirmed (e.g. delivered after a reconnect): a stale "not sent" banner would be wrong
  });

  useSocketEvent<{ matchId: string; typing: boolean }>('typing', (p) => {
    if (p.matchId !== matchId) return;
    window.clearTimeout(typingShow.current);
    setPartnerTyping(p.typing);
    if (p.typing) typingShow.current = window.setTimeout(() => setPartnerTyping(false), TYPING_SHOW_MS);
  });

  // Unmatched, blocked, suspended or deleted: the server says the conversation changed, so ask it whether we still have access.
  useSocketEvent('matches:changed', () => {
    if (state !== 'ready') return;
    api.match(matchId).catch((e) => { if (e instanceof ApiError && e.status === 404) setState('gone'); });
  });

  // Reconnected: pull whatever was missed while the connection was down.
  const wasConnected = useRef(false);
  useEffect(() => {
    if (state !== 'ready') return;
    if (connected && !wasConnected.current) void catchUp();
    wasConnected.current = connected;
  }, [connected, state, catchUp]);

  // No live connection: fall back to polling so chat still works, just a little slower.
  useEffect(() => {
    if (state !== 'ready' || connected) return;
    const t = window.setInterval(() => { if (!document.hidden) void catchUp(); }, FALLBACK_POLL_MS);
    return () => window.clearInterval(t);
  }, [state, connected, catchUp]);

  // Only mention the connection after it has been down for a moment, so brief blips stay quiet.
  useEffect(() => {
    if (connected || state !== 'ready') return setOffline(false);
    const t = window.setTimeout(() => setOffline(true), 2500);
    return () => window.clearTimeout(t);
  }, [connected, state]);

  useEffect(() => {
    const onVisible = () => { if (!document.hidden && state === 'ready') { markSeen(); void catchUp(); } };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [state, markSeen, catchUp]);

  useEffect(() => { if (stick.current) endRef.current?.scrollIntoView({ block: 'end' }); }, [messages, partnerTyping]);

  // Close the options menu on Escape (returning focus to its button) or on an outside click.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { setMenuOpen(false); menuRef.current?.querySelector('button')?.focus(); }
    };
    const onDown = (e: MouseEvent) => { if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false); };
    document.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onDown);
    return () => { document.removeEventListener('keydown', onKey); document.removeEventListener('mousedown', onDown); };
  }, [menuOpen]);

  useEffect(() => () => { window.clearTimeout(typingIdle.current); window.clearTimeout(typingShow.current); }, []);

  async function loadOlder() {
    if (!older) return;
    stick.current = false;
    try {
      const page = await api.messages(matchId, { before: older });
      receive(page.items);
      setOlder(page.nextCursor);
    } catch { /* leave the button for another try */ }
  }

  const sendTyping = (typing: boolean) => { if (socket?.connected) socket.emit('typing', { matchId, typing }); };

  function onDraft(value: string) {
    setDraft(value);
    window.clearTimeout(typingIdle.current);
    if (!value.trim()) { typingSent.current = 0; return sendTyping(false); }
    const now = Date.now();
    if (now - typingSent.current > TYPING_REFRESH_MS) { typingSent.current = now; sendTyping(true); }
    typingIdle.current = window.setTimeout(() => { typingSent.current = 0; sendTyping(false); }, TYPING_IDLE_MS);
  }

  /**
   * Deliver one message. Over the socket when it is up, otherwise (or if that fails) over REST. Both carry the
   * same clientId, so a retry after a dropped connection or a lost reply can never create a duplicate.
   */
  async function deliver(content: string, clientId: string) {
    const fail = (message: string) => {
      setMessages((prev) => prev.map((m) => (m.clientId === clientId ? { ...m, pending: false, failed: true } : m)));
      setSendError(message);
    };
    try {
      let confirmed: Message | null = null;
      if (socket?.connected) {
        try {
          const ack = (await socket.timeout(ACK_TIMEOUT_MS).emitWithAck('message:send', { matchId, content, clientId })) as
            | { ok: true; message: Message }
            | { ok: false; code: string; message: string };
          if (ack.ok) confirmed = ack.message;
          else if (ack.code === 'NOT_FOUND') return setState('gone');
          else if (ack.code === 'RATE_LIMITED') return fail("You're sending messages too fast — take a breath and try again.");
          else if (ack.code === 'VALIDATION') return fail('That message could not be sent.');
          // anything else (network, server hiccup): fall through to REST with the same clientId
        } catch { /* ack timed out: the REST retry below is safe because of clientId */ }
      }
      if (!confirmed) confirmed = await api.sendMessage(matchId, content, clientId);
      receive([{ ...confirmed, clientId }]);
      setSendError(null);
    } catch (err) {
      if (err instanceof ApiError && err.status === 404) setState('gone');
      else if (err instanceof ApiError && err.status === 429) fail("You're sending messages too fast — take a breath and try again.");
      else fail(err instanceof ApiError && err.status !== 0 ? err.message : 'Not sent — check your connection and retry.');
    }
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    const content = draft.trim();
    if (!content) return;
    const clientId = crypto.randomUUID();
    stick.current = true;
    setMessages((prev) => [...prev, { id: `pending-${clientId}`, clientId, content, mine: true, createdAt: new Date().toISOString(), pending: true }]);
    setDraft('');
    setSendError(null);
    window.clearTimeout(typingIdle.current);
    typingSent.current = 0;
    sendTyping(false);
    void deliver(content, clientId);
  }

  function retry(m: Message) {
    if (!m.clientId) return;
    setMessages((prev) => prev.map((x) => (x.clientId === m.clientId ? { ...x, pending: true, failed: false } : x)));
    setSendError(null);
    void deliver(m.content, m.clientId);
  }

  async function endChat(kind: 'unmatch' | 'block') {
    if (!match) return;
    setBusy(true);
    try {
      await (kind === 'unmatch' ? api.unmatch(match.id) : api.block(match.partner.id));
      navigate('/matches', { replace: true });
    } catch (e) {
      setSendError(e instanceof Error ? e.message : 'Something went wrong');
      setDialog(null);
    } finally {
      setBusy(false);
    }
  }

  if (state === 'loading') return <PageLoader label="Opening chat…" />;
  if (state === 'gone')
    return <div className="page py-12"><EmptyState title="This conversation has ended" action={<LinkButton to="/matches">Back to matches</LinkButton>}>It was unmatched, or one of you left or was blocked.</EmptyState></div>;
  if (state === 'error' || !match) return <div className="page py-12"><ErrorMessage message={error ?? 'Something went wrong'} onRetry={() => navigate(0)} /></div>;

  return (
    <div className="page flex h-[calc(100dvh-4rem)] max-w-3xl flex-col py-3">
      <div className="card flex items-center gap-3 p-3">
        <Link to="/matches" aria-label="Back to matches" className="grid h-10 w-10 place-items-center rounded-full hover:bg-plum/5">←</Link>
        <Avatar nickname={match.partner.nickname} photo={match.partner.photo} size="h-11 w-11" textSize="text-lg" />
        <div className="min-w-0 flex-1"><h1 className="truncate font-sans text-lg font-bold">{match.partner.nickname}</h1><p className="truncate text-xs text-plum-700">{match.partner.bio || 'Matched with you'}</p></div>
        <div className="relative" ref={menuRef}>
          <button type="button" aria-haspopup="menu" aria-expanded={menuOpen} aria-controls="chat-menu" aria-label="Chat options" onClick={() => setMenuOpen((o) => !o)} className="grid h-10 w-10 place-items-center rounded-full hover:bg-plum/5">⋯</button>
          {menuOpen && (
            <div id="chat-menu" role="menu" aria-label="Chat options" className="card absolute right-0 z-10 mt-2 w-44 p-2 text-sm font-bold">
              {(['unmatch', 'report', 'block'] as const).map((k) => (
                <button key={k} type="button" role="menuitem" className="block w-full rounded-xl px-3 py-2 text-left capitalize hover:bg-lavender-200/60" onClick={() => { setMenuOpen(false); setDialog(k); }}>{k}</button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div role="status" className="min-h-0 text-center text-xs font-semibold text-plum-700">
        {offline && <p className="mt-2 rounded-full bg-lavender-200 px-3 py-1">Reconnecting… messages still send, and new ones may take a few seconds to appear.</p>}
      </div>

      <div className="mb-3 mt-1 flex-1 overflow-y-auto rounded-3xl bg-white/60 p-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-lavender-700" role="log" tabIndex={0} aria-live="polite" aria-relevant="additions" aria-label={`Conversation with ${match.partner.nickname}`}>
        {older && <div className="mb-3 text-center"><Button size="sm" variant="secondary" onClick={() => void loadOlder()}>Load earlier messages</Button></div>}
        {messages.length === 0 ? (
          <p className="mt-10 text-center text-plum-700">You matched! Break the ice with something friendly.</p>
        ) : (
          <ul className="space-y-2">
            {messages.map((m) => (
              <li key={m.id} className={`flex ${m.mine ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] rounded-3xl px-4 py-2 ${m.mine ? 'rounded-br-md bg-gradient-to-br from-bubblegum to-bubblegum-300' : 'rounded-bl-md bg-lavender-200'} ${m.pending ? 'opacity-70' : ''}`}>
                  <p className="whitespace-pre-wrap break-words">{m.content}</p>
                  <p className="mt-0.5 text-right text-[11px] text-plum-700">
                    {m.failed ? (
                      <span className="font-bold text-bubblegum-700">Not sent · <button type="button" className="underline" onClick={() => retry(m)}>Retry</button></span>
                    ) : m.pending ? (
                      'Sending…'
                    ) : (
                      <time dateTime={m.createdAt}>{fmt.format(new Date(m.createdAt))}</time>
                    )}
                  </p>
                </div>
              </li>
            ))}
          </ul>
        )}
        <div ref={endRef} />
      </div>

      <p className="h-5 px-2 text-sm text-plum-700" role="status" aria-live="polite">{partnerTyping ? `${match.partner.nickname} is typing…` : ''}</p>

      <form onSubmit={submit} className="space-y-2">
        {sendError && <ErrorMessage message={sendError} />}
        <div className="flex items-end gap-2">
          <div className="flex-1">
            <label htmlFor="msg" className="sr-only">Message</label>
            <textarea id="msg" rows={1} value={draft} maxLength={MAX} onChange={(e) => onDraft(e.target.value)} onBlur={() => { window.clearTimeout(typingIdle.current); typingSent.current = 0; sendTyping(false); }} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); e.currentTarget.form?.requestSubmit(); } }} placeholder="Write a message…" className="max-h-32 w-full resize-none rounded-3xl border-0 bg-white px-4 py-3 shadow-sm ring-1 ring-plum/15 focus-visible:ring-2 focus-visible:ring-lavender-700" />
            {draft.length > MAX - 200 && <p className="mt-1 text-right text-xs text-plum-700" aria-live="polite">{draft.length}/{MAX}</p>}
          </div>
          <Button type="submit" disabled={!draft.trim()}>Send</Button>
        </div>
      </form>

      <ConfirmModal open={dialog === 'unmatch'} title={`Unmatch ${match.partner.nickname}?`} body="This ends the conversation for both of you. It can't be undone." confirmLabel="Unmatch" busy={busy} onConfirm={() => void endChat('unmatch')} onClose={() => setDialog(null)} />
      <ConfirmModal open={dialog === 'block'} title={`Block ${match.partner.nickname}?`} body="You'll disappear from each other everywhere in Hush and this chat ends. You can unblock later in Settings." confirmLabel="Block" busy={busy} onConfirm={() => void endChat('block')} onClose={() => setDialog(null)} />
      <ReportModal target={dialog === 'report' ? match.partner : null} onClose={() => setDialog(null)} />
    </div>
  );
}
