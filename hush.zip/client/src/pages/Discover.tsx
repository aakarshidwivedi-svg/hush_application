import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ConfirmModal } from '../components/ConfirmModal';
import { Heart } from '../components/Illustrations';
import { ProfileCard } from '../components/ProfileCard';
import { ReportModal } from '../components/ReportModal';
import { SwipeDeck, type SwipeDirection } from '../components/SwipeDeck';
import { Button, LinkButton } from '../components/ui/Button';
import { CardSkeleton, EmptyState, ErrorMessage } from '../components/ui/States';
import { useAuth } from '../hooks/useAuth';
import { api, ApiError } from '../services/api';
import type { DiscoverCard } from '../types';

export default function Discover() {
  const { me } = useAuth();
  const [cards, setCards] = useState<DiscoverCard[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [more, setMore] = useState(false);
  const [error, setError] = useState<{ message: string; code?: string } | null>(null);
  const [pending, setPending] = useState<Set<string>>(new Set());
  const [announce, setAnnounce] = useState('');
  const [reporting, setReporting] = useState<DiscoverCard | null>(null);
  const [blocking, setBlocking] = useState<DiscoverCard | null>(null);
  const [blockBusy, setBlockBusy] = useState(false);
  const run = useRef(0);
  // "Not now" is a private note to self, stored on the server so the same person is not shown again. Nobody
  // else can see it and it says nothing about interest. `skipped` hides the card immediately.
  const [skipped, setSkipped] = useState<Set<string>>(new Set());
  // People already swiped past in the deck this visit (a crush stays withdrawable from Matches/Discover later).
  const [passed, setPassed] = useState<Set<string>>(new Set());
  const MODE_KEY = 'hush:discover-mode';
  const [mode, setMode] = useState<'swipe' | 'browse'>(() => {
    try {
      const saved = localStorage.getItem(MODE_KEY);
      if (saved === 'swipe' || saved === 'browse') return saved;
    } catch { /* storage unavailable */ }
    return window.matchMedia?.('(pointer: coarse)').matches ? 'swipe' : 'browse';
  });
  const chooseMode = (m: 'swipe' | 'browse') => { setMode(m); try { localStorage.setItem(MODE_KEY, m); } catch { /* ignore */ } };
  const sentinel = useRef<HTMLDivElement | null>(null);

  const load = useCallback(async (next: string | null) => {
    const id = ++run.current;
    next ? setMore(true) : setLoading(true);
    setError(null);
    try {
      const page = await api.discover(next);
      if (id !== run.current) return;
      setCards((prev) => (next ? [...prev, ...page.items.filter((p) => !prev.some((q) => q.id === p.id))] : page.items));
      setCursor(page.nextCursor);
    } catch (e) {
      if (id === run.current) setError({ message: e instanceof Error ? e.message : 'Something went wrong', ...(e instanceof ApiError ? { code: e.code } : {}) });
    } finally {
      if (id === run.current) { setLoading(false); setMore(false); }
    }
  }, []);

  useEffect(() => { if (me?.account.eligible) void load(null); else setLoading(false); }, [me?.account.eligible, load]);

  // Someone you just matched with leaves your Discover feed (the server already excludes them on the next load).
  useEffect(() => {
    const onMatch = (e: Event) => {
      const ids = new Set((e as CustomEvent<{ partnerIds?: string[] }>).detail?.partnerIds ?? []);
      if (ids.size > 0) setCards((cs) => cs.filter((c) => !ids.has(c.id)));
    };
    window.addEventListener('hush:match', onMatch);
    return () => window.removeEventListener('hush:match', onMatch);
  }, []);

  function skip(card: DiscoverCard) {
    setSkipped((prev) => new Set(prev).add(card.id));
    setAnnounce(`Skipped ${card.nickname}.`);
    void api.skipProfile(card.id).catch(() => { /* best effort: the card is already hidden for this visit */ });
  }

  async function resetSkipped() {
    setSkipped(new Set());
    setPassed(new Set());
    await api.resetSkips().catch(() => undefined);
    void load(null);
  }

  function swipe(card: DiscoverCard, dir: SwipeDirection) {
    setPassed((p) => new Set(p).add(card.id));
    if (dir === 'left') return skip(card);
    if (!card.crushed) void toggleCrush(card); // same generic message as the button: never reveals whether it is mutual
  }

  async function toggleCrush(card: DiscoverCard) {
    setPending((p) => new Set(p).add(card.id));
    try {
      if (card.crushed) {
        await api.withdrawCrush(card.id);
        setAnnounce(`Crush on ${card.nickname} withdrawn.`);
      } else {
        await api.sendCrush(card.id);
        window.dispatchEvent(new Event('hush:crush'));
        // Same message every time: it never reveals whether the interest is mutual.
        setAnnounce(`Secret crush sent to ${card.nickname}. They'll only find out if it's mutual.`);
      }
      setCards((cs) => cs.map((c) => (c.id === card.id ? { ...c, crushed: !c.crushed } : c)));
    } catch (e) {
      if (e instanceof ApiError && e.status === 404) {
        setCards((cs) => cs.filter((c) => c.id !== card.id)); // no longer available
        setAnnounce('That profile is no longer available.');
      } else setAnnounce(e instanceof Error ? e.message : 'Something went wrong');
    } finally {
      setPending((p) => { const n = new Set(p); n.delete(card.id); return n; });
    }
  }

  async function confirmBlock() {
    if (!blocking) return;
    setBlockBusy(true);
    try {
      await api.block(blocking.id);
      setCards((cs) => cs.filter((c) => c.id !== blocking.id));
      setAnnounce(`${blocking.nickname} blocked.`);
    } catch (e) {
      setAnnounce(e instanceof Error ? e.message : 'Could not block');
    } finally {
      setBlockBusy(false);
      setBlocking(null);
    }
  }

  const visible = cards.filter((c) => !skipped.has(c.id));
  const deck = visible.filter((c) => !passed.has(c.id));

  // Scrolling: load the next page when the end of the list comes into view; keep the deck topped up.
  useEffect(() => {
    if (mode !== 'browse' || !cursor || more || loading || error) return;
    const el = sentinel.current;
    if (!el || typeof IntersectionObserver === 'undefined') return;
    const io = new IntersectionObserver((entries) => { if (entries.some((e) => e.isIntersecting)) void load(cursor); }, { rootMargin: '600px 0px' });
    io.observe(el);
    return () => io.disconnect();
  }, [mode, cursor, more, loading, error, load, visible.length]);
  useEffect(() => {
    if (mode === 'swipe' && cursor && !more && !loading && !error && deck.length <= 3) void load(cursor);
  }, [mode, cursor, more, loading, error, deck.length, load]);

  if (me && me.account.status === 'SUSPENDED') {
    return <div className="page py-12"><EmptyState title="Your account is paused">It's been suspended by our moderators. Read the <Link className="font-bold underline" to="/guidelines">Community Guidelines</Link> or <Link className="font-bold underline" to="/contact">contact us</Link>.</EmptyState></div>;
  }
  if (me && !me.account.eligible) {
    return (
      <div className="page py-12">
        <EmptyState title="Almost there!" action={<LinkButton to="/settings" variant="secondary">Review my profile</LinkButton>}>
          {me.account.missing.includes('campus_verification')
            ? "You signed up without a campus email, so we can't confirm your campus yet. A moderator will verify it (or sign in with an email from your campus)."
            : 'Your account is waiting on verification'}
          {me.account.missing.includes('age_verification') ? ' This campus also needs extra age verification, which a moderator completes.' : ''} You'll appear in Discover as soon as it's done.
        </EmptyState>
      </div>
    );
  }


  const cardFooter = (c: DiscoverCard, withSkip: boolean) => (
    <div className="space-y-2">
      {withSkip && <Button className="w-full" variant={c.crushed ? 'secondary' : 'primary'} loading={pending.has(c.id)} aria-pressed={c.crushed} onClick={() => void toggleCrush(c)}>
        <Heart className={`h-5 w-5 ${c.crushed ? 'text-bubblegum-700' : ''}`} />
        {c.crushed ? 'Crush sent · undo' : 'Secret crush'}
      </Button>}
      <div className="flex items-center justify-between gap-2 text-sm">
        {withSkip ? <Button size="sm" variant="ghost" onClick={() => skip(c)} aria-label={`Skip ${c.nickname}`}>Not now</Button> : <span />}
        <span className="flex gap-4">
          <button type="button" className="font-semibold text-plum-700 underline-offset-2 hover:underline" onClick={() => setReporting(c)}>Report</button>
          <button type="button" className="font-semibold text-plum-700 underline-offset-2 hover:underline" onClick={() => setBlocking(c)}>Block</button>
        </span>
      </div>
    </div>
  );

  return (
    <div className="page py-8">
      <div className="mb-6">
        <h1 className="text-4xl font-bold">Discover</h1>
        <p className="mt-1 text-plum-700">Students from {me?.campus.name}. Tap the heart on anyone you like — it stays secret unless it&rsquo;s mutual.</p>
      </div>
      <div className="mb-4 inline-flex rounded-full bg-lavender-200 p-1" role="group" aria-label="Browsing style">
        {(['swipe', 'browse'] as const).map((m) => (
          <button key={m} type="button" aria-pressed={mode === m} onClick={() => chooseMode(m)} className={`rounded-full px-4 py-1.5 text-sm font-bold focus-visible:outline focus-visible:outline-2 focus-visible:outline-lavender-700 ${mode === m ? 'bg-white text-plum shadow-sm' : 'text-plum-700'}`}>
            {m === 'swipe' ? 'Swipe' : 'Browse'}
          </button>
        ))}
      </div>
      <p className="sr-only" role="status" aria-live="polite">{announce}</p>
      {announce && <p className="mb-4 rounded-2xl bg-lavender-200 px-4 py-2 text-sm font-semibold" aria-hidden="true">{announce}</p>}

      {error?.code === 'PROFILE_INCOMPLETE' ? (
        <EmptyState title="Finish your profile first" action={<LinkButton to="/onboarding">Add photos &amp; interests</LinkButton>}>A photo and at least three interests help people say hi.</EmptyState>
      ) : error && cards.length === 0 ? (
        <ErrorMessage message={error.message} onRetry={() => void load(null)} />
      ) : loading ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" aria-busy="true" aria-label="Loading profiles">{[0, 1, 2, 3, 4, 5].map((n) => <CardSkeleton key={n} />)}</div>
      ) : (mode === 'browse' ? visible.length === 0 : deck.length === 0 && !more && !cursor) ? (
        <EmptyState title="You've seen everyone for now" action={<Button variant="secondary" onClick={() => void resetSkipped()}>Refresh &amp; bring back skipped</Button>}>
          New people show up as more students join. Check back soon!
        </EmptyState>
      ) : (
        mode === 'browse' ? (
        <>
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((c) => (
              <li key={c.id} className="h-full animate-enter">
                <ProfileCard profile={c} footer={cardFooter(c, true)} />
              </li>
            ))}
          </ul>
          {error && <div className="mt-6"><ErrorMessage message={error.message} onRetry={() => void load(cursor)} /></div>}
          {cursor && !error && <div ref={sentinel} className="mt-8 text-center"><Button variant="secondary" loading={more} onClick={() => void load(cursor)}>Show more people</Button></div>}
        </>
        ) : (
          <div>
            {deck[0] ? (
              <>
                <SwipeDeck
                  current={deck[0].id}
                  rightLabel="Crush"
                  leftLabel="Not now"
                  disabled={pending.has(deck[0].id)}
                  onSwipe={(dir) => deck[0] && swipe(deck[0], dir)}
                  next={deck[1] ? <ProfileCard profile={deck[1]} as="div" /> : undefined}
                >
                  <ProfileCard profile={deck[0]} footer={cardFooter(deck[0], false)} />
                </SwipeDeck>
                <div className="mx-auto mt-4 flex max-w-sm items-center justify-between gap-3">
                  <Button variant="secondary" onClick={() => swipe(deck[0]!, 'left')}>← Not now</Button>
                  <Button variant="primary" loading={pending.has(deck[0].id)} onClick={() => swipe(deck[0]!, 'right')}>Secret crush →</Button>
                </div>
                <p className="mt-3 text-center text-sm text-plum-700">Swipe right for a secret crush, left for not now — or use the buttons or the ← → keys.</p>
              </>
            ) : (
              <div className="py-10 text-center" aria-busy="true"><p className="text-plum-700">Finding more people…</p></div>
            )}
            {error && <div className="mt-6"><ErrorMessage message={error.message} onRetry={() => void load(cursor)} /></div>}
          </div>
        )
      )}

      <ReportModal target={reporting} onClose={() => setReporting(null)} />
      <ConfirmModal open={blocking !== null} title={`Block ${blocking?.nickname ?? ''}?`} body="You won't see each other anywhere in Hush, and any chat or pending crush between you ends. You can unblock later in Settings." confirmLabel="Block" busy={blockBusy} onConfirm={() => void confirmBlock()} onClose={() => setBlocking(null)} />
    </div>
  );
}
