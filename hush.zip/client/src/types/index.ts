export interface Campus { id: string; name: string; emailDomains: string[] }

export interface InterestRef { id: string; name: string }
export interface InterestCategory { category: string; interests: InterestRef[] }

/** Short-lived signed image URLs. `url` is the full size, `thumbUrl` the card size. */
export interface PhotoRef { url: string; thumbUrl: string; width: number; height: number }
export interface OwnPhoto extends PhotoRef { id: string; isPrimary: boolean; order: number }

export interface Me {
  id: string;
  nickname: string;
  bio: string;
  interests: InterestRef[];
  photo: PhotoRef | null;
  photoCount: number;
  discoverable: boolean;
  campus: { id: string; name: string };
  /** A profile needs at least one photo and 3 interests before it can reach Discover. */
  profile: { complete: boolean; missing: ('photos' | 'interests')[] };
  account: {
    status: 'ACTIVE' | 'SUSPENDED' | 'DELETED';
    ageStatus: 'UNVERIFIED' | 'SELF_ATTESTED' | 'VERIFIED';
    campusStatus: 'UNVERIFIED' | 'VERIFIED';
    eligible: boolean;
    missing: string[];
  };
}

/** What a card needs to render someone's approved public profile. */
export interface PublicProfile { nickname: string; bio: string; interests: InterestRef[]; photo: PhotoRef | null }

export interface DiscoverCard extends PublicProfile {
  id: string;
  crushed: boolean;
  /** Interests both of you chose to show, and a plain-language reason for the ranking (null when nothing is shared). */
  sharedInterestIds: string[];
  reason: string | null;
}
export interface PartnerCard extends PublicProfile { id: string }
export interface MatchView {
  id: string;
  createdAt: string;
  partner: PartnerCard;
  lastMessage: { preview: string; createdAt: string; mine: boolean } | null;
  unreadCount: number;
}
export interface Message {
  id: string;
  content: string;
  createdAt: string;
  mine: boolean;
  /** Client-only: a message that has not been confirmed by the server yet. */
  pending?: boolean;
  /** Client-only: sending failed; the same clientId is reused when retrying. */
  failed?: boolean;
  clientId?: string;
}
export interface AppNotification {
  id: string;
  type: 'MATCH' | 'MESSAGE';
  matchId: string;
  createdAt: string;
  read: boolean;
  /** For MESSAGE: how many new messages this stands for. */
  count: number;
  partner: { nickname: string };
}
export interface BlockedUser { id: string; nickname: string; blockedAt: string }
export type ReportReason = 'HARASSMENT' | 'SPAM' | 'FAKE_PROFILE' | 'INAPPROPRIATE_CONTENT' | 'UNDERAGE' | 'OTHER';

export type ReportStatus = 'OPEN' | 'REVIEWING' | 'ACTIONED' | 'DISMISSED';
export interface ModReport {
  id: string;
  reason: ReportReason;
  details: string | null;
  status: ReportStatus;
  createdAt: string;
  reporter: { id: string; nickname: string | null };
  target: {
    id: string;
    nickname: string | null;
    bio: string | null;
    accountStatus: 'ACTIVE' | 'SUSPENDED' | 'DELETED';
    campusStatus: 'UNVERIFIED' | 'VERIFIED';
    ageStatus: 'UNVERIFIED' | 'SELF_ATTESTED' | 'VERIFIED';
    reportsReceived: number;
    blockedByCount: number;
  };
  reviewedAt: string | null;
  reviewedBy: string | null;
  resolutionNote: string | null;
}
export interface ModAuditEntry {
  id: string;
  action: string;
  reason: string;
  detail: string | null;
  createdAt: string;
  moderator: string;
  targetId: string | null;
  reportId: string | null;
}
export interface ModPage<T> { items: T[]; total: number; limit: number; offset: number }
export interface ModReportQuery { status?: string; reason?: string; from?: string; to?: string; limit?: number; offset?: number }
export type ModUserAction = 'suspend' | 'reinstate' | 'verify-age' | 'verify-campus';
