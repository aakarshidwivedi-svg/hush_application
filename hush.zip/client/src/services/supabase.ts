import { createClient } from '@supabase/supabase-js';

// Only the public anon key lives in the browser. The API verifies every access token itself.
const url = import.meta.env.VITE_SUPABASE_URL || 'http://localhost:54321';
const anon = import.meta.env.VITE_SUPABASE_ANON_KEY || 'public-anon-key-not-configured';

export const supabase = createClient(url, anon, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});
