import type { BlockedUser, ModAuditEntry, ModPage, ModReport, ModReportQuery, ModUserAction, Campus, DiscoverCard, InterestCategory, AppNotification, MatchView, Me, Message, OwnPhoto, ReportReason } from '../types';
import { supabase } from './supabase';

export const BASE = (import.meta.env.VITE_API_URL || 'http://localhost:4000/api/v1').replace(/\/+$/, '');

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
  /** Field-level messages from a 422, keyed by field path. */
  get fieldErrors(): Record<string, string> {
    const out: Record<string, string> = {};
    if (Array.isArray(this.details)) {
      for (const d of this.details as { path: string; message: string }[]) if (d.path) out[d.path] = d.message;
    }
    return out;
  }
}

interface Envelope<T> { data: T; page?: { nextCursor: string | null; total?: number; limit?: number; offset?: number } }

async function raw<T>(method: string, path: string, body?: unknown, opts: { auth?: boolean } = {}): Promise<Envelope<T>> {
  const headers: Record<string, string> = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (opts.auth !== false) {
    const { data } = await supabase.auth.getSession();
    if (data.session) headers.Authorization = `Bearer ${data.session.access_token}`;
  }
  let res: Response;
  try {
    res = await fetch(`${BASE}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new ApiError(0, 'NETWORK', "We couldn't reach Hush. Check your connection and try again.");
  }
  const json = (await res.json().catch(() => null)) as (Envelope<T> & { error?: { code: string; message: string; details?: unknown } }) | null;
  if (!res.ok) {
    const e = json?.error;
    throw new ApiError(res.status, e?.code ?? 'ERROR', e?.message ?? 'Something went wrong', e?.details);
  }
  return json as Envelope<T>;
}

async function request<T>(method: string, path: string, body?: unknown, opts: { auth?: boolean } = {}): Promise<T> {
  return (await raw<T>(method, path, body, opts)).data;
}

async function paged<T>(path: string): Promise<{ items: T[]; nextCursor: string | null }> {
  const env = await raw<T[]>('GET', path);
  return { items: env.data, nextCursor: env.page?.nextCursor ?? null };
}

async function modPage<T>(path: string, q: Record<string, string | number | undefined>): Promise<ModPage<T>> {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(q)) if (v !== undefined && v !== '') qs.set(k, String(v));
  const env = await raw<T[]>('GET', `${path}?${qs}`);
  return { items: env.data, total: env.page?.total ?? env.data.length, limit: env.page?.limit ?? env.data.length, offset: env.page?.offset ?? 0 };
}

const get = <T,>(p: string) => request<T>('GET', p);
const post = <T,>(p: string, b?: unknown) => request<T>('POST', p, b ?? {});

export interface ProfileInput {
  nickname: string;
  bio: string;
  discoverable: boolean;
}

/**
 * Upload one already-compressed photo. XMLHttpRequest rather than fetch because only XHR reports
 * real upload progress. The body is the image itself; the server re-validates and re-encodes it.
 */
async function uploadPhoto(blob: Blob, onProgress: (fraction: number) => void, signal?: AbortSignal): Promise<OwnPhoto> {
  const { data } = await supabase.auth.getSession();
  return new Promise<OwnPhoto>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${BASE}/profiles/me/photos`);
    if (data.session) xhr.setRequestHeader('Authorization', `Bearer ${data.session.access_token}`);
    xhr.setRequestHeader('Content-Type', blob.type);
    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(e.loaded / e.total); };
    xhr.onerror = () => reject(new ApiError(0, 'NETWORK', "We couldn't reach Hush. Check your connection and try again."));
    xhr.onabort = () => reject(new ApiError(0, 'ABORTED', 'Upload cancelled'));
    xhr.onload = () => {
      let json: { data?: OwnPhoto; error?: { code: string; message: string; details?: unknown } } | null = null;
      try { json = JSON.parse(xhr.responseText); } catch { /* non-JSON error page */ }
      if (xhr.status >= 200 && xhr.status < 300 && json?.data) return resolve(json.data);
      const e = json?.error;
      reject(new ApiError(xhr.status, e?.code ?? 'ERROR', xhr.status === 429 ? 'Too many uploads — please wait a bit.' : (e?.message ?? 'Upload failed'), e?.details));
    };
    signal?.addEventListener('abort', () => xhr.abort());
    xhr.send(blob);
  });
}

export const api = {
  campuses: () => request<Campus[]>('GET', '/campuses', undefined, { auth: false }),
  completeProfile: (b: ProfileInput & { campusId: string; ageAttestation: true; inviteCode?: string }) => post<Me>('/auth/complete-profile', b),
  myInvite: () => get<{ code: string; joined: number }>('/invites/me'),
  me: () => get<Me>('/profiles/me'),
  updateMe: (b: Partial<ProfileInput>) => request<Me>('PATCH', '/profiles/me', b),
  interestCatalog: () => get<InterestCategory[]>('/interests'),
  setInterests: (interestIds: string[]) => request<Me>('PUT', '/profiles/me/interests', { interestIds }),
  photos: () => get<OwnPhoto[]>('/profiles/me/photos'),
  uploadPhoto,
  reorderPhotos: (photoIds: string[]) => request<OwnPhoto[]>('PATCH', '/profiles/me/photos/reorder', { photoIds }),
  setPrimaryPhoto: (id: string) => request<OwnPhoto[]>('PATCH', `/profiles/me/photos/${id}/primary`, {}),
  deletePhoto: (id: string) => request<OwnPhoto[]>('DELETE', `/profiles/me/photos/${id}`),
  discover(cursor?: string | null) {
    const qs = new URLSearchParams({ limit: '12' });
    if (cursor) qs.set('cursor', cursor);
    return paged<DiscoverCard>(`/profiles/discover?${qs}`);
  },
  skipProfile: (id: string) => post<{ status: string }>(`/profiles/discover/skips/${id}`),
  resetSkips: () => request<{ status: string }>('DELETE', '/profiles/discover/skips'),
  sendCrush: (id: string) => post<{ status: string }>(`/crushes/${id}`),
  withdrawCrush: (id: string) => request<{ status: string }>('DELETE', `/crushes/${id}`),
  matches: () => get<MatchView[]>('/matches'),
  match: (id: string) => get<MatchView>(`/matches/${id}`),
  unmatch: (id: string) => post<{ status: string }>(`/matches/${id}/unmatch`),
  messages: (id: string, q: { after?: string; before?: string } = {}) => {
    const qs = new URLSearchParams({ limit: '50' });
    if (q.after) qs.set('after', q.after);
    if (q.before) qs.set('before', q.before);
    return paged<Message>(`/matches/${id}/messages?${qs}`);
  },
  sendMessage: (id: string, content: string, clientId?: string) => post<Message>(`/matches/${id}/messages`, { content, ...(clientId ? { clientId } : {}) }),
  markConversationRead: (id: string) => post<{ status: string }>(`/matches/${id}/read`),
  notifications: async (filter: 'unread' | 'all' = 'unread') => {
    const env = await raw<AppNotification[]>('GET', `/notifications?filter=${filter}`);
    return { items: env.data, unreadCount: env.page?.total ?? env.data.filter((n) => !n.read).length };
  },
  markNotificationsRead: (sel: { ids?: string[]; type?: 'MATCH' | 'MESSAGE' } = {}) => post<{ marked: number }>('/notifications/read', sel),
  markNotificationRead: (id: string) => post<{ status: string }>(`/notifications/${id}/read`),
  block: (id: string) => post<{ status: string }>(`/users/${id}/block`),
  unblock: (id: string) => request<{ status: string }>('DELETE', `/users/${id}/block`),
  blocked: () => get<BlockedUser[]>('/blocks'),
  report: (b: { targetId: string; reason: ReportReason; details?: string }) => post<{ status: string }>('/reports', b),
  // ---- Moderation (the server decides who is a moderator; these 404 for everyone else) ----
  modMe: () => get<{ moderator: true }>('/moderation/me'),
  modReports: (q: ModReportQuery) => modPage<ModReport>('/moderation/reports', { ...q }),
  modReport: (id: string) => get<{ report: ModReport; history: ModAuditEntry[] }>(`/moderation/reports/${id}`),
  modReview: (id: string, b: { status: 'REVIEWING' | 'ACTIONED' | 'DISMISSED'; note?: string }) => request<{ status: string }>('PATCH', `/moderation/reports/${id}`, b),
  modAudit: (q: { limit?: number; offset?: number; targetId?: string }) => modPage<ModAuditEntry>('/moderation/audit', { ...q }),
  modUser: (userId: string, action: ModUserAction, b: { reason: string; reportId?: string }) => post<{ status: string }>(`/moderation/users/${userId}/${action}`, b),
  deleteAccount: () => request<{ status: string }>('DELETE', '/account', { confirm: 'DELETE' }),
};
