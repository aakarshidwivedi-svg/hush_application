import AxeBuilder from '@axe-core/playwright';
import { expect, test } from '@playwright/test';
import { onboard, person, signedInContext } from './helpers';

const CAMPUS = 'Invite College';

test('invite a friend: personal link → friend joins → inviter sees a count, never a name', async ({ browser }) => {
  const inviter = person('ivy', CAMPUS);
  const friend = person('finn', CAMPUS);

  const ictx = await signedInContext(browser, inviter);
  const ipage = await ictx.newPage();
  await onboard(ipage, inviter);
  await ipage.goto('/settings');
  await expect(ipage.getByRole('heading', { name: 'Invite friends' })).toBeVisible();
  await expect(ipage.getByText('No one has joined with your link yet.')).toBeVisible();
  const link = await ipage.getByLabel('Your invite link').inputValue();
  expect(link).toMatch(/\/\?invite=[A-Z2-7]{10}$/);
  await ipage.getByRole('button', { name: 'Copy link' }).click();
  await expect(ipage.getByRole('status').filter({ hasText: /copied|copy it/i })).toBeVisible();
  const axe = await new AxeBuilder({ page: ipage }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(axe.violations.map((v) => `${v.id}: ${v.help}`)).toEqual([]);

  // The friend follows the link (signed out first: a friendly note, and the code leaves the address bar).
  const anon = await (await browser.newContext()).newPage();
  await anon.goto(new URL(link).pathname + new URL(link).search);
  await anon.goto('/signup');
  await expect(anon.getByText('A friend invited you to Hush')).toBeVisible();
  await expect(anon.locator('body')).not.toContainText(inviter.nickname);

  // …then signs in, follows the link again and finishes onboarding. The code is credited exactly once.
  const fctx = await signedInContext(browser, friend);
  const fpage = await fctx.newPage();
  await fpage.goto(new URL(link).pathname + new URL(link).search);
  await expect(fpage).not.toHaveURL(/invite=/);
  await onboard(fpage, friend);

  await ipage.reload();
  await expect(ipage.getByText('1 friend has joined with your link.')).toBeVisible();
  await expect(ipage.locator('body')).not.toContainText(friend.nickname);
  await ictx.close();
  await fctx.close();
});

test('a junk invite code is ignored: no note, no error, and it disappears from the address bar', async ({ browser }) => {
  const page = await (await browser.newContext()).newPage();
  await page.goto('/?invite=not-a-real-code');
  await expect(page).not.toHaveURL(/invite=/);
  await page.goto('/signup');
  await expect(page.getByText('A friend invited you to Hush')).toHaveCount(0);
  await expect(page.getByRole('heading', { name: 'Join Hush' })).toBeVisible();
});
