import { randomUUID } from 'node:crypto';
import { SignJWT } from 'jose';
import sharp from 'sharp';
import pg from 'pg';
import { expect, type BrowserContext, type Browser, type Page } from '@playwright/test';
import { E2E } from '../playwright.config';

export const DEFAULT_CAMPUS = 'Hush University';
export interface Person { sub: string; email: string; nickname: string; campus: string }

/** Each spec file uses its own campus so people created by one spec never appear in another's Discover. */
export function person(label: string, campus = DEFAULT_CAMPUS): Person {
  const tag = randomUUID().slice(0, 6);
  return { sub: randomUUID(), email: `${label}.${tag}@hush.edu`, nickname: `${label}_${tag}`, campus };
}

async function token(p: Person, email = p.email): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  return new SignJWT({ email, email_verified: true, role: 'authenticated' })
    .setProtectedHeader({ alg: 'HS256' })
    .setSubject(p.sub)
    .setIssuer(`${E2E.supabaseUrl}/auth/v1`)
    .setAudience('authenticated')
    .setIssuedAt(now - 5)
    .setExpirationTime(now + 3600)
    .sign(new TextEncoder().encode(E2E.jwtSecret));
}

/** A browser context already "signed in" as `p` (what supabase-js would have in localStorage). */
export async function signedInContext(browser: Browser, p: Person, email = p.email): Promise<BrowserContext> {
  const access_token = await token(p, email);
  const now = Math.floor(Date.now() / 1000);
  const session = {
    access_token,
    refresh_token: 'e2e-refresh',
    token_type: 'bearer',
    expires_in: 3600,
    expires_at: now + 3600,
    user: { id: p.sub, aud: 'authenticated', role: 'authenticated', email, email_confirmed_at: new Date().toISOString(), app_metadata: {}, user_metadata: {}, created_at: new Date().toISOString() },
  };
  const context = await browser.newContext();
  await context.addInitScript(([key, value]) => window.localStorage.setItem(key as string, value as string), ['sb-localhost-auth-token', JSON.stringify(session)]);
  return context;
}

/** A real image (decoded by the browser, re-encoded by the API) so uploads exercise the whole pipeline. */
export async function image(color = '#F9A8D4', width = 480, height = 600, format: 'png' | 'jpeg' | 'webp' = 'png'): Promise<Buffer> {
  const img = sharp({ create: { width, height, channels: 3, background: color } });
  return format === 'png' ? img.png().toBuffer() : format === 'jpeg' ? img.jpeg().toBuffer() : img.webp().toBuffer();
}

export const MIME = { png: 'image/png', jpeg: 'image/jpeg', webp: 'image/webp' } as const;

/** Upload one generated photo through the photo manager and wait until it is saved. */
export async function addPhoto(page: Page, color: string, name = 'photo.png', format: 'png' | 'jpeg' | 'webp' = 'png') {
  const before = await page.getByRole('list', { name: 'Your photos' }).getByRole('listitem').count();
  await page.locator('#photo-input').setInputFiles({ name, mimeType: MIME[format], buffer: await image(color, 480, 600, format) });
  await expect(page.getByText('Preview — not saved yet')).toBeVisible();
  await page.getByRole('button', { name: /^Upload 1 photo$/ }).click();
  await expect(page.getByRole('list', { name: 'Your photos' }).getByRole('listitem')).toHaveCount(before + 1);
}

export const DEFAULT_INTERESTS = ['Movies', 'Anime', 'Coffee'];

/** Walk the real five-step onboarding: campus → about you → photos → interests → preview. */
export async function onboard(page: Page, p: Person, bio = 'hello from e2e', interests: string[] = DEFAULT_INTERESTS) {
  await page.goto('/onboarding'); // where the email-confirmation link lands
  await page.getByLabel('Your campus').selectOption({ label: p.campus });
  await page.getByLabel('I confirm that I am 18 or older.').check();
  await page.getByRole('button', { name: 'Continue' }).click();

  await page.getByLabel('Nickname').fill(p.nickname);
  await page.getByLabel('Short bio').fill(bio);
  await page.getByRole('button', { name: 'Continue' }).click();

  await expect(page.getByRole('heading', { name: /Show us your vibe/ })).toBeFocused();
  await addPhoto(page, '#C4B5FD', `${p.nickname}.png`);
  await page.getByRole('button', { name: 'Continue' }).click();

  for (const name of interests) await page.getByRole('button', { name, exact: true }).click();
  await page.getByRole('button', { name: 'Continue' }).click();

  await expect(page.getByRole('heading', { name: /Your profile, your rules/ })).toBeVisible();
  await page.getByRole('button', { name: /Finish/ }).click();
  await page.waitForURL('**/discover');
}

/**
 * Insert complete, discoverable profiles straight into the e2e database (a photo row, three interests),
 * for tests that need a crowd. The person under test still goes through the real onboarding.
 */
export async function seedPeople(campus: string, people: { nickname: string; interests: string[] }[]): Promise<void> {
  const u = new URL(E2E.adminUrl);
  u.pathname = `/${E2E.dbName}`;
  const db = new pg.Client({ connectionString: u.toString() });
  await db.connect();
  try {
    const c = await db.query<{ id: string }>('SELECT id FROM campuses WHERE name = $1', [campus]);
    for (const p of people) {
      const u2 = await db.query<{ id: string }>(
        `INSERT INTO users (auth_subject, campus_id, age_status, campus_status, account_status) VALUES ($1, $2, 'SELF_ATTESTED', 'VERIFIED', 'ACTIVE') RETURNING id`,
        [randomUUID(), c.rows[0]!.id],
      );
      const id = u2.rows[0]!.id;
      await db.query(`INSERT INTO profiles (user_id, nickname, nickname_key, bio, discoverable) VALUES ($1, $2, $3, 'seeded for e2e', true)`, [id, p.nickname, p.nickname.toLowerCase()]);
      const interestIds = (await db.query<{ id: string }>('SELECT id FROM interests WHERE name = ANY($1::text[])', [p.interests])).rows.map((r) => r.id);
      await db.query('INSERT INTO user_interests (user_id, interest_id) SELECT $1, unnest($2::text[])', [id, interestIds]);
      const pid = randomUUID();
      await db.query(
        `INSERT INTO profile_photos (id, user_id, storage_path, thumb_path, width, height, display_order, is_primary) VALUES ($1, $2, $3, $4, 800, 1000, 0, true)`,
        [pid, id, `${randomUUID()}/${pid}.webp`, `${randomUUID()}/${pid}_thumb.webp`],
      );
    }
  } finally {
    await db.end();
  }
}
