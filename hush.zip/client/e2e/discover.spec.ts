import AxeBuilder from '@axe-core/playwright';
import { expect, test, type Page } from '@playwright/test';
import { onboard, person, seedPeople, signedInContext } from './helpers';

test.describe.configure({ mode: 'serial' });

const CAMPUS = 'Discover College';
const me = person('vera', CAMPUS);
const ALL = ['Movies', 'Anime', 'Coffee'];
let page: Page;

const cards = () => page.locator('article');
const crushes = (reqs: string[]) => reqs.filter((r) => r.startsWith('POST') && r.includes('/crushes/'));

test.beforeAll(async ({ browser }) => {
  // 15 people: one close match, one partial match, thirteen with nothing in common.
  await seedPeople(CAMPUS, [
    { nickname: 'close_match', interests: ALL },
    { nickname: 'partial_match', interests: ['Movies', 'Gym', 'Art'] },
    ...Array.from({ length: 13 }, (_, i) => ({ nickname: `other_${String(i).padStart(2, '0')}`, interests: ['Gym', 'Art', 'Pop'] })),
  ]);
  const ctx = await signedInContext(browser, me);
  page = await ctx.newPage();
  await onboard(page, me, 'hello from vera', ALL);
});

test('Browse: best matches come first, with a plain-language reason and shared interests highlighted', async () => {
  await page.getByRole('button', { name: 'Browse', exact: true }).click();
  await expect(cards().first()).toContainText('close_match');
  await expect(cards().first()).toContainText('You share interests in Movies, Anime and Coffee.');
  await expect(cards().nth(1)).toContainText('partial_match');
  await expect(cards().nth(1)).toContainText('You share an interest in Movies.');
  await expect(cards().nth(2)).not.toContainText('You share');
  await expect(page.locator('body')).not.toContainText(/likes you|crushing on you|admirer|popular/i);
});

test('Browse: scrolling loads the next page by itself (no button press)', async () => {
  // 15 people, 12 per page: the last three only arrive by scrolling down.
  await expect(cards()).toHaveCount(12);
  await cards().last().scrollIntoViewIfNeeded();
  await page.mouse.wheel(0, 4000);
  await expect(cards()).toHaveCount(15);
  await expect(page.getByRole('button', { name: 'Show more people' })).toHaveCount(0);
});

test('the chosen style is remembered, and Swipe shows one card at a time', async () => {
  await page.getByRole('button', { name: 'Swipe', exact: true }).click();
  await expect(cards()).toHaveCount(1);
  await expect(cards().first()).toContainText('close_match');
  await page.reload();
  await expect(page.getByRole('button', { name: 'Swipe', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await expect(cards()).toHaveCount(1);
});

test('Swipe: → sends a secret crush, ← skips, and both move to the next person', async () => {
  const reqs: string[] = [];
  page.on('request', (r) => reqs.push(`${r.method()} ${new URL(r.url()).pathname}`));
  await expect(cards().first()).toContainText('close_match');
  await page.keyboard.press('ArrowRight');
  await expect(cards().first()).toContainText('partial_match');
  await expect.poll(() => crushes(reqs).length).toBe(1);
  await expect(page.locator('[role="status"]').first()).toContainText('Secret crush sent to close_match');

  await page.keyboard.press('ArrowLeft');
  await expect(cards().first()).not.toContainText('partial_match');
  await expect.poll(() => reqs.filter((r) => r.startsWith('POST') && r.includes('/discover/skips/')).length).toBe(1);
  expect(crushes(reqs).length).toBe(1); // skipping sent no crush
});

test('Swipe: dragging the card past the threshold works, a short drag springs back', async () => {
  const reqs: string[] = [];
  page.on('request', (r) => reqs.push(`${r.method()} ${new URL(r.url()).pathname}`));
  const first = await cards().first().getByRole('heading', { level: 3 }).innerText();
  const box = (await cards().first().boundingBox())!;
  const y = box.y + 80;
  // Short drag: stays.
  await page.mouse.move(box.x + box.width / 2, y);
  await page.mouse.down();
  await page.mouse.move(box.x + box.width / 2 + 40, y, { steps: 4 });
  await page.mouse.up();
  await expect(cards().first()).toContainText(first!);
  expect(reqs.filter((r) => r.startsWith('POST'))).toEqual([]);
  // Long drag to the left: skipped.
  const box2 = (await cards().first().boundingBox())!;
  await page.mouse.move(box2.x + box2.width / 2, y);
  await page.mouse.down();
  await page.mouse.move(box2.x + box2.width / 2 - 260, y, { steps: 8 });
  await page.mouse.up();
  await expect(cards().first()).not.toContainText(first!);
  await expect.poll(() => reqs.filter((r) => r.includes('/discover/skips/')).length).toBe(1);
});

test('Swipe: skipped and already-crushed people do not come back after a reload', async () => {
  await page.reload();
  await expect(cards()).toHaveCount(1);
  const shown = await cards().first().innerText();
  expect(shown).not.toContain('partial_match'); // skipped earlier
  expect(shown).not.toContain('close_match'); // crushed earlier: now sorted after everyone new
});

test('Swipe has no accessibility violations and does not overflow sideways', async () => {
  const r = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(r.violations.map((v) => `${v.id}: ${v.help}`)).toEqual([]);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
});
