import AxeBuilder from '@axe-core/playwright';
import { expect, test, type BrowserContext, type Page } from '@playwright/test';
import { onboard, person, signedInContext } from './helpers';

test.describe.configure({ mode: 'serial' });

const ann = person('ann', 'Chat College');
const ben = person('ben', 'Chat College');
let annCtx: BrowserContext;
let benCtx: BrowserContext;
let a: Page;
let b: Page;
let chatPath = '';

const message = (p: Page) => p.getByLabel('Message', { exact: true });
const log = (p: Page, name: string) => p.getByRole('log', { name: `Conversation with ${name}` });
const send = async (p: Page, text: string) => {
  await message(p).fill(text);
  await p.getByRole('button', { name: 'Send', exact: true }).click();
};

test('two people match; the first one sees the match celebration live, without reloading', async ({ browser }) => {
  annCtx = await signedInContext(browser, ann);
  benCtx = await signedInContext(browser, ben);
  a = await annCtx.newPage();
  b = await benCtx.newPage();
  await onboard(a, ann);
  await onboard(b, ben);
  await a.goto('/discover');
  await a.locator('article', { hasText: ben.nickname }).getByRole('button', { name: /Secret crush/ }).click();
  await b.goto('/discover');
  await b.locator('article', { hasText: ann.nickname }).getByRole('button', { name: /Secret crush/ }).click();
  await expect(b.getByRole('dialog', { name: "It's a match!" })).toBeVisible();
  // Ann is sitting on Discover; the celebration is pushed to her over the socket (the old poll took up to 15s).
  await expect(a.getByRole('dialog', { name: "It's a match!" })).toBeVisible({ timeout: 5000 });
  await b.getByRole('dialog').getByRole('button', { name: 'Start chatting' }).click();
  await a.getByRole('dialog').getByRole('button', { name: 'Start chatting' }).click();
  await expect(b).toHaveURL(/\/matches\/[0-9a-f-]+$/);
  chatPath = new URL(b.url()).pathname;
});

test('messages arrive instantly, in order, with no reload and no polling delay', async () => {
  const t0 = Date.now();
  await send(a, 'hi ben, real time?');
  await expect(log(b, ann.nickname).getByText('hi ben, real time?')).toBeVisible({ timeout: 2500 });
  expect(Date.now() - t0).toBeLessThan(3500); // far below the old 4s poll
  await send(b, 'yes!');
  await expect(log(a, ben.nickname).getByText('yes!')).toBeVisible({ timeout: 2500 });
  await send(a, 'one');
  await send(a, 'two');
  await send(a, 'three');
  await expect(log(b, ann.nickname).getByRole('listitem')).toHaveCount(5);
  expect(await log(b, ann.nickname).getByRole('listitem').allInnerTexts().then((t) => t.map((x) => x.split('\n')[0]))).toEqual(['hi ben, real time?', 'yes!', 'one', 'two', 'three']);
  // No duplicates on the sender's side either.
  await expect(log(a, ben.nickname).getByRole('listitem')).toHaveCount(5);
});

test('typing is shown to the other person and goes away', async () => {
  await message(a).pressSequentially('typing…', { delay: 30 });
  await expect(b.getByText(`${ann.nickname} is typing…`)).toBeVisible({ timeout: 3000 });
  await message(a).fill('');
  await expect(b.getByText(`${ann.nickname} is typing…`)).toBeHidden({ timeout: 6000 });
});

test('unread counts show on the nav and the matches list, and clear once the chat is open', async ({ browser }) => {
  // Ben leaves the chat; Ann writes.
  await b.goto('/discover');
  await send(a, 'are you there?');
  await send(a, 'ben?');
  const nav = b.getByRole('navigation', { name: 'Main' });
  await expect(nav.getByRole('link', { name: /Matches/ })).toContainText('1 unread', { timeout: 5000 });
  await expect(nav.getByRole('link', { name: /Notifications/ })).toContainText('unread');
  await b.getByRole('link', { name: /Matches/ }).first().click();
  await expect(b.getByText('2 new messages')).toBeVisible();
  const axe = await new AxeBuilder({ page: b }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(axe.violations.map((v) => `${v.id}: ${v.help}`)).toEqual([]);
  await b.goto(chatPath);
  await expect(log(b, ann.nickname).getByText('ben?')).toBeVisible();
  await expect(nav.getByRole('link', { name: /Matches/ })).not.toContainText('unread', { timeout: 5000 });
});

test('the notifications page lists matches and messages, and marks them read', async () => {
  await b.goto('/discover');
  await send(a, 'one more');
  await b.goto('/notifications');
  await expect(b.getByRole('heading', { name: 'Notifications', level: 1 })).toBeVisible();
  await expect(b.getByText(`You and ${ann.nickname} matched!`)).toBeVisible();
  // One row per burst of unread messages: earlier ones were read above, this one is new.
  await expect(b.getByText(`${ann.nickname} sent you a new message`).first()).toBeVisible();
  await expect(b.getByText('New', { exact: true })).toHaveCount(1);
  const axe = await new AxeBuilder({ page: b }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(axe.violations.map((v) => `${v.id}: ${v.help}`)).toEqual([]);
  await b.getByRole('button', { name: 'Mark all as read' }).click();
  await expect(b.getByText('You’re all caught up.')).toBeVisible();
  await expect(b.getByRole('button', { name: 'Mark all as read' })).toBeDisabled();
});

test('a dropped connection: sending still works, and the other side catches up after reconnecting', async () => {
  await b.goto(chatPath);
  await expect(log(b, ann.nickname).getByText('one more')).toBeVisible();
  await benCtx.setOffline(true);
  await send(a, 'sent while ben is offline');
  await expect(log(a, ben.nickname).getByText('sent while ben is offline')).toBeVisible();
  await benCtx.setOffline(false);
  await expect(log(b, ann.nickname).getByText('sent while ben is offline')).toBeVisible({ timeout: 20_000 });
  await expect(log(b, ann.nickname).getByText('sent while ben is offline')).toHaveCount(1);
});

test('a failed send can be retried without creating a duplicate', async () => {
  await annCtx.setOffline(true);
  await send(a, 'queued while offline');
  await expect(a.getByText('Not sent').first()).toBeVisible({ timeout: 15_000 });
  await annCtx.setOffline(false);
  // Either the buffered send is delivered by itself on reconnect, or the person presses Retry. Both must end the same way.
  await a.getByRole('button', { name: 'Retry' }).click({ timeout: 4000 }).catch(() => undefined);
  await expect(a.getByText('Not sent')).toHaveCount(0, { timeout: 10_000 });
  await expect(log(b, ann.nickname).getByText('queued while offline')).toBeVisible({ timeout: 10_000 });
  await expect(log(a, ben.nickname).getByText('queued while offline')).toHaveCount(1);
  await expect(log(b, ann.nickname).getByText('queued while offline')).toHaveCount(1);
});

test('chat has no WCAG A/AA violations', async () => {
  const axe = await new AxeBuilder({ page: a }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(axe.violations.map((v) => `${v.id}: ${v.help}`)).toEqual([]);
});

test('blocking ends the conversation for the other person immediately, without a reload', async () => {
  await a.getByRole('button', { name: 'Chat options' }).click();
  await a.getByRole('menuitem', { name: 'block' }).click();
  await a.getByRole('dialog').getByRole('button', { name: 'Block' }).click();
  await a.waitForURL('**/matches');
  await expect(b.getByText('This conversation has ended')).toBeVisible({ timeout: 5000 });
  await expect(message(b)).toHaveCount(0);
  // The API agrees, whichever door is used.
  const status = await b.evaluate(async (path) => {
    const raw = Object.keys(localStorage).find((k) => k.endsWith('auth-token'))!;
    const token = JSON.parse(localStorage.getItem(raw)!).access_token as string;
    const id = path.split('/').pop();
    const r = await fetch(`http://localhost:4010/api/v1/matches/${id}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'still there?' }),
    });
    return r.status;
  }, chatPath);
  expect(status).toBe(404);
  await annCtx.close();
  await benCtx.close();
});
