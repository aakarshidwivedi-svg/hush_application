import AxeBuilder from '@axe-core/playwright';
import { expect, test } from '@playwright/test';
import { onboard, person, signedInContext, type Person } from './helpers';

test.describe.configure({ mode: 'serial' });

// MODERATOR_AUTH_SUBJECTS in playwright.config.ts lists this subject; nothing in the browser grants it.
const mod: Person = { sub: '00000000-0000-4000-8000-00000000aaaa', email: 'moderator.e2e@hush.edu', nickname: 'moderator_e2e', campus: 'Moderation College' };
const reporter = person('rita', 'Moderation College');
const target = person('troy', 'Moderation College');

test('set up: a moderator, a reporter and a reported person onboard', async ({ browser }) => {
  for (const p of [mod, reporter, target]) {
    const ctx = await signedInContext(browser, p);
    const page = await ctx.newPage();
    await onboard(page, p);
    await ctx.close();
  }
});

test('the reporter files a report from Discover', async ({ browser }) => {
  const ctx = await signedInContext(browser, reporter);
  const page = await ctx.newPage();
  await page.goto('/discover');
  await page.locator('article', { hasText: target.nickname }).getByRole('button', { name: 'Report' }).click();
  await page.getByLabel('Details (optional)').fill('e2e: keeps sending rude messages');
  await page.getByRole('button', { name: 'Send report' }).click();
  await expect(page.getByText('Report received')).toBeVisible();
  await ctx.close();
});

test('ordinary people never see the dashboard link, and the route sends them away', async ({ browser }) => {
  const ctx = await signedInContext(browser, reporter);
  const page = await ctx.newPage();
  await page.goto('/discover');
  await expect(page.getByRole('link', { name: 'Moderation' })).toHaveCount(0);
  await page.goto('/moderation');
  await page.waitForURL('**/discover');
  // And the API itself says 404, regardless of the UI.
  const status = await page.evaluate(async () => {
    const raw = Object.keys(localStorage).find((k) => k.endsWith('auth-token'))!;
    const token = JSON.parse(localStorage.getItem(raw)!).access_token as string;
    const r = await fetch('http://localhost:4010/api/v1/moderation/reports', { headers: { Authorization: `Bearer ${token}` } });
    return r.status;
  });
  expect(status).toBe(404);
  await ctx.close();
});

test('a moderator reviews, suspends, closes the report, and the audit log records every step', async ({ browser }) => {
  const ctx = await signedInContext(browser, mod);
  const page = await ctx.newPage();
  await page.goto('/discover');
  await page.getByRole('link', { name: 'Moderation' }).first().click();
  await expect(page.getByRole('heading', { name: 'Moderation', level: 1 })).toBeVisible();

  // Filters narrow the queue.
  await page.getByLabel('Category').selectOption('SPAM');
  await expect(page.getByText('Nothing matches these filters.')).toBeVisible();
  await page.getByLabel('Category').selectOption('');
  await page.getByLabel('Status').selectOption('OPEN');
  const row = page.getByRole('link', { name: new RegExp(target.nickname) });
  await expect(row).toBeVisible();
  const list = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(list.violations.map((v) => `${v.id}: ${v.help}`)).toEqual([]);
  await row.click();

  await expect(page.getByText('e2e: keeps sending rude messages')).toBeVisible();
  const detail = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(detail.violations.map((v) => `${v.id}: ${v.help}`)).toEqual([]);

  await page.getByRole('button', { name: 'Start review' }).click();
  await expect(page.getByText('Marked as under review.')).toBeVisible();

  // A decision needs a reason; the dialog refuses to submit without one.
  await page.getByRole('button', { name: 'Suspend account' }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('button', { name: 'Suspend account' }).click();
  await expect(dialog.getByText('Please give a reason')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(dialog).toBeHidden();
  await expect(page.getByText('Account', { exact: true }).locator('xpath=following-sibling::dd')).toHaveText('Active');

  await page.getByRole('button', { name: 'Suspend account' }).click();
  await dialog.getByLabel(/Reason/).fill('Repeated harassment, e2e');
  await dialog.getByRole('button', { name: 'Suspend account' }).click();
  await expect(page.getByText('Account suspended.')).toBeVisible();
  await expect(page.getByText('Account', { exact: true }).locator('xpath=following-sibling::dd')).toHaveText('Suspended');
  await expect(page.getByRole('button', { name: 'Reinstate account' })).toBeVisible();

  await page.getByRole('button', { name: 'Mark actioned' }).click();
  await dialog.getByLabel(/Reason/).fill('Suspended for harassment');
  await dialog.getByRole('button', { name: 'Mark actioned' }).click();
  await expect(page.getByText('Report marked as actioned.')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Dismiss report' })).toHaveCount(0);

  await page.getByRole('link', { name: '← All reports' }).click();
  await page.getByRole('tab', { name: 'Audit log' }).click();
  await expect(page.getByText('Suspended account')).toBeVisible();
  await expect(page.getByText('“Repeated harassment, e2e”')).toBeVisible();
  await expect(page.getByText('Report actioned')).toBeVisible();
  await expect(page.getByText('Marked under review')).toBeVisible();
  await ctx.close();
});

test('the suspended person is locked out of the app', async ({ browser }) => {
  const ctx = await signedInContext(browser, target);
  const page = await ctx.newPage();
  await page.goto('/discover');
  await expect(page.getByRole('button', { name: /secret crush/i })).toHaveCount(0);
  await expect(page.locator('body')).toContainText(/suspended/i);
  await ctx.close();
});

test('@mobile the dashboard is usable on a phone without sideways scrolling', async ({ browser }) => {
  const ctx = await signedInContext(browser, mod);
  const page = await ctx.newPage();
  await page.setViewportSize({ width: 412, height: 915 });
  await page.goto('/moderation');
  await expect(page.getByRole('heading', { name: 'Moderation', level: 1 })).toBeVisible();
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  expect(overflow).toBeLessThanOrEqual(1);
  await ctx.close();
});
