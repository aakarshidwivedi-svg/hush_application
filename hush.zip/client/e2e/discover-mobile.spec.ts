import { expect, test } from '@playwright/test';
import { onboard, person, seedPeople, signedInContext } from './helpers';

const CAMPUS = 'Phone College';

test('Swipe on a phone: the deck fits the screen and the buttons work @mobile', async ({ browser }) => {
  await seedPeople(CAMPUS, [
    { nickname: 'phone_one', interests: ['Movies', 'Anime', 'Coffee'] },
    { nickname: 'phone_two', interests: ['Gym', 'Art', 'Pop'] },
  ]);
  const p = person('mobile_vera', CAMPUS);
  const ctx = await signedInContext(browser, p);
  const phone = await ctx.newPage();
  await onboard(phone, p, 'phone', ['Movies', 'Anime', 'Coffee']);
  await phone.getByRole('button', { name: 'Swipe', exact: true }).click();
  await expect(phone.locator('article')).toHaveCount(1);
  await expect(phone.locator('article').first()).toContainText('phone_one');
  expect(await phone.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  await expect(phone.getByRole('button', { name: /Secret crush/ })).toBeVisible();
  await phone.getByRole('button', { name: /Not now/ }).click();
  await expect(phone.locator('article').first()).toContainText('phone_two');
  await ctx.close();
});
