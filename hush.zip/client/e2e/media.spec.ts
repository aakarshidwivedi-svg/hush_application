import AxeBuilder from '@axe-core/playwright';
import { expect, test, type Page } from '@playwright/test';
import { addPhoto, image, MIME, onboard, person, signedInContext } from './helpers';

test.describe.configure({ mode: 'serial' });

const erin = person('erin', 'Media College');
const frank = person('frank', 'Media College');
const gina = person('gina', 'Media College');
const hana = person('hana', 'Media College');

const photoList = (page: Page) => page.getByRole('list', { name: 'Your photos' }).getByRole('listitem');

test('photo manager: previews, validation errors, upload, main photo, reorder, delete', async ({ browser }) => {
  const ctx = await signedInContext(browser, erin);
  const page = await ctx.newPage();
  await onboard(page, erin);
  await page.goto('/settings');
  await expect(photoList(page)).toHaveCount(1);
  await expect(page.getByText('★ Main')).toHaveCount(1);

  // Unsupported type and too-small images are refused with clear messages and are never uploaded.
  const uploads: string[] = [];
  page.on('request', (r) => { if (r.method() === 'POST' && r.url().endsWith('/profiles/me/photos')) uploads.push(r.url()); });
  const input = page.locator('#photo-input');
  await input.setInputFiles({ name: 'notes.gif', mimeType: 'image/gif', buffer: Buffer.from('GIF89a') });
  await expect(page.getByRole('alert').filter({ hasText: 'Only JPEG, PNG and WebP' })).toBeVisible();
  await input.setInputFiles({ name: 'tiny.png', mimeType: 'image/png', buffer: await image('#000000', 120, 120) });
  await expect(page.getByRole('alert').filter({ hasText: 'at least 300×300' })).toBeVisible();
  expect(uploads).toEqual([]);
  const remove = page.getByRole('button', { name: 'Remove', exact: true });
  while ((await remove.count()) > 0) await remove.first().click();
  await expect(page.getByText('Preview — not saved yet')).toBeHidden();

  // Valid photos in all three formats: previewed first, saved only after "Upload".
  await input.setInputFiles([
    { name: 'a.jpg', mimeType: MIME.jpeg, buffer: await image('#E97DB8', 800, 1000, 'jpeg') },
    { name: 'b.webp', mimeType: MIME.webp, buffer: await image('#6D4FD6', 700, 700, 'webp') },
  ]);
  await expect(page.getByText('Preview — not saved yet')).toBeVisible();
  await expect(page.getByRole('img', { name: 'Preview of a.jpg' })).toBeVisible();
  await expect(photoList(page)).toHaveCount(1); // nothing saved yet
  await page.getByRole('button', { name: 'Upload 2 photos' }).click();
  await expect(photoList(page)).toHaveCount(3);
  await expect(page.getByText('3 of 6 photos')).toBeVisible();

  // Make photo 3 the main one: exactly one "Main" badge, and it moves.
  await page.getByRole('button', { name: 'Make photo 3 your main photo' }).click();
  await expect(page.getByRole('img', { name: 'Your photo 3 (main photo)' })).toBeVisible();
  await expect(page.getByText('★ Main')).toHaveCount(1);

  // Reorder: move the main photo to the front. It persists across a reload.
  await page.getByRole('button', { name: 'Move photo 3 earlier' }).click();
  await expect(page.getByRole('img', { name: 'Your photo 2 (main photo)' })).toBeVisible();
  await page.getByRole('button', { name: 'Move photo 2 earlier' }).click();
  await expect(page.getByRole('img', { name: 'Your photo 1 (main photo)' })).toBeVisible();
  await page.reload();
  await expect(page.getByRole('img', { name: 'Your photo 1 (main photo)' })).toBeVisible();

  // Delete the main photo: a confirmation first, then the next photo is promoted.
  await page.getByRole('button', { name: 'Delete photo 1' }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Delete' }).click();
  await expect(photoList(page)).toHaveCount(2);
  await expect(page.getByText('★ Main')).toHaveCount(1);

  // The six-photo limit disables adding more.
  for (const c of ['#111111', '#222222', '#333333', '#444444']) {
    if ((await photoList(page).count()) >= 6) break;
    await addPhoto(page, c);
  }
  await expect(photoList(page)).toHaveCount(6);
  await expect(page.getByRole('button', { name: '+ Add photos' })).toBeDisabled();
  await ctx.close();
});

test('settings: interests are validated (3–10), saved, and reloaded', async ({ browser }) => {
  const ctx = await signedInContext(browser, erin);
  const page = await ctx.newPage();
  await page.goto('/settings');
  await expect(page.getByRole('button', { name: 'Movies', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await page.getByRole('button', { name: 'Remove Movies' }).click();
  await page.getByRole('button', { name: 'Remove Anime' }).click();
  await page.getByRole('button', { name: 'Save interests' }).click();
  await expect(page.getByRole('alert').filter({ hasText: 'Pick between 3 and 10' })).toBeVisible();

  // Search, then add up to the maximum: the rest lock.
  await page.getByLabel('Search interests').fill('gam');
  await expect(page.getByRole('button', { name: 'Gaming', exact: true })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Coffee', exact: true })).toHaveCount(0);
  await page.getByRole('button', { name: 'Gaming', exact: true }).click();
  await page.getByLabel('Search interests').fill('');
  for (const n of ['Gym', 'Reading', 'Art', 'Dancing', 'Sports', 'Pop', 'Indie', 'Cooking']) await page.getByRole('button', { name: n, exact: true }).click();
  await expect(page.getByText('10 of 10 selected · that’s the max')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Coding', exact: true })).toHaveAttribute('aria-disabled', 'true');
  await page.getByRole('button', { name: 'Remove Dancing' }).click();
  await page.getByRole('button', { name: 'Remove Sports' }).click();
  await page.getByRole('button', { name: 'Save interests' }).click();
  await expect(page.getByText('Saved ✓').last()).toBeVisible();
  await page.reload();
  await expect(page.getByRole('button', { name: 'Gaming', exact: true })).toHaveAttribute('aria-pressed', 'true');
  await expect(page.getByRole('button', { name: 'Dancing', exact: true })).toHaveAttribute('aria-pressed', 'false');
  await ctx.close();
});

test('"Continue discovering" closes the match celebration and stays in Discover', async ({ browser }) => {
  const fCtx = await signedInContext(browser, frank);
  const gCtx = await signedInContext(browser, gina);
  const f = await fCtx.newPage();
  const g = await gCtx.newPage();
  await onboard(f, frank);
  await onboard(g, gina);
  await f.goto('/discover');
  await f.locator('article', { hasText: gina.nickname }).getByRole('button', { name: /Secret crush/ }).click();
  await g.goto('/discover');
  await g.locator('article', { hasText: frank.nickname }).getByRole('button', { name: /Secret crush/ }).click();
  const dialog = g.getByRole('dialog', { name: "It's a match!" });
  await expect(dialog).toBeVisible();
  await dialog.getByRole('button', { name: 'Continue discovering' }).click();
  await expect(dialog).toBeHidden();
  await expect(g).toHaveURL(/\/discover$/);
  // Matched people leave each other's Discover feed.
  await expect(g.locator('article', { hasText: frank.nickname })).toHaveCount(0);
  await fCtx.close();
  await gCtx.close();
});

test('onboarding and settings have no WCAG A/AA violations', async ({ browser }) => {
  const ctx = await signedInContext(browser, hana);
  const page = await ctx.newPage();
  const scan = async (label: string) => {
    const r = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
    expect(r.violations.map((v) => `${label} — ${v.id}: ${v.help}`)).toEqual([]);
  };
  await page.goto('/onboarding');
  await scan('step 1');
  await page.getByLabel('Your campus').selectOption({ label: 'Media College' });
  await page.getByLabel('I confirm that I am 18 or older.').check();
  await page.getByRole('button', { name: 'Continue' }).click();
  await scan('step 2');
  await page.getByLabel('Nickname').fill(hana.nickname);
  await page.getByRole('button', { name: 'Continue' }).click();
  await scan('step 3 (empty)');
  await addPhoto(page, '#C4B5FD');
  await scan('step 3 (with photo)');
  await page.getByRole('button', { name: 'Continue' }).click();
  await page.getByRole('button', { name: 'Coffee', exact: true }).click();
  await scan('step 4');
  await page.getByRole('button', { name: 'Gym', exact: true }).click();
  await page.getByRole('button', { name: 'Art', exact: true }).click();
  await page.getByRole('button', { name: 'Continue' }).click();
  await scan('step 5');
  await page.getByRole('button', { name: /Finish/ }).click();
  await page.waitForURL('**/discover');
  await page.goto('/settings');
  await expect(photoList(page)).toHaveCount(1);
  await scan('settings');
  await ctx.close();
});

test.describe('mobile @mobile', () => {
  test('onboarding steps fit the screen with no horizontal scroll', async ({ browser }) => {
    const p = person('mobi', 'Media College');
    const ctx = await signedInContext(browser, p);
    const page = await ctx.newPage();
    const fits = async () => expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
    await page.goto('/onboarding');
    await fits();
    await page.getByLabel('Your campus').selectOption({ label: 'Media College' });
    await page.getByLabel('I confirm that I am 18 or older.').check();
    await page.getByRole('button', { name: 'Continue' }).click();
    await page.getByLabel('Nickname').fill(p.nickname);
    await page.getByRole('button', { name: 'Continue' }).click();
    await addPhoto(page, '#F9A8D4');
    await fits();
    await page.getByRole('button', { name: 'Continue' }).click();
    for (const n of ['Coffee', 'Gym', 'Art']) await page.getByRole('button', { name: n, exact: true }).click();
    await fits();
    await page.getByRole('button', { name: 'Continue' }).click();
    await fits();
    await page.getByRole('button', { name: /Finish/ }).click();
    await page.waitForURL('**/discover');
    await fits();
    await ctx.close();
  });
});
