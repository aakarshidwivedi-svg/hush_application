import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import pg from 'pg';
import { E2E } from '../playwright.config';

/** Fresh database + real SQL migrations + one campus, before the servers start. */
export default async function globalSetup() {
  const admin = new pg.Client({ connectionString: E2E.adminUrl });
  await admin.connect().catch((e) => {
    throw new Error(`Cannot reach PostgreSQL at ${E2E.adminUrl}: ${e.message}. Set E2E_ADMIN_DATABASE_URL.`);
  });
  await admin.query(`DROP DATABASE IF EXISTS ${E2E.dbName} WITH (FORCE)`);
  await admin.query(`CREATE DATABASE ${E2E.dbName}`);
  await admin.end();

  const u = new URL(E2E.adminUrl);
  u.pathname = `/${E2E.dbName}`;
  execFileSync('npx', ['tsx', 'src/db/migrate-cli.ts'], {
    cwd: path.resolve(process.cwd(), '../server'),
    env: { ...process.env, DATABASE_URL: u.toString(), SUPABASE_URL: E2E.supabaseUrl, SUPABASE_JWT_SECRET: E2E.jwtSecret },
    stdio: 'inherit',
  });

  const db = new pg.Client({ connectionString: u.toString() });
  await db.connect();
  // Optionally exercise the API under the real least-privilege role (see server/docs/db-grants.sql).
  if (process.env.E2E_APP_DATABASE_URL) {
    await db.query(readFileSync(path.resolve(process.cwd(), '../server/docs/db-grants.sql'), 'utf8'));
  }
  // One campus per spec file (see `person()` in helpers.ts) so specs cannot see each other's people.
  for (const name of ['Hush University', 'Chat College', 'Media College', 'Moderation College', 'Discover College', 'Phone College', 'Invite College']) {
    await db.query(`INSERT INTO campuses (name, verification_config) VALUES ($1, $2)`, [name, JSON.stringify({ emailDomains: ['hush.edu'] })]);
  }
  await db.end();
}
