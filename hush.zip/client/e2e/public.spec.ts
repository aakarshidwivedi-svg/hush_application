import AxeBuilder from '@axe-core/playwright';
import { expect, test } from '@playwright/test';

test.describe('landing page', () => {
  test('explains the product and offers sign up / log in', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByRole('heading', { level: 1 })).toContainText('Someone might like you.');
    await expect(page.getByRole('heading', { name: 'How it works' })).toBeVisible();
    await expect(page.getByRole('heading', { name: /Privacy & safety/ })).toBeVisible();
    await expect(page.getByRole('link', { name: 'Create your profile' })).toHaveAttribute('href', '/signup');
    await expect(page.getByRole('link', { name: 'Log in' }).first()).toBeVisible();
    for (const name of ['Terms', 'Privacy Policy', 'Community Guidelines', 'Contact']) {
      await expect(page.getByRole('navigation', { name: 'Legal' }).getByRole('link', { name })).toBeVisible();
    }
  });

  test('footer links open the legal pages, including the honest privacy disclosure', async ({ page }) => {
    await page.goto('/');
    await page.getByRole('navigation', { name: 'Legal' }).getByRole('link', { name: 'Privacy Policy' }).click();
    await expect(page.getByRole('heading', { level: 1, name: 'Privacy Policy' })).toBeVisible();
    await expect(page.getByText('cannot promise absolute anonymity')).toBeVisible();
    await expect(page.getByText('90 days after they are resolved')).toBeVisible();
  });

  test('keyboard: the first Tab stop is a visible skip link that jumps to content', async ({ page }) => {
    await page.goto('/');
    await page.keyboard.press('Tab');
    const skip = page.getByRole('link', { name: 'Skip to content' });
    await expect(skip).toBeFocused();
    await expect(skip).toBeVisible();
    await page.keyboard.press('Enter');
    await expect(page.locator('#main')).toBeFocused();
  });

  test('private routes send signed-out visitors to login', async ({ page }) => {
    for (const path of ['/discover', '/matches', '/settings', '/matches/00000000-0000-4000-8000-000000000000']) {
      await page.goto(path);
      await expect(page).toHaveURL(/\/login$/);
    }
    await page.goto('/onboarding');
    await expect(page).toHaveURL(/\/login$/);
  });

  test('unknown pages show a friendly 404', async ({ page }) => {
    await page.goto('/no-such-page');
    await expect(page.getByRole('heading', { name: 'Page not found' })).toBeVisible();
  });
});

test.describe('forms', () => {
  test('login shows a generic error without revealing whether the email exists', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill('nobody@hush.edu');
    await page.getByLabel('Password').fill('wrong-password-123');
    await page.getByRole('button', { name: 'Log in' }).click();
    // No Supabase locally, so the request fails; the message must still be generic and announced.
    await expect(page.getByRole('alert')).toContainText(/Incorrect email or password|reach/i);
  });

  test('signup enforces a minimum password length', async ({ page }) => {
    await page.goto('/signup');
    await page.getByLabel('Email', { exact: true }).fill('a@hush.edu');
    await page.getByLabel('Password').fill('short');
    await page.getByRole('button', { name: 'Create account' }).click();
    await expect(page.getByRole('alert')).toContainText('at least 10 characters');
  });
});

test.describe('accessibility (axe)', () => {
  for (const path of ['/', '/login', '/signup', '/terms', '/privacy', '/guidelines', '/contact']) {
    test(`no WCAG A/AA violations on ${path}`, async ({ page }) => {
      await page.goto(path);
      await page.waitForLoadState('networkidle');
      const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa']).analyze();
      expect(results.violations.map((v) => `${v.id}: ${v.help} (${v.nodes.length})`)).toEqual([]);
    });
  }
});

test.describe('mobile @mobile', () => {
  test('landing has no horizontal scroll and the menu works', async ({ page }) => {
    await page.goto('/');
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBeLessThanOrEqual(0);

    const toggle = page.locator('button[aria-controls="mobile-nav"]');
    await expect(toggle).toHaveAccessibleName('Open menu');
    await expect(toggle).toBeVisible();
    await expect(page.getByRole('navigation', { name: 'Main' })).toBeHidden();
    await toggle.click();
    await expect(toggle).toHaveAttribute('aria-expanded', 'true');
    await expect(toggle).toHaveAccessibleName('Close menu');
    await page.getByRole('navigation', { name: 'Mobile' }).getByRole('link', { name: 'Sign up' }).click();
    await expect(page).toHaveURL(/\/signup$/);
    await expect(page.getByRole('navigation', { name: 'Mobile' })).toBeHidden(); // closes on navigation
  });

  for (const path of ['/login', '/signup', '/privacy']) {
    test(`no horizontal scroll on ${path}`, async ({ page }) => {
      await page.goto(path);
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      expect(overflow).toBeLessThanOrEqual(0);
    });
  }
});

test('respects reduced motion', async ({ browser }) => {
  const ctx = await browser.newContext({ reducedMotion: 'reduce' });
  const page = await ctx.newPage();
  await page.goto('/');
  const duration = await page.evaluate(() => {
    const el = document.querySelector('.animate-floaty');
    return el ? getComputedStyle(el).animationDuration : 'none';
  });
  expect(parseFloat(duration)).toBeLessThan(0.01);
  await ctx.close();
});
