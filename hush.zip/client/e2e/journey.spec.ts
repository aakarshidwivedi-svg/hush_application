import AxeBuilder from '@axe-core/playwright';
import { expect, test } from '@playwright/test';
import { addPhoto, onboard, person, signedInContext } from './helpers';

test.describe.configure({ mode: 'serial' });

const alice = person('alice');
const bob = person('bob');
const carol = person('carol');
let matchPath = '';

test('a personal (non-campus) account can join but stays out of Discover until the campus is verified', async ({ browser }) => {
  const outsider = person('mallory');
  const ctx = await signedInContext(browser, outsider, `${outsider.nickname}@gmail.com`);
  const page = await ctx.newPage();
  await onboard(page, outsider);
  await expect(page.getByText("we can't confirm your campus yet", { exact: false })).toBeVisible();
  await expect(page.getByRole('button', { name: /secret crush/i })).toHaveCount(0);
  await ctx.close();
});

test('onboarding validates every step and keeps what you typed when you go back', async ({ browser }) => {
  const p = person('dana');
  const ctx = await signedInContext(browser, p);
  const page = await ctx.newPage();
  await page.goto('/onboarding');
  await expect(page.getByText('Step 1 of 5')).toBeVisible();
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page.getByText('Choose your campus.')).toBeVisible();
  await page.getByLabel('Your campus').selectOption({ label: p.campus });
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page.getByText('Please confirm that you are 18 or older.')).toBeVisible();
  await page.getByLabel('I confirm that I am 18 or older.').check();
  await page.getByRole('button', { name: 'Continue' }).click();

  await page.getByLabel('Nickname').fill('ab');
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page.getByText(/3–24 characters/).first()).toBeVisible();
  await page.getByLabel('Nickname').fill(p.nickname);
  await page.getByLabel('Short bio').fill('typed before going back');
  await page.getByRole('button', { name: 'Back' }).click();
  await expect(page.getByLabel('Your campus')).toHaveValue(/.+/);
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page.getByLabel('Short bio')).toHaveValue('typed before going back');
  await page.getByRole('button', { name: 'Continue' }).click();

  // Photos: cannot continue without one.
  await expect(page.getByText('Step 3 of 5')).toBeVisible();
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page.getByRole('alert')).toContainText('Add at least one photo');
  await addPhoto(page, '#F9A8D4');
  await page.getByRole('button', { name: 'Continue' }).click();

  // Progress is saved: a reload resumes at the interests step instead of starting over.
  await expect(page.getByText('Step 4 of 5')).toBeVisible();
  await page.reload();
  await expect(page.getByText('Step 4 of 5')).toBeVisible();

  // Interests: at least 3.
  await page.getByRole('button', { name: 'Coffee', exact: true }).click();
  await page.getByRole('button', { name: 'Gym', exact: true }).click();
  await expect(page.getByText('2 of 10 selected · pick 1 more to continue')).toBeVisible();
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page.getByRole('alert')).toContainText('Pick at least 3 interests');
  await page.getByRole('button', { name: 'Art', exact: true }).click();
  await expect(page.getByText('3 of 10 selected')).toBeVisible();
  await page.getByRole('button', { name: 'Continue' }).click();
  await expect(page.getByRole('heading', { name: /Your profile, your rules/ })).toBeVisible();

  // Hide Dana from Discover so later tests still start with an empty campus, then finish.
  await page.getByRole('switch', { name: 'Show me in Discover' }).click();
  await page.getByRole('button', { name: /Finish/ }).click();
  await expect(page).toHaveURL(/\/discover$/);
  // Everything was saved as she went: a finished profile has nothing left to do on /onboarding.
  await page.goto('/onboarding');
  await expect(page).toHaveURL(/\/discover$/);
  await ctx.close();
});

test('three students onboard; an empty campus shows the empty state', async ({ browser }) => {
  const ctx = await signedInContext(browser, alice);
  const page = await ctx.newPage();
  await onboard(page, alice, 'alice loves astronomy');
  // Alice is the only person on campus so far.
  await expect(page.getByRole('heading', { name: "You've seen everyone for now" })).toBeVisible();
  await ctx.close();
  for (const p of [bob, carol]) {
    const c = await signedInContext(browser, p);
    const pg = await c.newPage();
    await onboard(pg, p, `${p.nickname} bio`);
    await c.close();
  }
});

test('discover shows only public fields; the crush button never reveals who likes whom', async ({ browser }) => {
  const ctx = await signedInContext(browser, bob);
  const page = await ctx.newPage();
  await page.goto('/discover');
  const card = page.locator('article', { hasText: alice.nickname });
  await expect(card).toBeVisible();
  await expect(card).toContainText('alice loves astronomy');
  await expect(card).toContainText('Movies');
  // The primary photo is shown, really loads, and exposes no storage path or account id.
  const img = card.getByRole('img', { name: `${alice.nickname}’s photo` });
  await expect(img).toBeVisible();
  await expect.poll(() => img.evaluate((el) => (el as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);
  const html = await page.content();
  expect(html).not.toMatch(/storage_path|profile_photos|auth_subject/);
  expect(html).not.toContain(alice.email);
  expect(html).not.toContain(alice.sub);
  await expect(page.locator('body')).not.toContainText(/likes you|crushing on you|admirer|popular/i);

  const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).analyze();
  expect(results.violations.map((v) => `${v.id}: ${v.help}`)).toEqual([]);
  await ctx.close();
});

test('report dialog traps focus, closes with Escape and restores focus', async ({ browser }) => {
  const ctx = await signedInContext(browser, bob);
  const page = await ctx.newPage();
  await page.goto('/discover');
  const card = page.locator('article', { hasText: carol.nickname });
  const trigger = card.getByRole('button', { name: 'Report' });
  await trigger.focus();
  await trigger.press('Enter');
  const dialog = page.getByRole('dialog');
  await expect(dialog).toBeVisible();
  await expect(dialog).toContainText(`Report ${carol.nickname}`);
  for (let i = 0; i < 8; i++) {
    await page.keyboard.press('Tab');
    expect(await page.evaluate(() => !!document.activeElement?.closest('[role="dialog"]'))).toBe(true);
  }
  await page.keyboard.press('Escape');
  await expect(dialog).toBeHidden();
  await expect(trigger).toBeFocused();
  await ctx.close();
});

test('"Not now" is a private note to yourself: the card stays hidden after a reload, and no crush is sent', async ({ browser }) => {
  const ctx = await signedInContext(browser, bob);
  const page = await ctx.newPage();
  const writes: string[] = [];
  page.on('request', (r) => { if (r.method() !== 'GET') writes.push(`${r.method()} ${new URL(r.url()).pathname}`); });
  await page.goto('/discover');
  const card = page.locator('article', { hasText: carol.nickname });
  await expect(card).toBeVisible();
  await card.getByRole('button', { name: `Skip ${carol.nickname}` }).click();
  await expect(page.locator('article', { hasText: carol.nickname })).toHaveCount(0);
  await expect.poll(() => writes.filter((w) => w.startsWith('POST /api/v1/profiles/discover/skips/')).length).toBe(1);
  expect(writes.filter((w) => w.includes('/crushes'))).toEqual([]); // skipping says nothing about interest
  await page.reload();
  await expect(page.locator('article', { hasText: alice.nickname })).toBeVisible();
  await expect(page.locator('article', { hasText: carol.nickname })).toHaveCount(0);
  // A brand-new browser session is also still skipped: it lives on the server, not in the tab.
  const fresh = await (await signedInContext(browser, bob)).newPage();
  await fresh.goto('/discover');
  await expect(fresh.locator('article', { hasText: alice.nickname })).toBeVisible();
  await expect(fresh.locator('article', { hasText: carol.nickname })).toHaveCount(0);
  await ctx.close();
});

test('secret crush → mutual crush → match celebration for both → private chat', async ({ browser }) => {
  const aCtx = await signedInContext(browser, alice);
  const bCtx = await signedInContext(browser, bob);
  const a = await aCtx.newPage();
  const b = await bCtx.newPage();

  // Alice crushes Bob. The UI says only that the crush is secret.
  await a.goto('/discover');
  const bobCard = a.locator('article', { hasText: bob.nickname });
  await bobCard.getByRole('button', { name: /Secret crush/ }).click();
  await expect(bobCard.getByRole('button', { name: /Crush sent/ })).toBeVisible();
  await expect(a.getByRole('dialog')).toBeHidden(); // no match yet — one-sided stays silent

  // Bob sees nothing different: Alice is just another card with a normal button.
  await b.goto('/discover');
  const aliceCard = b.locator('article', { hasText: alice.nickname });
  await expect(aliceCard.getByRole('button', { name: /Secret crush/ })).toBeVisible();
  await expect(b.getByRole('dialog')).toBeHidden();
  await b.goto('/matches');
  await expect(b.getByRole('heading', { name: 'No matches yet' })).toBeVisible();

  // Bob crushes Alice back → instant celebration for Bob.
  await b.goto('/discover');
  await b.locator('article', { hasText: alice.nickname }).getByRole('button', { name: /Secret crush/ }).click();
  const celebration = b.getByRole('dialog', { name: "It's a match!" });
  await expect(celebration).toBeVisible();
  await expect(celebration).toContainText(alice.nickname);
  await expect(celebration).toContainText("It's mutual!");
  // Both people's photos are shown and actually load.
  await expect(celebration.locator('img')).toHaveCount(2);
  await expect.poll(() => celebration.locator('img').evaluateAll((els) => els.every((e) => (e as HTMLImageElement).naturalWidth > 0))).toBe(true);

  // Alice learns on her next notification check.
  await a.reload();
  const aCelebration = a.getByRole('dialog', { name: "It's a match!" });
  await expect(aCelebration).toContainText(bob.nickname);

  await aCelebration.getByRole('button', { name: 'Start chatting' }).click();
  await celebration.getByRole('button', { name: 'Start chatting' }).click();
  await expect(a).toHaveURL(/\/matches\/[0-9a-f-]{36}$/);
  await expect(b).toHaveURL(/\/matches\/[0-9a-f-]{36}$/);
  matchPath = new URL(b.url()).pathname;

  // Chat both ways (Alice picks up Bob's message via polling).
  await expect(a.getByText('You matched!')).toBeVisible();
  await b.getByLabel('Message').fill('hey, it\'s bob 👋');
  await b.getByRole('button', { name: 'Send' }).click();
  await expect(b.getByRole('log')).toContainText("hey, it's bob 👋");
  await expect(a.getByRole('log')).toContainText("hey, it's bob 👋");
  await a.getByLabel('Message').fill('hi bob!');
  await a.getByLabel('Message').press('Enter');
  await expect(b.getByRole('log')).toContainText('hi bob!');
  await expect(a.getByRole('log').locator('time').first()).toBeVisible();

  // Matches page lists the match with a start-chatting button.
  await b.goto('/matches');
  const card = b.locator('article', { hasText: alice.nickname });
  await expect(card.getByRole('link', { name: 'Open chat' })).toBeVisible();
  await expect(card).toContainText('You: hi bob!'.replace('You: ', '')); // last message preview
  await aCtx.close();
  await bCtx.close();
});

test('only participants can open a conversation (guessed ids do not work)', async ({ browser }) => {
  const ctx = await signedInContext(browser, carol);
  const page = await ctx.newPage();
  await page.goto(matchPath);
  await expect(page.getByRole('heading', { name: 'This conversation has ended' })).toBeVisible();
  await expect(page.locator('body')).not.toContainText('hey, it\'s bob');
  await ctx.close();
});

test('blocking ends the chat for both people', async ({ browser }) => {
  const aCtx = await signedInContext(browser, alice);
  const bCtx = await signedInContext(browser, bob);
  const a = await aCtx.newPage();
  const b = await bCtx.newPage();
  await a.goto(matchPath);
  await b.goto(matchPath);
  await expect(b.getByLabel('Message')).toBeVisible();

  await a.getByRole('button', { name: 'Chat options' }).click();
  await expect(a.getByRole('button', { name: 'Chat options' })).toHaveAttribute('aria-expanded', 'true');
  await a.getByRole('menuitem', { name: 'block' }).click();
  await a.getByRole('dialog').getByRole('button', { name: 'Block' }).click();
  await expect(a).toHaveURL(/\/matches$/);
  await expect(a.getByRole('heading', { name: 'No matches yet' })).toBeVisible();

  // Bob's open chat notices on the next poll and cannot send any more.
  await expect(b.getByRole('heading', { name: 'This conversation has ended' })).toBeVisible({ timeout: 15_000 });

  // Neither person sees the other in Discover.
  await a.goto('/discover');
  await expect(a.locator('article', { hasText: bob.nickname })).toHaveCount(0);
  await b.goto('/discover');
  await expect(b.locator('article', { hasText: alice.nickname })).toHaveCount(0);

  // Alice can manage her block list in Settings.
  await a.goto('/settings');
  await expect(a.getByRole('region', { name: 'Blocked people' })).toContainText(bob.nickname);
  await a.getByRole('button', { name: 'Unblock' }).click();
  await expect(a.getByText(/You haven.t blocked anyone/)).toBeVisible();
  await aCtx.close();
  await bCtx.close();
});

test('settings: edit the profile, toggle discoverability', async ({ browser }) => {
  const ctx = await signedInContext(browser, carol);
  const page = await ctx.newPage();
  await page.goto('/settings');
  await page.getByLabel('Short bio').fill('updated bio from e2e');
  await page.getByRole('switch', { name: 'Show me in Discover' }).click();
  await page.getByRole('button', { name: 'Save changes' }).click();
  await expect(page.getByText('Saved ✓')).toBeVisible();
  await page.reload();
  await expect(page.getByLabel('Short bio')).toHaveValue('updated bio from e2e');
  await expect(page.getByRole('switch', { name: 'Show me in Discover' })).toHaveAttribute('aria-checked', 'false');

  // Carol is hidden from Discover now; a nickname clash is reported clearly.
  const b = await signedInContext(browser, bob);
  const bp = await b.newPage();
  await bp.goto('/discover');
  await expect(bp.locator('article', { hasText: carol.nickname })).toHaveCount(0);
  await page.getByLabel('Nickname').fill(alice.nickname);
  await page.getByRole('button', { name: 'Save changes' }).click();
  await expect(page.getByText('That nickname is already taken')).toBeVisible();
  await b.close();
  await ctx.close();
});

test('deleting an account requires typing DELETE and signs the person out', async ({ browser }) => {
  const ctx = await signedInContext(browser, carol);
  const page = await ctx.newPage();
  await page.goto('/settings');
  await page.getByRole('button', { name: 'Delete my account…' }).click();
  const dialog = page.getByRole('dialog', { name: 'Delete your account?' });
  const confirm = dialog.getByRole('button', { name: 'Delete forever' });
  await expect(confirm).toBeDisabled();
  await dialog.getByLabel('Confirmation').fill('delete');
  await expect(confirm).toBeDisabled();
  await dialog.getByLabel('Confirmation').fill('DELETE');
  await confirm.click();
  await expect(page).toHaveURL(/\/$/);
  await page.goto('/discover');
  await expect(page).toHaveURL(/\/login$/);
  await ctx.close();
});
