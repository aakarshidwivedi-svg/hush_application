import { randomUUID } from 'node:crypto';
import request from 'supertest';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { createUser, resetDb, seedCampus, setupApp, type TestUser } from './helpers.js';

const { pool, app } = setupApp();
afterAll(() => pool.end());

let campus: string;
let viewer: TestUser;

beforeEach(async () => {
  await resetDb(pool);
  campus = await seedCampus(pool, { name: 'Test University' });
  viewer = await createUser(pool, campus, { nickname: 'viewer_one' });
});

const discoverAs = (u: TestUser, qs = '') => request(app).get(`/api/v1/profiles/discover${qs}`).set(u.h);
const nicknames = (res: request.Response): string[] => res.body.data.map((c: { nickname: string }) => c.nickname).sort();

describe('GET /profiles/discover — access', () => {
  it('requires authentication', async () => {
    expect((await request(app).get('/api/v1/profiles/discover')).status).toBe(401);
  });

  it('requires completed onboarding', async () => {
    const { makeToken, bearer } = await import('./helpers.js');
    const token = await makeToken({ sub: randomUUID(), email: 'n@uni.edu' });
    const res = await request(app).get('/api/v1/profiles/discover').set(bearer(token));
    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('ONBOARDING_REQUIRED');
  });

  it.each([
    ['campus-unverified', { campusStatus: 'UNVERIFIED' as const }, ['campus_verification']],
    ['age-unverified', { ageStatus: 'UNVERIFIED' as const }, ['age_verification']],
  ])('refuses %s accounts', async (_name, over, missing) => {
    const u = await createUser(pool, campus, over);
    const res = await discoverAs(u);
    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('NOT_ELIGIBLE');
    expect(res.body.error.details.missing).toEqual(missing);
  });

  it('refuses suspended accounts', async () => {
    const u = await createUser(pool, campus, { status: 'SUSPENDED' });
    const res = await discoverAs(u);
    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('ACCOUNT_SUSPENDED');
  });

  it('requires verified age on campuses that demand it', async () => {
    const strict = await seedCampus(pool, { name: 'Strict U', requireVerifiedAge: true });
    const selfAttested = await createUser(pool, strict, { ageStatus: 'SELF_ATTESTED' });
    const verified = await createUser(pool, strict, { ageStatus: 'VERIFIED', nickname: 'verified_one' });
    expect((await discoverAs(selfAttested)).status).toBe(403);
    const res = await discoverAs(verified);
    expect(res.status).toBe(200);
    expect(res.body.data).toEqual([]); // the self-attested user is not shown to anyone
  });
});

describe('GET /profiles/discover — who is shown', () => {
  it('shows only eligible, active, discoverable users from the viewer’s own campus', async () => {
    const otherCampus = await seedCampus(pool, { name: 'Other U' });
    await createUser(pool, campus, { nickname: 'visible_a' });
    await createUser(pool, campus, { nickname: 'visible_b' });
    await createUser(pool, campus, { nickname: 'hidden_profile', discoverable: false });
    await createUser(pool, campus, { nickname: 'suspended_user', status: 'SUSPENDED' });
    await createUser(pool, campus, { nickname: 'deleted_user', status: 'DELETED' });
    await createUser(pool, campus, { nickname: 'unverified_campus', campusStatus: 'UNVERIFIED' });
    await createUser(pool, campus, { nickname: 'unverified_age', ageStatus: 'UNVERIFIED' });
    await createUser(pool, otherCampus, { nickname: 'other_campus' });

    const res = await discoverAs(viewer);
    expect(res.status).toBe(200);
    expect(nicknames(res)).toEqual(['visible_a', 'visible_b']); // never the viewer themself
  });

  it('hides users blocked in either direction, and existing matches', async () => {
    const iBlocked = await createUser(pool, campus, { nickname: 'i_blocked' });
    const blockedMe = await createUser(pool, campus, { nickname: 'blocked_me' });
    const matched = await createUser(pool, campus, { nickname: 'matched_user' });
    await createUser(pool, campus, { nickname: 'still_visible' });
    await pool.query('INSERT INTO blocks (blocker_id, blocked_id) VALUES ($1, $2), ($3, $1)', [viewer.id, iBlocked.id, blockedMe.id]);
    const [lo, hi] = [viewer.id, matched.id].sort();
    await pool.query('INSERT INTO matches (user_a, user_b) VALUES ($1, $2)', [lo, hi]);
    expect(nicknames(await discoverAs(viewer))).toEqual(['still_visible']);
  });

  it('returns an empty list (not an error) when nobody is available', async () => {
    const res = await discoverAs(viewer);
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ data: [], page: { nextCursor: null } });
  });
});

describe('GET /profiles/discover — privacy', () => {
  it('exposes only approved public fields', async () => {
    const other = await createUser(pool, campus, { nickname: 'public_one', bio: 'my bio', interestIds: ['art', 'pop', 'movies'] });
    const res = await discoverAs(viewer);
    expect(res.body.data).toHaveLength(1);
    expect(Object.keys(res.body.data[0]).sort()).toEqual(['bio', 'crushed', 'id', 'interests', 'nickname', 'photo', 'reason', 'sharedInterestIds']);
    expect(res.body.data[0]).toMatchObject({ id: other.id, nickname: 'public_one', bio: 'my bio', crushed: false, interests: [{ id: 'pop', name: 'Pop' }, { id: 'movies', name: 'Movies' }, { id: 'art', name: 'Art' }] });
    const raw = JSON.stringify(res.body);
    expect(raw).not.toContain(other.sub); // auth subject
    expect(raw).not.toContain('@uni.edu'); // email
    expect(raw).not.toMatch(/auth_?subject|campus_?status|age_?status|account_?status|student|email|count|popular|rank|likes/i);
  });

  it('is byte-for-byte identical whether or not other people have crushed on the viewer', async () => {
    const people = await Promise.all(['p1', 'p2', 'p3', 'p4'].map((n) => createUser(pool, campus, { nickname: `person_${n}` })));
    const before = await discoverAs(viewer);
    await pool.query(
      'INSERT INTO crushes (sender_id, receiver_id) VALUES ($1, $4), ($2, $4), ($3, $4)',
      [people[0]!.id, people[1]!.id, people[2]!.id, viewer.id],
    );
    const after = await discoverAs(viewer);
    expect(after.body).toEqual(before.body);
    expect(after.text).toBe(before.text);
  });

  it('reflects only the viewer’s own crushes, never the other side’s', async () => {
    const target = await createUser(pool, campus, { nickname: 'target_user' });
    await pool.query('INSERT INTO crushes (sender_id, receiver_id) VALUES ($1, $2)', [viewer.id, target.id]);
    // viewer sees their own crush state…
    expect((await discoverAs(viewer)).body.data.find((c: { id: string }) => c.id === target.id).crushed).toBe(true);
    // …but the target, who has no idea, sees nothing different about the viewer.
    const seenByTarget = (await discoverAs(target)).body.data.find((c: { id: string }) => c.id === viewer.id);
    expect(seenByTarget.crushed).toBe(false);
    expect(Object.keys(seenByTarget).sort()).toEqual(['bio', 'crushed', 'id', 'interests', 'nickname', 'photo', 'reason', 'sharedInterestIds']);
  });
});

describe('GET /profiles/discover — pagination', () => {
  it('pages through everyone exactly once with stable ordering', async () => {
    for (let i = 0; i < 7; i++) await createUser(pool, campus, { nickname: `person_${i}` });
    const seen: string[] = [];
    let cursor: string | null = null;
    let pages = 0;
    do {
      const res: request.Response = await discoverAs(viewer, `?limit=3${cursor ? `&cursor=${cursor}` : ''}`);
      expect(res.status).toBe(200);
      expect(res.body.data.length).toBeLessThanOrEqual(3);
      seen.push(...res.body.data.map((c: { id: string }) => c.id));
      cursor = res.body.page.nextCursor;
      pages++;
    } while (cursor);
    expect(pages).toBe(3);
    expect(seen).toHaveLength(7);
    expect(new Set(seen).size).toBe(7);

    const firstAgain = await discoverAs(viewer, '?limit=7');
    expect(firstAgain.body.data.map((c: { id: string }) => c.id)).toEqual(seen);
    expect(firstAgain.body.page.nextCursor).toBeNull();
  });

  it('rejects invalid limits and cursors', async () => {
    for (const qs of ['?limit=0', '?limit=51', '?limit=abc', '?cursor=nope', "?cursor=' OR 1=1 --"]) {
      expect((await discoverAs(viewer, qs)).status, qs).toBe(422);
    }
  });
});

describe('GET /profiles/discover — interest-based ranking', () => {
  // These tests bring their own viewer, so the shared one must not show up as a candidate.
  beforeEach(async () => { await pool.query('DELETE FROM users WHERE id = $1', [viewer.id]); });
  const ids = (res: request.Response): string[] => res.body.data.map((c: { id: string }) => c.id);

  it('ranks by shared interests and explains why, using only interests both people chose to show', async () => {
    const me = await createUser(pool, campus, { nickname: 'ranker', interestIds: ['movies', 'anime', 'coffee'] });
    const none = await createUser(pool, campus, { nickname: 'shares_none', interestIds: ['gym', 'art', 'pop'] });
    const one = await createUser(pool, campus, { nickname: 'shares_one', interestIds: ['movies', 'gym', 'art'] });
    const three = await createUser(pool, campus, { nickname: 'shares_three', interestIds: ['movies', 'anime', 'coffee'] });
    const two = await createUser(pool, campus, { nickname: 'shares_two', interestIds: ['anime', 'coffee', 'pop', 'gym'] });
    const res = await discoverAs(me);
    expect(ids(res)).toEqual([three.id, two.id, one.id, none.id]);
    const by = (u: TestUser) => res.body.data.find((c: { id: string }) => c.id === u.id);
    expect(by(three)).toMatchObject({ sharedInterestIds: ['movies', 'anime', 'coffee'], reason: 'You share interests in Movies, Anime and Coffee.' });
    expect(by(two)).toMatchObject({ sharedInterestIds: ['anime', 'coffee'], reason: 'You share interests in Anime and Coffee.' });
    expect(by(one)).toMatchObject({ sharedInterestIds: ['movies'], reason: 'You share an interest in Movies.' });
    expect(by(none)).toMatchObject({ sharedInterestIds: [], reason: null });
  });

  it('never explains with anything the candidate did not choose to show', async () => {
    const me = await createUser(pool, campus, { nickname: 'ranker2', interestIds: ['movies', 'anime', 'coffee'] });
    await createUser(pool, campus, { nickname: 'candidate_x', interestIds: ['movies', 'gym', 'art'] });
    const card = (await discoverAs(me)).body.data[0];
    const shown = new Set(card.interests.map((i: { id: string }) => i.id));
    for (const id of card.sharedInterestIds) expect(shown.has(id)).toBe(true);
    expect(card.reason).not.toMatch(/crush|like(s|d) you|interested in you/i);
  });

  it('keeps the order identical whether or not other people have crushed on the viewer', async () => {
    const me = await createUser(pool, campus, { nickname: 'ranker3', interestIds: ['movies', 'anime', 'coffee'] });
    const people = await Promise.all([
      createUser(pool, campus, { nickname: 'a_person', interestIds: ['movies', 'anime', 'coffee'] }),
      createUser(pool, campus, { nickname: 'b_person', interestIds: ['movies', 'gym', 'art'] }),
      createUser(pool, campus, { nickname: 'c_person', interestIds: ['gym', 'art', 'pop'] }),
    ]);
    const before = await discoverAs(me);
    await pool.query('INSERT INTO crushes (sender_id, receiver_id) VALUES ($1, $4), ($2, $4), ($3, $4)', [people[2]!.id, people[1]!.id, people[0]!.id, me.id]);
    const after = await discoverAs(me);
    expect(after.text).toBe(before.text);
  });

  it('puts people the viewer already sent a crush to after new faces, even if they are the best match', async () => {
    const me = await createUser(pool, campus, { nickname: 'ranker4', interestIds: ['movies', 'anime', 'coffee'] });
    const best = await createUser(pool, campus, { nickname: 'best_match', interestIds: ['movies', 'anime', 'coffee'] });
    const other = await createUser(pool, campus, { nickname: 'other_match', interestIds: ['gym', 'art', 'pop'] });
    await pool.query('INSERT INTO crushes (sender_id, receiver_id) VALUES ($1, $2)', [me.id, best.id]);
    expect(ids(await discoverAs(me))).toEqual([other.id, best.id]);
  });

  it('pages through the ranked list exactly once, in rank order', async () => {
    const me = await createUser(pool, campus, { nickname: 'ranker5', interestIds: ['movies', 'anime', 'coffee'] });
    const pool5 = [['movies', 'anime', 'coffee'], ['movies', 'anime', 'gym'], ['movies', 'gym', 'art'], ['gym', 'art', 'pop'], ['pop', 'art', 'dancing']];
    for (const [i, interestIds] of pool5.entries()) await createUser(pool, campus, { nickname: `ranked_${i}`, interestIds });
    const whole = ids(await discoverAs(me, '?limit=10'));
    const paged: string[] = [];
    let cursor: string | null = null;
    do {
      const res: request.Response = await discoverAs(me, `?limit=2${cursor ? `&cursor=${cursor}` : ''}`);
      paged.push(...ids(res));
      cursor = res.body.page.nextCursor;
    } while (cursor);
    expect(paged).toEqual(whole);
    expect(new Set(paged).size).toBe(5);
  });
});

describe('discovery skips ("Not now")', () => {
  const skip = (u: TestUser, target: string) => request(app).post(`/api/v1/profiles/discover/skips/${target}`).set(u.h);

  it('hides the skipped person from the skipper only, and persists across requests', async () => {
    const a = await createUser(pool, campus, { nickname: 'skip_target' });
    const b = await createUser(pool, campus, { nickname: 'stays_visible' });
    expect((await skip(viewer, a.id)).status).toBe(200);
    expect(nicknames(await discoverAs(viewer))).toEqual(['stays_visible']);
    expect(nicknames(await discoverAs(viewer))).toEqual(['stays_visible']); // still hidden next time
    expect(nicknames(await discoverAs(b))).toEqual(['skip_target', 'viewer_one']); // others see no change at all
    expect(nicknames(await discoverAs(a))).toEqual(['stays_visible', 'viewer_one']);
  });

  it('is idempotent and brought back by resetting', async () => {
    const a = await createUser(pool, campus, { nickname: 'skip_target' });
    await skip(viewer, a.id);
    expect((await skip(viewer, a.id)).status).toBe(200);
    expect((await discoverAs(viewer)).body.data).toHaveLength(0);
    expect((await request(app).delete('/api/v1/profiles/discover/skips').set(viewer.h)).status).toBe(200);
    expect(nicknames(await discoverAs(viewer))).toEqual(['skip_target']);
  });

  it('is not a crush and tells nobody anything', async () => {
    const a = await createUser(pool, campus, { nickname: 'skip_target' });
    await skip(viewer, a.id);
    expect((await pool.query('SELECT count(*)::int AS n FROM crushes')).rows[0].n).toBe(0);
    expect((await pool.query('SELECT count(*)::int AS n FROM notifications')).rows[0].n).toBe(0);
    expect((await pool.query('SELECT count(*)::int AS n FROM discovery_skips WHERE user_id = $1', [a.id])).rows[0].n).toBe(0);
  });

  it('answers the same for unknown ids, yourself and real people (no way to probe ids)', async () => {
    const a = await createUser(pool, campus, { nickname: 'skip_target' });
    const real = await skip(viewer, a.id);
    const unknown = await skip(viewer, randomUUID());
    const self = await skip(viewer, viewer.id);
    expect([real.status, unknown.status, self.status]).toEqual([200, 200, 200]);
    expect(unknown.body).toEqual(real.body);
    expect((await pool.query('SELECT count(*)::int AS n FROM discovery_skips')).rows[0].n).toBe(1);
  });

  it('validates the id and requires an eligible, signed-in caller', async () => {
    expect((await skip(viewer, 'not-a-uuid')).status).toBe(422);
    expect((await request(app).post(`/api/v1/profiles/discover/skips/${randomUUID()}`)).status).toBe(401);
    expect((await request(app).delete('/api/v1/profiles/discover/skips')).status).toBe(401);
    await pool.query("UPDATE users SET account_status = 'SUSPENDED' WHERE id = $1", [viewer.id]);
    expect((await skip(viewer, randomUUID())).status).toBe(403);
  });

  it('is removed with the account', async () => {
    const a = await createUser(pool, campus, { nickname: 'skip_target' });
    await skip(viewer, a.id);
    await pool.query('DELETE FROM users WHERE id = $1', [a.id]);
    expect((await pool.query('SELECT count(*)::int AS n FROM discovery_skips')).rows[0].n).toBe(0);
  });
});
