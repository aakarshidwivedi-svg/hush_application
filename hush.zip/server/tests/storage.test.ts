import { randomUUID } from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { loadConfig } from '../src/config/env.js';
import { LocalStorage, SupabaseStorage } from '../src/modules/photos/storage.js';
import { STORAGE_DIR } from './helpers.js';

const baseEnv = { DATABASE_URL: 'postgresql://x/y', SUPABASE_URL: 'https://proj.supabase.co', SUPABASE_JWT_SECRET: 'x'.repeat(20) };
const objectPath = () => `${randomUUID()}/${randomUUID()}.webp`;

describe('storage configuration', () => {
  it('uses Supabase Storage when a server key is configured, local disk otherwise (outside production)', () => {
    expect(loadConfig({ ...baseEnv, SUPABASE_SERVICE_ROLE_KEY: 'k'.repeat(30) }).storage.driver).toBe('supabase');
    expect(loadConfig({ ...baseEnv }).storage.driver).toBe('local');
  });

  it('refuses to start in production without a real storage setup', () => {
    expect(() => loadConfig({ ...baseEnv, NODE_ENV: 'production' })).toThrow(/Supabase Storage|SUPABASE_SERVICE_ROLE_KEY/);
    expect(() => loadConfig({ ...baseEnv, NODE_ENV: 'production', STORAGE_DRIVER: 'local' })).toThrow(/MEDIA_SIGNING_SECRET/);
    expect(loadConfig({ ...baseEnv, NODE_ENV: 'production', SUPABASE_SERVICE_ROLE_KEY: 'k'.repeat(30) }).storage.driver).toBe('supabase');
  });

  it('requires the key when the Supabase driver is chosen explicitly', () => {
    expect(() => loadConfig({ ...baseEnv, STORAGE_DRIVER: 'supabase' })).toThrow(/SUPABASE_SERVICE_ROLE_KEY/);
  });
});

describe('LocalStorage', () => {
  const cfg = loadConfig({ ...baseEnv, LOCAL_STORAGE_DIR: STORAGE_DIR, MEDIA_SIGNING_SECRET: 's'.repeat(24), PUBLIC_API_URL: 'http://api.test/api/v1' }).storage;

  it('refuses anything that is not a server-generated object path', async () => {
    const s = new LocalStorage(cfg);
    for (const bad of ['../x.webp', '/etc/passwd', 'a/b.webp', `${randomUUID()}/../../x.webp`, `${randomUUID()}/${randomUUID()}.png`]) {
      await expect(s.put(bad, Buffer.from('x'))).rejects.toThrow();
      expect(s.verify(bad, Math.floor(Date.now() / 1000) + 100, 'a'.repeat(64))).toBeNull();
    }
  });

  it('does not overwrite an existing object', async () => {
    const s = new LocalStorage(cfg);
    const p = objectPath();
    await s.put(p, Buffer.from('one'));
    await expect(s.put(p, Buffer.from('two'))).rejects.toThrow();
    await s.remove([p, p]); // removing twice is fine
  });
});

describe('SupabaseStorage request shapes (against a fake Storage API)', () => {
  interface Seen { method: string; url: string; headers: http.IncomingHttpHeaders; body: Buffer }
  let server: http.Server;
  let base: string;
  const seen: Seen[] = [];
  let respond: (req: Seen) => { status: number; json?: unknown } = () => ({ status: 200, json: {} });

  beforeAll(async () => {
    server = http.createServer((req, res) => {
      const chunks: Buffer[] = [];
      req.on('data', (c: Buffer) => chunks.push(c));
      req.on('end', () => {
        const rec = { method: req.method!, url: req.url!, headers: req.headers, body: Buffer.concat(chunks) };
        seen.push(rec);
        const r = respond(rec);
        res.writeHead(r.status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(r.json ?? {}));
      });
    });
    await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
    base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  });
  afterAll(() => new Promise<void>((r) => server.close(() => r())));

  const make = (key: string) => new SupabaseStorage(loadConfig({ ...baseEnv, SUPABASE_URL: base, SUPABASE_SERVICE_ROLE_KEY: key, PHOTO_BUCKET: 'profile-photos', PHOTO_URL_TTL_SECONDS: '900' }).storage);

  it('uploads to the private bucket with the server key, never overwriting', async () => {
    const p = objectPath();
    seen.length = 0;
    await make('sb_secret_' + 'k'.repeat(24)).put(p, Buffer.from('imgbytes'), 'image/webp');
    const r = seen[0]!;
    expect(r.method).toBe('POST');
    expect(r.url).toBe(`/storage/v1/object/profile-photos/${p}`);
    expect(r.headers.apikey).toBe('sb_secret_' + 'k'.repeat(24));
    expect(r.headers.authorization).toBeUndefined(); // new-style secret keys are not JWTs
    expect(r.headers['content-type']).toBe('image/webp');
    expect(r.headers['x-upsert']).toBe('false');
    expect(r.body.toString()).toBe('imgbytes');
  });

  it('sends legacy JWT service keys as a bearer token as well', async () => {
    seen.length = 0;
    await make('eyJhbGciOi.' + 'a'.repeat(30)).put(objectPath(), Buffer.from('x'), 'image/webp');
    expect(seen[0]!.headers.authorization).toBe('Bearer eyJhbGciOi.' + 'a'.repeat(30));
  });

  it('surfaces upload failures', async () => {
    respond = () => ({ status: 500 });
    await expect(make('k'.repeat(30)).put(objectPath(), Buffer.from('x'), 'image/webp')).rejects.toThrow(/upload failed/);
    respond = () => ({ status: 200, json: {} });
  });

  it('removes objects with one batched delete', async () => {
    const paths = [objectPath(), objectPath()];
    seen.length = 0;
    await make('k'.repeat(30)).remove(paths);
    expect(seen).toHaveLength(1);
    expect(seen[0]!.method).toBe('DELETE');
    expect(seen[0]!.url).toBe('/storage/v1/object/profile-photos');
    expect(JSON.parse(seen[0]!.body.toString())).toEqual({ prefixes: paths });
    await make('k'.repeat(30)).remove([]);
    expect(seen).toHaveLength(1); // nothing to do, no request
  });

  it('asks for expiring signed URLs in one request and maps them back by path', async () => {
    const [p1, p2, p3] = [objectPath(), objectPath(), objectPath()];
    respond = () => ({
      status: 200,
      json: [
        { path: p1, signedURL: `/object/sign/profile-photos/${p1}?token=t1`, error: null },
        { path: p2, signedURL: null, error: 'Object not found' },
        { path: p3, signedURL: `/object/sign/profile-photos/${p3}?token=t3`, error: null },
      ],
    });
    seen.length = 0;
    const urls = await make('k'.repeat(30)).signedUrls([p1, p2, p3]);
    expect(seen).toHaveLength(1);
    expect(seen[0]!.url).toBe('/storage/v1/object/sign/profile-photos');
    expect(JSON.parse(seen[0]!.body.toString())).toEqual({ expiresIn: 900, paths: [p1, p2, p3] });
    expect(urls.get(p1)).toBe(`${base}/storage/v1/object/sign/profile-photos/${p1}?token=t1`);
    expect(urls.has(p2)).toBe(false); // unsignable objects are simply absent
    expect(urls.get(p3)).toContain('token=t3');
    respond = () => ({ status: 200, json: {} });
  });

  it('never sends a path that is not server-generated', async () => {
    seen.length = 0;
    await expect(make('k'.repeat(30)).signedUrls(['../../other-bucket/secret.webp'])).rejects.toThrow();
    await expect(make('k'.repeat(30)).remove(['../x'])).rejects.toThrow();
    expect(seen).toHaveLength(0);
  });
});
