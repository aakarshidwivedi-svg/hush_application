import { describe, expect, it } from 'vitest';
import {
  CURSOR_RE,
  WEIGHTS,
  compareRank,
  decodeCursor,
  encodeCursor,
  explainShared,
  pageAfter,
  scoreCandidate,
  type RankKey,
} from '../src/modules/profiles/ranking.js';

const uuid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const key = (n: number, over: Partial<RankKey> = {}): RankKey => ({ crushed: false, score: 0, tie: String(n).padStart(32, '0'), id: uuid(n), ...over });

describe('scoreCandidate', () => {
  it('scores zero when nothing is shared', () => {
    expect(scoreCandidate({ viewerCount: 5, candidateCount: 5, sharedCount: 0, sharedCategories: 0 })).toBe(0);
  });

  it('rises with every shared interest', () => {
    const s = (shared: number) => scoreCandidate({ viewerCount: 6, candidateCount: 6, sharedCount: shared, sharedCategories: 1 });
    expect(s(1)).toBeLessThan(s(2));
    expect(s(2)).toBeLessThan(s(3));
  });

  it('prefers sharing across more categories when the shared count is equal', () => {
    const base = { viewerCount: 6, candidateCount: 6, sharedCount: 2 };
    expect(scoreCandidate({ ...base, sharedCategories: 2 })).toBeGreaterThan(scoreCandidate({ ...base, sharedCategories: 1 }));
  });

  it('prefers a close fit over a sprawling profile with the same shared count', () => {
    const close = scoreCandidate({ viewerCount: 4, candidateCount: 4, sharedCount: 3, sharedCategories: 2 });
    const sprawling = scoreCandidate({ viewerCount: 4, candidateCount: 10, sharedCount: 3, sharedCategories: 2 });
    expect(close).toBeGreaterThan(sprawling);
  });

  it('lets one extra shared interest outweigh any category or overlap bonus', () => {
    const lots = scoreCandidate({ viewerCount: 10, candidateCount: 10, sharedCount: 2, sharedCategories: 6 });
    const more = scoreCandidate({ viewerCount: 10, candidateCount: 10, sharedCount: 3, sharedCategories: 1 });
    expect(more).toBeGreaterThan(lots);
  });

  it('is an integer, deterministic and bounded', () => {
    const i = { viewerCount: 10, candidateCount: 10, sharedCount: 10, sharedCategories: 6 };
    const s = scoreCandidate(i);
    expect(Number.isInteger(s)).toBe(true);
    expect(scoreCandidate(i)).toBe(s);
    expect(s).toBeLessThanOrEqual(10 * WEIGHTS.sharedInterest + 6 * WEIGHTS.sharedCategory + WEIGHTS.overlap);
  });
});

describe('compareRank', () => {
  it('orders by score (high first), then the per-viewer tie key, then id', () => {
    const list = [key(3, { score: 100 }), key(1, { score: 300 }), key(2, { score: 100 }), key(4, { score: 300, tie: '0'.repeat(31) + '0' })];
    expect(list.sort(compareRank).map((k) => k.id)).toEqual([uuid(4), uuid(1), uuid(2), uuid(3)]);
  });

  it('puts people the viewer already crushed on after everyone new, whatever the score', () => {
    const list = [key(1, { score: 900, crushed: true }), key(2, { score: 0 })];
    expect(list.sort(compareRank).map((k) => k.id)).toEqual([uuid(2), uuid(1)]);
  });
});

describe('cursor and paging', () => {
  const sorted = Array.from({ length: 7 }, (_, i) => key(i + 1, { score: 700 - i * 100 })).sort(compareRank);

  it('round-trips and rejects anything that is not exactly the format', () => {
    const k = key(5, { score: 120, crushed: true });
    expect(decodeCursor(encodeCursor(k))).toEqual(k);
    for (const bad of ['', 'x', '1_1_zz_y', `2_1_${'a'.repeat(32)}_${uuid(1)}`, `0_1234567_${'a'.repeat(32)}_${uuid(1)}`, `0_1_${'a'.repeat(32)}_${uuid(1)}'; DROP TABLE users`]) {
      expect(CURSOR_RE.test(bad)).toBe(false);
      expect(decodeCursor(bad)).toBeNull();
    }
  });

  it('pages through every item exactly once', () => {
    const seen: string[] = [];
    let cursor: RankKey | null = null;
    for (let guard = 0; guard < 10; guard++) {
      const { items, next } = pageAfter(sorted, cursor, 3);
      seen.push(...items.map((i) => i.id));
      if (!next) break;
      cursor = decodeCursor(next);
    }
    expect(seen).toEqual(sorted.map((s) => s.id));
  });

  it('is unaffected by people disappearing between pages (keyset, not offset)', () => {
    const first = pageAfter(sorted, null, 3);
    const cursor = decodeCursor(first.next!);
    const without = sorted.filter((s) => s.id !== sorted[1]!.id); // someone on page one is blocked meanwhile
    expect(pageAfter(without, cursor, 3).items.map((i) => i.id)).toEqual(sorted.slice(3, 6).map((i) => i.id));
  });

  it('returns no cursor on the last page and an empty page past the end', () => {
    expect(pageAfter(sorted, null, 7).next).toBeNull();
    expect(pageAfter(sorted, decodeCursor(encodeCursor(sorted[6]!)), 3)).toEqual({ items: [], next: null });
  });
});

describe('explainShared', () => {
  it('names nothing when nothing is shared', () => {
    expect(explainShared([])).toBeNull();
  });
  it('reads naturally for one, two, three and many', () => {
    expect(explainShared(['Movies'])).toBe('You share an interest in Movies.');
    expect(explainShared(['Movies', 'Coffee'])).toBe('You share interests in Movies and Coffee.');
    expect(explainShared(['Movies', 'Anime', 'Coffee'])).toBe('You share interests in Movies, Anime and Coffee.');
    expect(explainShared(['A', 'B', 'C', 'D', 'E'])).toBe('You share interests in A, B, C and 2 more.');
  });
});
