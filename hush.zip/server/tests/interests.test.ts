import { randomUUID } from 'node:crypto';
import request from 'supertest';
import { afterAll, afterEach, beforeEach, describe, expect, it } from 'vitest';
import { bearer, createUser, makeToken, resetDb, seedCampus, setupApp, type TestUser } from './helpers.js';

const { pool, app } = setupApp();
afterAll(() => pool.end());

let campus: string;
let a: TestUser;

/** Tests below retire and add catalog entries; put the seeded catalog back so tests stay independent. */
afterEach(async () => {
  await pool.query('TRUNCATE user_interests');
  await pool.query(`DELETE FROM interests WHERE id = 'chess'`);
  await pool.query('UPDATE interests SET is_active = true');
});

beforeEach(async () => {
  await resetDb(pool);
  campus = await seedCampus(pool, { name: 'Test University' });
  a = await createUser(pool, campus, { nickname: 'alice_a', interestIds: [] });
});

const put = (u: { h: { Authorization: string } }, body: unknown) => request(app).put('/api/v1/profiles/me/interests').set(u.h).send(body as object);
const mine = async (u: TestUser) => (await pool.query('SELECT interest_id FROM user_interests WHERE user_id = $1 ORDER BY interest_id', [u.id])).rows.map((r) => r.interest_id as string);

describe('GET /interests', () => {
  it('requires authentication', async () => {
    expect((await request(app).get('/api/v1/interests')).status).toBe(401);
  });

  it('returns the catalog grouped in display order, with canonical ids', async () => {
    const res = await request(app).get('/api/v1/interests').set(a.h);
    expect(res.status).toBe(200);
    const cats = res.body.data as { category: string; interests: { id: string; name: string }[] }[];
    expect(cats.map((c) => c.category)).toEqual(['Music', 'Entertainment', 'Food', 'Lifestyle', 'Personality & social', 'Academic & creative']);
    expect(cats.map((c) => c.interests.length)).toEqual([6, 6, 6, 8, 8, 6]);
    expect(cats[0]!.interests[0]).toEqual({ id: 'pop', name: 'Pop' });
    const all = cats.flatMap((c) => c.interests);
    expect(new Set(all.map((i) => i.id)).size).toBe(40);
    expect(all.map((i) => i.name)).toEqual(expect.arrayContaining(['Bollywood', 'K-dramas', 'AI and technology', 'Trying new restaurants', 'Late-night talks']));
    expect(Object.keys(all[0]!).sort()).toEqual(['id', 'name']);
  });

  it('works for a brand-new account that has not finished onboarding', async () => {
    const token = await makeToken({ sub: randomUUID(), email: 'new@uni.edu' });
    expect((await request(app).get('/api/v1/interests').set(bearer(token))).status).toBe(200);
  });

  it('hides retired interests, so the catalog is easy to evolve', async () => {
    await pool.query(`UPDATE interests SET is_active = false WHERE id = 'memes'`);
    const all = (await request(app).get('/api/v1/interests').set(a.h)).body.data.flatMap((c: { interests: { id: string }[] }) => c.interests);
    expect(all.map((i: { id: string }) => i.id)).not.toContain('memes');
    await pool.query(`INSERT INTO interests (id, name, category, category_order, sort_order) VALUES ('chess', 'Chess', 'Lifestyle', 4, 90)`);
    const again = (await request(app).get('/api/v1/interests').set(a.h)).body.data.flatMap((c: { interests: { id: string }[] }) => c.interests);
    expect(again.map((i: { id: string }) => i.id)).toContain('chess');
  });
});

describe('PUT /profiles/me/interests', () => {
  it('saves 3–10 interests and returns the updated profile', async () => {
    const res = await put(a, { interestIds: ['coding', 'pop', 'coffee'] });
    expect(res.status).toBe(200);
    expect(res.body.data.interests).toEqual([
      { id: 'pop', name: 'Pop' },
      { id: 'coffee', name: 'Coffee' },
      { id: 'coding', name: 'Coding' },
    ]);
    expect(await mine(a)).toEqual(['coding', 'coffee', 'pop']);
    const ten = await put(a, { interestIds: ['pop', 'indie', 'bollywood', 'hip-hop', 'classical', 'live-concerts', 'movies', 'anime', 'k-dramas', 'web-series'] });
    expect(ten.status).toBe(200);
    expect(await mine(a)).toHaveLength(10);
  });

  it('replaces the previous selection and is idempotent', async () => {
    await put(a, { interestIds: ['pop', 'indie', 'movies'] });
    await put(a, { interestIds: ['coding', 'design', 'writing', 'pop'] });
    expect(await mine(a)).toEqual(['coding', 'design', 'pop', 'writing']);
    await put(a, { interestIds: ['coding', 'design', 'writing', 'pop'] });
    expect(await mine(a)).toEqual(['coding', 'design', 'pop', 'writing']);
  });

  it('is loaded back when the profile is fetched', async () => {
    await put(a, { interestIds: ['gym', 'reading', 'travelling'] });
    const me = (await request(app).get('/api/v1/profiles/me').set(a.h)).body.data;
    expect(me.interests.map((i: { id: string }) => i.id)).toEqual(['gym', 'reading', 'travelling']);
  });

  it.each([
    ['fewer than 3', { interestIds: ['pop', 'indie'] }],
    ['none', { interestIds: [] }],
    ['more than 10', { interestIds: ['pop', 'indie', 'bollywood', 'hip-hop', 'classical', 'live-concerts', 'movies', 'anime', 'k-dramas', 'web-series', 'gaming'] }],
    ['duplicates', { interestIds: ['pop', 'pop', 'indie'] }],
    ['an unknown id', { interestIds: ['pop', 'indie', 'not-a-real-interest'] }],
    ['malformed ids', { interestIds: ['pop', 'indie', 'DROP TABLE users;'] }],
    ['an uppercase id', { interestIds: ['pop', 'indie', 'Movies'] }],
    ['numbers instead of ids', { interestIds: [1, 2, 3] }],
    ['a non-array', { interestIds: 'pop' }],
    ['free-form names', { interestNames: ['Pop', 'Indie', 'Movies'] }],
    ['an extra field', { interestIds: ['pop', 'indie', 'movies'], userId: randomUUID() }],
    ['an empty body', {}],
  ])('rejects %s and leaves the saved selection untouched', async (_name, body) => {
    await put(a, { interestIds: ['gym', 'reading', 'travelling'] });
    const res = await put(a, body);
    expect(res.status).toBe(422);
    expect(await mine(a)).toEqual(['gym', 'reading', 'travelling']);
  });

  it('rejects a retired interest without applying a partial change', async () => {
    await put(a, { interestIds: ['gym', 'reading', 'travelling'] });
    await pool.query(`UPDATE interests SET is_active = false WHERE id = 'memes'`);
    const res = await put(a, { interestIds: ['pop', 'indie', 'memes'] });
    expect(res.status).toBe(422);
    expect(res.body.error.details[0]).toMatchObject({ path: 'interestIds' });
    expect(await mine(a)).toEqual(['gym', 'reading', 'travelling']);
  });

  it('changes only the caller’s own interests', async () => {
    const b = await createUser(pool, campus, { nickname: 'bob_b', interestIds: ['art', 'dancing', 'sports'] });
    await put(a, { interestIds: ['pop', 'indie', 'movies'] });
    expect(await mine(b)).toEqual(['art', 'dancing', 'sports']);
    // The body cannot redirect the change to someone else.
    expect((await put(a, { interestIds: ['pop', 'indie', 'movies'], userId: b.id })).status).toBe(422);
    expect(await mine(b)).toEqual(['art', 'dancing', 'sports']);
  });

  it('requires authentication, an onboarded account and an active account', async () => {
    expect((await request(app).put('/api/v1/profiles/me/interests').send({ interestIds: ['pop', 'indie', 'movies'] })).status).toBe(401);
    const fresh = await makeToken({ sub: randomUUID(), email: 'new@uni.edu' });
    expect((await put({ h: bearer(fresh) }, { interestIds: ['pop', 'indie', 'movies'] })).body.error.code).toBe('ONBOARDING_REQUIRED');
    const s = await createUser(pool, campus, { status: 'SUSPENDED' });
    expect((await put(s, { interestIds: ['pop', 'indie', 'movies'] })).status).toBe(403);
  });

  it('stays consistent when two edits race', async () => {
    const setA = ['pop', 'indie', 'movies'];
    const setB = ['coding', 'design', 'writing', 'gym'];
    await Promise.all([put(a, { interestIds: setA }), put(a, { interestIds: setB }), put(a, { interestIds: setA }), put(a, { interestIds: setB })]);
    const final = await mine(a);
    expect([[...setA].sort(), [...setB].sort()]).toContainEqual(final); // exactly one of the two sets, never a blend
  });
});

describe('database rules for user_interests', () => {
  it('refuses an 11th interest and a duplicate pair', async () => {
    const ids = ['pop', 'indie', 'bollywood', 'hip-hop', 'classical', 'live-concerts', 'movies', 'anime', 'k-dramas', 'web-series', 'gaming'];
    await expect(pool.query('INSERT INTO user_interests (user_id, interest_id) SELECT $1, unnest($2::text[])', [a.id, ids])).rejects.toMatchObject({ code: '23514' });
    expect(await mine(a)).toEqual([]);
    await pool.query(`INSERT INTO user_interests (user_id, interest_id) VALUES ($1, 'pop')`, [a.id]);
    await expect(pool.query(`INSERT INTO user_interests (user_id, interest_id) VALUES ($1, 'pop')`, [a.id])).rejects.toMatchObject({ code: '23505' });
  });

  it('refuses ids that are not in the catalog', async () => {
    await expect(pool.query(`INSERT INTO user_interests (user_id, interest_id) VALUES ($1, 'made-up')`, [a.id])).rejects.toMatchObject({ code: '23503' });
  });
});

describe('profile completeness gates discovery and crushes', () => {
  const discoverIds = async (u: TestUser) => (await request(app).get('/api/v1/profiles/discover').set(u.h)).body.data?.map((c: { id: string }) => c.id) as string[];

  it('reports what is missing on /profiles/me', async () => {
    const none = await createUser(pool, campus, { photos: 0, interestIds: [] });
    expect((await request(app).get('/api/v1/profiles/me').set(none.h)).body.data.profile).toEqual({ complete: false, missing: ['photos', 'interests'] });
    const noPhoto = await createUser(pool, campus, { photos: 0 });
    expect((await request(app).get('/api/v1/profiles/me').set(noPhoto.h)).body.data.profile).toEqual({ complete: false, missing: ['photos'] });
    const twoInterests = await createUser(pool, campus, { interestIds: ['pop', 'indie'] });
    expect((await request(app).get('/api/v1/profiles/me').set(twoInterests.h)).body.data.profile).toEqual({ complete: false, missing: ['interests'] });
    const full = await createUser(pool, campus);
    expect((await request(app).get('/api/v1/profiles/me').set(full.h)).body.data.profile).toEqual({ complete: true, missing: [] });
  });

  it('keeps incomplete profiles out of everyone’s Discover', async () => {
    const viewer = await createUser(pool, campus, { nickname: 'viewer_v' });
    const complete = await createUser(pool, campus, { nickname: 'complete_c' });
    const noPhoto = await createUser(pool, campus, { nickname: 'no_photo', photos: 0 });
    const fewInterests = await createUser(pool, campus, { nickname: 'few_interests', interestIds: ['pop', 'indie'] });
    const seen = await discoverIds(viewer);
    expect(seen).toContain(complete.id);
    expect(seen).not.toContain(noPhoto.id);
    expect(seen).not.toContain(fewInterests.id);
  });

  it('retired interests do not count towards the minimum', async () => {
    const viewer = await createUser(pool, campus, { nickname: 'viewer_v' });
    const u = await createUser(pool, campus, { nickname: 'edge_case', interestIds: ['memes', 'pop', 'indie'] });
    expect(await discoverIds(viewer)).toContain(u.id);
    await pool.query(`UPDATE interests SET is_active = false WHERE id = 'memes'`);
    expect(await discoverIds(viewer)).not.toContain(u.id);
  });

  it('stops an incomplete profile from browsing or sending crushes, and from being a crush target', async () => {
    const complete = await createUser(pool, campus, { nickname: 'complete_c' });
    const incomplete = await createUser(pool, campus, { nickname: 'incomplete_i', photos: 0 });
    const d = await request(app).get('/api/v1/profiles/discover').set(incomplete.h);
    expect(d.status).toBe(403);
    expect(d.body.error.code).toBe('PROFILE_INCOMPLETE');
    expect(d.body.error.details.missing).toEqual(['photos']);
    expect((await request(app).post(`/api/v1/crushes/${complete.id}`).set(incomplete.h)).body.error.code).toBe('PROFILE_INCOMPLETE');
    // Targeting an incomplete profile looks exactly like targeting someone who does not exist.
    const res = await request(app).post(`/api/v1/crushes/${incomplete.id}`).set(complete.h);
    expect(res.status).toBe(404);
    expect((await pool.query('SELECT 1 FROM crushes')).rowCount).toBe(0);
  });

  it('lets people finish their profile and appear immediately', async () => {
    const viewer = await createUser(pool, campus, { nickname: 'viewer_v' });
    const u = await createUser(pool, campus, { nickname: 'getting_there', interestIds: [], photos: 1 });
    expect(await discoverIds(viewer)).not.toContain(u.id);
    expect((await put(u, { interestIds: ['pop', 'indie', 'movies'] })).body.data.profile.complete).toBe(true);
    expect(await discoverIds(viewer)).toContain(u.id);
  });

  it('does not stop existing matches from chatting if a photo is later removed', async () => {
    const x = await createUser(pool, campus, { nickname: 'xavier_x' });
    const y = await createUser(pool, campus, { nickname: 'yara_y' });
    await request(app).post(`/api/v1/crushes/${y.id}`).set(x.h);
    await request(app).post(`/api/v1/crushes/${x.id}`).set(y.h);
    const matches = (await request(app).get('/api/v1/matches').set(x.h)).body.data;
    expect(matches).toHaveLength(1);
    await pool.query('DELETE FROM profile_photos WHERE user_id = $1', [x.id]);
    const after = await request(app).get('/api/v1/matches').set(y.h);
    expect(after.status).toBe(200);
    expect(after.body.data[0].partner.photo).toBeNull();
    const msg = await request(app).post(`/api/v1/matches/${matches[0].id}/messages`).set(y.h).send({ content: 'hi' });
    expect(msg.status).toBe(201);
  });
});
