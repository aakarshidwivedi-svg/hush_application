import { randomUUID } from 'node:crypto';
import request from 'supertest';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { INVITE_CODE_RE, newInviteCode, normaliseInviteCode } from '../src/modules/invites/service.js';
import { bearer, createUser, makeToken, resetDb, seedCampus, setupApp, type TestUser } from './helpers.js';

const { pool, app } = setupApp();
afterAll(() => pool.end());

let campus: string;
let inviter: TestUser;
beforeEach(async () => {
  await resetDb(pool);
  campus = await seedCampus(pool, { name: 'Test University', domains: ['uni.edu'] });
  inviter = await createUser(pool, campus, { nickname: 'inviter_one' });
});

const myInvite = (u: TestUser) => request(app).get('/api/v1/invites/me').set(u.h);
async function join(nickname: string, inviteCode?: unknown) {
  const sub = randomUUID();
  const token = await makeToken({ sub, email: `${nickname}@uni.edu` });
  const res = await request(app)
    .post('/api/v1/auth/complete-profile')
    .set(bearer(token))
    .send({ campusId: campus, nickname, bio: '', ageAttestation: true, ...(inviteCode === undefined ? {} : { inviteCode }) });
  return { sub, res };
}
const referrals = async () => (await pool.query('SELECT inviter_id, invitee_id FROM referrals')).rows;

describe('invite codes', () => {
  it('are random, unambiguous base32 and normalise copied text', () => {
    const codes = new Set(Array.from({ length: 200 }, newInviteCode));
    expect(codes.size).toBe(200);
    for (const c of codes) expect(c).toMatch(INVITE_CODE_RE);
    expect(normaliseInviteCode('  abcdefg234 ')).toBe('ABCDEFG234');
    for (const bad of ['', 'short', 'ABCDEFG2341', 'ABCDEFG23!', 'ABCDEFG231', 123, null, undefined, "A'; DROP TABLE users;--"]) {
      expect(normaliseInviteCode(bad)).toBeNull();
    }
  });
});

describe('GET /invites/me', () => {
  it('requires authentication', async () => {
    expect((await request(app).get('/api/v1/invites/me')).status).toBe(401);
  });

  it('gives each person one stable code of their own, with nothing else about anyone', async () => {
    const a = await myInvite(inviter);
    expect(a.status).toBe(200);
    expect(Object.keys(a.body.data).sort()).toEqual(['code', 'joined']);
    expect(a.body.data.code).toMatch(INVITE_CODE_RE);
    expect(a.body.data.joined).toBe(0);
    expect((await myInvite(inviter)).body.data.code).toBe(a.body.data.code); // stable
    const other = await createUser(pool, campus, { nickname: 'someone_else' });
    expect((await myInvite(other)).body.data.code).not.toBe(a.body.data.code);
  });

  it('refuses suspended accounts', async () => {
    await pool.query("UPDATE users SET account_status = 'SUSPENDED' WHERE id = $1", [inviter.id]);
    expect((await myInvite(inviter)).status).toBe(403);
  });

  it('survives many simultaneous first requests with exactly one code', async () => {
    const res = await Promise.all(Array.from({ length: 12 }, () => myInvite(inviter)));
    expect(res.every((r) => r.status === 200)).toBe(true);
    expect(new Set(res.map((r) => r.body.data.code)).size).toBe(1);
    expect((await pool.query('SELECT count(*)::int AS n FROM invite_codes')).rows[0].n).toBe(1);
  });
});

describe('joining with an invite code', () => {
  it('credits the inviter, who sees only a count', async () => {
    const { code } = (await myInvite(inviter)).body.data;
    const joined = await join('friend_one', code);
    expect(joined.res.status).toBe(201);
    expect(await referrals()).toHaveLength(1);
    expect((await join('friend_two', code.toLowerCase())).res.status).toBe(201); // pasted in lower case
    const mine = await myInvite(inviter);
    expect(mine.body.data.joined).toBe(2);
    expect(JSON.stringify(mine.body)).not.toMatch(/friend_|nickname|id"/);
  });

  it('never reveals the inviter to the person who joined, or anyone else', async () => {
    const { code } = (await myInvite(inviter)).body.data;
    const { res } = await join('friend_one', code);
    const raw = JSON.stringify(res.body);
    expect(raw).not.toContain(inviter.id);
    expect(raw).not.toContain('inviter_one');
    expect(raw).not.toContain(code);
    expect(raw).not.toMatch(/invite|referr/i);
  });

  it('is not an error to use an unknown, malformed or someone-else-suspended code (nothing to probe)', async () => {
    for (const code of ['AAAAAAAAAA', 'nonsense', '', "x'; DROP TABLE users;--", 12345 as unknown as string]) {
      const { res } = await join(`friend_${Math.random().toString(36).slice(2, 8)}`, code);
      expect(res.status, String(code)).toBe(201);
    }
    expect(await referrals()).toHaveLength(0);
    const { code } = (await myInvite(inviter)).body.data;
    await pool.query("UPDATE users SET account_status = 'SUSPENDED' WHERE id = $1", [inviter.id]);
    expect((await join('late_friend', code)).res.status).toBe(201);
    expect(await referrals()).toHaveLength(0);
  });

  it('cannot be used to invite yourself or credit one person twice', async () => {
    const { code } = (await myInvite(inviter)).body.data;
    const j = await join('friend_one', code);
    const again = await request(app).post('/api/v1/auth/complete-profile').set(bearer(await makeToken({ sub: j.sub, email: 'friend_one@uni.edu' }))).send({ campusId: campus, nickname: 'friend_one', ageAttestation: true, inviteCode: code });
    expect(again.status).toBe(409); // already onboarded
    expect(await referrals()).toHaveLength(1);
    await expect(pool.query('INSERT INTO referrals (invitee_id, inviter_id) VALUES ($1, $1)', [inviter.id])).rejects.toThrow(/referrals_not_self_chk/);
  });

  it('changes nothing about discovery or matching', async () => {
    const { code } = (await myInvite(inviter)).body.data;
    const friend = await join('friend_one', code);
    const token = await makeToken({ sub: friend.sub, email: 'friend_one@uni.edu' });
    expect((await pool.query('SELECT count(*)::int AS n FROM crushes')).rows[0].n).toBe(0);
    expect((await pool.query('SELECT count(*)::int AS n FROM matches')).rows[0].n).toBe(0);
    expect((await request(app).get('/api/v1/matches').set(bearer(token))).body.data).toEqual([]);
  });

  it('is erased with the account, on both sides', async () => {
    const { code } = (await myInvite(inviter)).body.data;
    const friend = await join('friend_one', code);
    const friendToken = await makeToken({ sub: friend.sub, email: 'friend_one@uni.edu' });
    // The invitee deleting their account removes the credit; the inviter's count drops.
    expect((await request(app).delete('/api/v1/account').set(bearer(friendToken)).send({ confirm: 'DELETE' })).status).toBeLessThan(300);
    expect((await myInvite(inviter)).body.data.joined).toBe(0);
    expect(await referrals()).toHaveLength(0);
    // The inviter deleting theirs removes the code.
    expect((await request(app).delete('/api/v1/account').set(inviter.h).send({ confirm: 'DELETE' })).status).toBeLessThan(300);
    expect((await pool.query('SELECT count(*)::int AS n FROM invite_codes')).rows[0].n).toBe(0);
  });
});
