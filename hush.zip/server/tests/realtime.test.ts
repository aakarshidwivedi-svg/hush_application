import { randomUUID } from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import request from 'supertest';
import { io as connectClient, type Socket } from 'socket.io-client';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { attachRealtime } from '../src/realtime/socket.js';
import { createUser, makeToken, resetDb, seedCampus, setupApp, type TestUser } from './helpers.js';

const { pool, app } = setupApp({ message: { windowMs: 60_000, max: 30 } });
let server: http.Server;
let url: string;
let ioServer: ReturnType<typeof attachRealtime>;
const open: Socket[] = [];

beforeAll(async () => {
  server = http.createServer(app);
  ioServer = attachRealtime(server, app);
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  url = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
afterAll(async () => {
  await new Promise<void>((r) => void ioServer.close(() => r()));
  await pool.end();
});
afterEach(() => {
  for (const s of open.splice(0)) s.close();
});

let campus: string;
let a: TestUser;
let b: TestUser;
let c: TestUser; // not in the conversation
let matchId: string;

beforeEach(async () => {
  await resetDb(pool);
  campus = await seedCampus(pool, { name: 'Test University' });
  a = await createUser(pool, campus, { nickname: 'alice_a' });
  b = await createUser(pool, campus, { nickname: 'bob_b' });
  c = await createUser(pool, campus, { nickname: 'carol_c' });
  matchId = await makeMatch(a, b);
});

async function makeMatch(x: TestUser, y: TestUser): Promise<string> {
  await request(app).post(`/api/v1/crushes/${y.id}`).set(x.h);
  await request(app).post(`/api/v1/crushes/${x.id}`).set(y.h);
  const { rows } = await pool.query<{ id: string }>(
    'SELECT id FROM matches WHERE user_a = LEAST($1::uuid, $2::uuid) AND user_b = GREATEST($1::uuid, $2::uuid)',
    [x.id, y.id],
  );
  return rows[0]!.id;
}

function connect(token: string): Promise<Socket> {
  const s = connectClient(url, { auth: { token }, transports: ['websocket'], reconnection: false, forceNew: true });
  open.push(s);
  return new Promise((resolve, reject) => {
    s.once('connect', () => resolve(s));
    s.once('connect_error', (e) => reject(e));
  });
}
const rejection = async (token: string | undefined): Promise<string> => {
  try {
    await connect(token as string);
  } catch (e) {
    return (e as { data?: { code?: string } }).data?.code ?? (e as Error).message;
  }
  throw new Error('connection was accepted');
};

const once = <T = unknown>(s: Socket, event: string, ms = 2000) =>
  new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`timed out waiting for "${event}"`)), ms);
    s.once(event, (p: T) => { clearTimeout(t); resolve(p); });
  });
/** Collects every payload for an event during `ms` (used to prove that something did NOT arrive). */
const collect = (s: Socket, event: string, ms = 400) =>
  new Promise<unknown[]>((resolve) => {
    const got: unknown[] = [];
    s.on(event, (p) => got.push(p));
    setTimeout(() => resolve(got), ms);
  });
const emit = <T = any>(s: Socket, event: string, payload: unknown) => s.timeout(3000).emitWithAck(event, payload) as Promise<T>;
const msg = (content = 'hi', extra: object = {}) => ({ matchId, content, clientId: randomUUID(), ...extra });
const count = async (sql: string, params: unknown[] = []) => (await pool.query(sql, params)).rows[0].n as number;

describe('connecting', () => {
  it('needs a valid access token', async () => {
    expect(await rejection(undefined)).toBe('UNAUTHENTICATED');
    expect(await rejection('')).toBe('UNAUTHENTICATED');
    expect(await rejection('not.a.jwt')).toBe('INVALID_TOKEN');
    expect(await rejection(await makeToken({ sub: a.sub, secret: 'another-secret-another-secret-123456' }))).toBe('INVALID_TOKEN');
    expect(await rejection(await makeToken({ sub: a.sub, exp: Math.floor(Date.now() / 1000) - 60 }))).toBe('INVALID_TOKEN');
    expect(await rejection(await makeToken({ sub: a.sub, aud: 'someone-else' }))).toBe('INVALID_TOKEN');
    expect(await rejection(await makeToken({ sub: a.sub, role: 'anon' }))).toBe('INVALID_TOKEN');
  });

  it('is refused for people who are not onboarded, suspended or not campus-verified', async () => {
    expect(await rejection(await makeToken({ sub: randomUUID(), email: 'new@uni.edu' }))).toBe('NOT_ELIGIBLE');
    const s = await createUser(pool, campus, { status: 'SUSPENDED' });
    expect(await rejection(s.token)).toBe('NOT_ELIGIBLE');
    const u = await createUser(pool, campus, { campusStatus: 'UNVERIFIED' });
    expect(await rejection(u.token)).toBe('NOT_ELIGIBLE');
    const d = await createUser(pool, campus, { status: 'DELETED' });
    expect(await rejection(d.token)).toBe('NOT_ELIGIBLE');
  });

  it('accepts an eligible member', async () => {
    const s = await connect(a.token);
    expect(s.connected).toBe(true);
  });

  it('drops the socket when its token expires', async () => {
    const short = await makeToken({ sub: a.sub, exp: Math.floor(Date.now() / 1000) + 2 });
    const s = await connect(short);
    const expired = once(s, 'auth:expired', 4000);
    const closed = once(s, 'disconnect', 4000);
    await expired;
    await closed;
    expect(s.connected).toBe(false);
  }, 10_000);

  it('offers no way to join arbitrary rooms', async () => {
    const sa = await connect(a.token);
    const sc = await connect(c.token);
    // Nothing a client can emit subscribes it to somebody else's events.
    for (const ev of ['join', 'subscribe', 'room:join', `match:${matchId}`, 'user:' + a.id]) sc.emit(ev, { matchId, room: `user:${a.id}` });
    const seen = collect(sc, 'message:new');
    await emit(sa, 'message:send', msg('private'));
    expect(await seen).toEqual([]);
  });
});

describe('message:send', () => {
  it('delivers in real time to the partner and syncs the sender’s other tabs', async () => {
    const sa = await connect(a.token);
    const sa2 = await connect(a.token);
    const sb = await connect(b.token);
    const toB = once<any>(sb, 'message:new');
    const toA2 = once<any>(sa2, 'message:new');
    const ack = await emit(sa, 'message:send', msg('hello bob'));
    expect(ack.ok).toBe(true);
    const gotB = await toB;
    const gotA2 = await toA2;
    expect(gotB.matchId).toBe(matchId);
    expect(gotB.message).toMatchObject({ content: 'hello bob', mine: false });
    expect(gotA2.message).toMatchObject({ content: 'hello bob', mine: true });
    expect(gotB.message.id).toBe(ack.message.id);
    // Only what the recipient may see: no sender ids, no other fields.
    expect(Object.keys(gotB.message).sort()).toEqual(['content', 'createdAt', 'id', 'mine']);
    expect(await count('SELECT count(*)::int AS n FROM messages')).toBe(1);
  });

  it('persists the message, so history is available over REST', async () => {
    const sa = await connect(a.token);
    await emit(sa, 'message:send', msg('stored'));
    const r = await request(app).get(`/api/v1/matches/${matchId}/messages`).set(b.h);
    expect(r.body.data.map((m: any) => [m.content, m.mine])).toEqual([['stored', false]]);
  });

  it('is idempotent: the same clientId creates one message and one delivery', async () => {
    const sa = await connect(a.token);
    const sb = await connect(b.token);
    const arrivals = collect(sb, 'message:new', 600);
    const payload = msg('only once');
    const first = await emit(sa, 'message:send', payload);
    const second = await emit(sa, 'message:send', payload);
    expect(second.ok).toBe(true);
    expect(second.message.id).toBe(first.message.id);
    expect(await arrivals).toHaveLength(1);
    expect(await count('SELECT count(*)::int AS n FROM messages')).toBe(1);
    expect(await count(`SELECT event_count AS n FROM notifications WHERE type = 'MESSAGE'`)).toBe(1);
  });

  it('is idempotent across transports (socket then REST retry)', async () => {
    const sa = await connect(a.token);
    const payload = msg('cross');
    const first = await emit(sa, 'message:send', payload);
    const retry = await request(app).post(`/api/v1/matches/${matchId}/messages`).set(a.h).send({ content: payload.content, clientId: payload.clientId });
    expect(retry.status).toBe(200);
    expect(retry.body.data.id).toBe(first.message.id);
    expect(await count('SELECT count(*)::int AS n FROM messages')).toBe(1);
  });

  it('also delivers messages sent over plain REST', async () => {
    const sb = await connect(b.token);
    const arrival = once<any>(sb, 'message:new');
    const r = await request(app).post(`/api/v1/matches/${matchId}/messages`).set(a.h).send({ content: 'via rest', clientId: randomUUID() });
    expect(r.status).toBe(201);
    expect((await arrival).message.content).toBe('via rest');
  });

  it('rejects malformed payloads without storing anything', async () => {
    const sa = await connect(a.token);
    const bad = [
      null,
      'hello',
      {},
      msg('x', { matchId: 'nope' }),
      msg('x', { clientId: 'nope' }),
      { matchId, content: 'no client id' },
      msg('   '),
      msg('y'.repeat(1001)),
      msg('x', { sender: b.id }),
      msg('x', { userId: b.id }),
    ];
    for (const p of bad) {
      const ack = await emit(sa, 'message:send', p);
      expect(ack.ok, JSON.stringify(p)?.slice(0, 60)).toBe(false);
    }
    expect(await count('SELECT count(*)::int AS n FROM messages')).toBe(0);
  });

  it('refuses people outside the conversation and tells the partner nothing', async () => {
    const sc = await connect(c.token);
    const sb = await connect(b.token);
    const arrivals = collect(sb, 'message:new');
    const ack = await emit(sc, 'message:send', msg('let me in'));
    expect(ack).toMatchObject({ ok: false, code: 'NOT_FOUND' });
    expect(await arrivals).toEqual([]);
    expect(await count('SELECT count(*)::int AS n FROM messages')).toBe(0);
    // A random match id looks exactly the same as someone else's.
    const unknown = await emit(sc, 'message:send', msg('x', { matchId: randomUUID() }));
    expect(unknown).toMatchObject({ ok: false, code: 'NOT_FOUND' });
  });

  it('never delivers to a connected outsider', async () => {
    const sa = await connect(a.token);
    const sc = await connect(c.token);
    const seen = collect(sc, 'message:new');
    const seenNotes = collect(sc, 'notifications:changed');
    await emit(sa, 'message:send', msg('secret'));
    expect(await seen).toEqual([]);
    expect(await seenNotes).toEqual([]);
  });

  it('rate-limits sockets', async () => {
    const sa = await connect(a.token);
    for (let i = 0; i < 30; i++) expect((await emit(sa, 'message:send', msg(`m${i}`))).ok).toBe(true);
    expect(await emit(sa, 'message:send', msg('too many'))).toMatchObject({ ok: false, code: 'RATE_LIMITED' });
  });
});

describe('every event is re-authorised', () => {
  it('stops delivery the moment a conversation is unmatched', async () => {
    const sa = await connect(a.token);
    const sb = await connect(b.token);
    const changed = once(sb, 'matches:changed');
    expect((await request(app).post(`/api/v1/matches/${matchId}/unmatch`).set(a.h)).status).toBe(200);
    await changed;
    expect(await emit(sa, 'message:send', msg('after unmatch'))).toMatchObject({ ok: false, code: 'NOT_FOUND' });
    expect(await emit(sb, 'message:send', msg('after unmatch'))).toMatchObject({ ok: false, code: 'NOT_FOUND' });
    expect(await count('SELECT count(*)::int AS n FROM messages')).toBe(0);
  });

  it('cannot be used to message someone who blocked you (or whom you blocked)', async () => {
    const sa = await connect(a.token);
    const sb = await connect(b.token);
    const changed = once(sa, 'matches:changed');
    expect((await request(app).post(`/api/v1/users/${a.id}/block`).set(b.h)).status).toBe(200);
    await changed;
    expect(await emit(sa, 'message:send', msg('hello?'))).toMatchObject({ ok: false, code: 'NOT_FOUND' });
    expect(await emit(sb, 'message:send', msg('hello?'))).toMatchObject({ ok: false, code: 'NOT_FOUND' });
    // The alternative REST endpoints agree.
    expect((await request(app).post(`/api/v1/matches/${matchId}/messages`).set(a.h).send({ content: 'x' })).status).toBe(404);
    expect((await request(app).get(`/api/v1/matches/${matchId}/messages`).set(a.h)).status).toBe(404);
    expect(await count('SELECT count(*)::int AS n FROM messages')).toBe(0);
  });

  it('a suspension disconnects the person and their matches stop working', async () => {
    const sa = await connect(a.token);
    const closed = once(sa, 'disconnect');
    const modToken = await makeToken({ sub: '00000000-0000-4000-8000-00000000aaaa' });
    const r = await request(app)
      .post(`/api/v1/moderation/users/${a.id}/suspend`)
      .set({ Authorization: `Bearer ${modToken}` })
      .send({ reason: 'test' });
    expect(r.status).toBe(200);
    await closed;
    expect(await rejection(a.token)).toBe('NOT_ELIGIBLE');
  });

  it('a status change in the database is enforced on the very next event, even on an open socket', async () => {
    const sa = await connect(a.token);
    await pool.query(`UPDATE users SET account_status = 'SUSPENDED' WHERE id = $1`, [a.id]);
    const closed = once(sa, 'disconnect');
    expect(await emit(sa, 'message:send', msg('still here?'))).toMatchObject({ ok: false, code: 'NOT_ELIGIBLE' });
    await closed;
    expect(await count('SELECT count(*)::int AS n FROM messages')).toBe(0);
  });

  it('an open socket cannot send to a partner who was suspended', async () => {
    const sa = await connect(a.token);
    await pool.query(`UPDATE users SET account_status = 'SUSPENDED' WHERE id = $1`, [b.id]);
    expect(await emit(sa, 'message:send', msg('to a suspended person'))).toMatchObject({ ok: false, code: 'NOT_FOUND' });
  });

  it('deleting an account disconnects it and notifies the partner', async () => {
    const sa = await connect(a.token);
    const sb = await connect(b.token);
    const closed = once(sa, 'disconnect');
    const changed = once(sb, 'matches:changed');
    const r = await request(app).delete('/api/v1/account').set(a.h).send({ confirm: 'DELETE' });
    expect(r.status).toBe(200);
    await closed;
    await changed;
    expect(await emit(sb, 'message:send', msg('anyone there?'))).toMatchObject({ ok: false, code: 'NOT_FOUND' });
  });
});

describe('typing indicator', () => {
  it('reaches only the partner', async () => {
    const sa = await connect(a.token);
    const sb = await connect(b.token);
    const sc = await connect(c.token);
    const toB = once<any>(sb, 'typing');
    const toC = collect(sc, 'typing');
    sa.emit('typing', { matchId, typing: true });
    expect(await toB).toEqual({ matchId, typing: true });
    expect(await toC).toEqual([]);
  });

  it('is ignored for conversations the sender is not in, and for junk payloads', async () => {
    const sb = await connect(b.token);
    const sc = await connect(c.token);
    const seen = collect(sb, 'typing');
    sc.emit('typing', { matchId, typing: true });
    sc.emit('typing', { matchId: 'x', typing: true });
    sc.emit('typing', 'junk');
    expect(await seen).toEqual([]);
  });

  it('shows typing again right after a stop (stopping re-arms the flood guard)', async () => {
    const sa = await connect(a.token);
    const sb = await connect(b.token);
    const seen = collect(sb, 'typing', 700);
    sa.emit('typing', { matchId, typing: true });
    sa.emit('typing', { matchId, typing: false });
    sa.emit('typing', { matchId, typing: true });
    expect((await seen).map((e: any) => e.typing)).toEqual([true, false, true]);
  });

  it('is rate-limited per socket', async () => {
    const sa = await connect(a.token);
    const sb = await connect(b.token);
    const seen = collect(sb, 'typing', 600);
    for (let i = 0; i < 20; i++) sa.emit('typing', { matchId, typing: true });
    expect((await seen).length).toBeLessThanOrEqual(2);
  });
});

describe('reconnection, ordering and unread counts', () => {
  it('a reconnecting client can fetch everything it missed, in order, without duplicates', async () => {
    const sb = await connect(b.token);
    await emit(sb, 'message:send', msg('before'));
    const first = await request(app).get(`/api/v1/matches/${matchId}/messages`).set(a.h);
    const cursor = first.body.data.at(-1).id;
    const sa = await connect(a.token);
    sa.close(); // a goes offline
    for (const t of ['one', 'two', 'three']) await request(app).post(`/api/v1/matches/${matchId}/messages`).set(b.h).send({ content: t, clientId: randomUUID() });
    const sa2 = await connect(a.token); // reconnects
    const missed = await request(app).get(`/api/v1/matches/${matchId}/messages?after=${cursor}`).set(a.h);
    expect(missed.body.data.map((m: any) => m.content)).toEqual(['one', 'two', 'three']);
    expect(sa2.connected).toBe(true);
  });

  it('keeps a consistent order under concurrent sends from both people', async () => {
    const sa = await connect(a.token);
    const sb = await connect(b.token);
    await Promise.all(
      Array.from({ length: 20 }, (_, i) => emit(i % 2 ? sa : sb, 'message:send', msg(`m${i}`))),
    );
    const all = await request(app).get(`/api/v1/matches/${matchId}/messages?limit=50`).set(a.h);
    const ids: string[] = all.body.data.map((m: any) => m.id);
    expect(ids).toHaveLength(20);
    expect(new Set(ids).size).toBe(20);
    // A client that had seen the first 6 pages forward from its cursor: every later message exactly once, in order.
    const seen: string[] = [];
    let after: string = ids[5]!;
    for (let i = 0; i < 10; i++) {
      const r = await request(app).get(`/api/v1/matches/${matchId}/messages?limit=4&after=${after}`).set(a.h);
      if (r.body.data.length === 0) break;
      seen.push(...r.body.data.map((m: any) => m.id));
      after = r.body.data.at(-1).id;
    }
    expect(seen).toEqual(ids.slice(6));
    const stamps = (await pool.query<{ created_at: Date }>('SELECT created_at FROM messages ORDER BY created_at, id')).rows.map((r) => r.created_at.getTime());
    expect([...stamps].sort((x, y) => x - y)).toEqual(stamps);
  });

  it('counts unread messages per conversation and clears them when the conversation is read', async () => {
    const sb = await connect(b.token);
    await emit(sb, 'message:send', msg('1'));
    await emit(sb, 'message:send', msg('2'));
    const unread = async () => (await request(app).get('/api/v1/matches').set(a.h)).body.data[0].unreadCount;
    expect(await unread()).toBe(2);
    // The sender's own view never counts their own messages.
    expect((await request(app).get('/api/v1/matches').set(b.h)).body.data[0].unreadCount).toBe(0);
    expect((await request(app).post(`/api/v1/matches/${matchId}/read`).set(a.h)).status).toBe(200);
    expect(await unread()).toBe(0);
    await emit(sb, 'message:send', msg('3'));
    expect(await unread()).toBe(1);
  });

  it('only participants can mark a conversation read', async () => {
    expect((await request(app).post(`/api/v1/matches/${matchId}/read`).set(c.h)).status).toBe(404);
  });
});

describe('secret crushes stay secret', () => {
  it('a one-sided crush produces no event of any kind for anyone', async () => {
    const sb = await connect(b.token);
    const sc = await connect(c.token);
    const seenB = [collect(sb, 'matches:changed'), collect(sb, 'notifications:changed'), collect(sb, 'message:new')];
    const seenC = [collect(sc, 'matches:changed'), collect(sc, 'notifications:changed')];
    const r = await request(app).post(`/api/v1/crushes/${c.id}`).set(b.h);
    expect(r.status).toBe(200);
    expect(r.body).toEqual({ data: { status: 'sent' } });
    for (const p of [...seenB, ...seenC]) expect(await p).toEqual([]);
    expect(await count('SELECT count(*)::int AS n FROM notifications WHERE user_id = $1', [c.id])).toBe(0);
  });

  it('a mutual match notifies exactly the two people, and the response stays generic', async () => {
    const sb = await connect(b.token);
    const sc = await connect(c.token);
    const sa = await connect(a.token);
    const seenA = collect(sa, 'matches:changed');
    const gotB = once(sb, 'matches:changed');
    const gotC = once(sc, 'matches:changed');
    await request(app).post(`/api/v1/crushes/${c.id}`).set(b.h);
    const r = await request(app).post(`/api/v1/crushes/${b.id}`).set(c.h);
    expect(r.body).toEqual({ data: { status: 'sent' } });
    await gotB;
    await gotC;
    expect(await seenA).toEqual([]);
  });
});
