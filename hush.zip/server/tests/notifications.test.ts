import { randomUUID } from 'node:crypto';
import request from 'supertest';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { createUser, resetDb, seedCampus, setupApp, type TestUser } from './helpers.js';

const { pool, app } = setupApp();
afterAll(() => pool.end());

let campus: string;
let a: TestUser;
let b: TestUser;
let c: TestUser;
let matchId: string;

const crush = (from: TestUser, to: string) => request(app).post(`/api/v1/crushes/${to}`).set(from.h);
async function makeMatch(x: TestUser, y: TestUser): Promise<string> {
  await crush(x, y.id);
  await crush(y, x.id);
  const { rows } = await pool.query<{ id: string }>(
    'SELECT id FROM matches WHERE user_a = LEAST($1::uuid, $2::uuid) AND user_b = GREATEST($1::uuid, $2::uuid)',
    [x.id, y.id],
  );
  return rows[0]!.id;
}
const send = (u: TestUser, content: string, clientId: string | undefined = randomUUID()) =>
  request(app).post(`/api/v1/matches/${matchId}/messages`).set(u.h).send({ content, ...(clientId ? { clientId } : {}) });
const inbox = (u: TestUser, q = '') => request(app).get(`/api/v1/notifications${q}`).set(u.h);
const rows = async (userId: string, type: string) =>
  (await pool.query('SELECT * FROM notifications WHERE user_id = $1 AND type = $2 ORDER BY created_at', [userId, type])).rows;

beforeEach(async () => {
  await resetDb(pool);
  campus = await seedCampus(pool, { name: 'Test University' });
  a = await createUser(pool, campus, { nickname: 'alice_a' });
  b = await createUser(pool, campus, { nickname: 'bob_b' });
  c = await createUser(pool, campus, { nickname: 'carol_c' });
  matchId = await makeMatch(a, b);
});

describe('GET /notifications', () => {
  it('requires authentication and eligibility', async () => {
    expect((await request(app).get('/api/v1/notifications')).status).toBe(401);
    const s = await createUser(pool, campus, { status: 'SUSPENDED' });
    expect((await inbox(s)).status).toBe(403);
  });

  it('lists the match notification with the unread count, and nothing about anyone else', async () => {
    const r = await inbox(a);
    expect(r.status).toBe(200);
    expect(r.body.page.total).toBe(1);
    expect(r.body.data).toEqual([
      { id: expect.any(String), type: 'MATCH', matchId, createdAt: expect.any(String), read: false, count: 1, partner: { nickname: 'bob_b' } },
    ]);
    expect((await inbox(c)).body).toMatchObject({ data: [], page: { total: 0 } });
  });

  it('can include read items; the default is unread only', async () => {
    await request(app).post('/api/v1/notifications/read').set(a.h).send({});
    expect((await inbox(a)).body.data).toEqual([]);
    const all = await inbox(a, '?filter=all');
    expect(all.body.data).toHaveLength(1);
    expect(all.body.data[0].read).toBe(true);
    expect(all.body.page.total).toBe(0);
  });

  it('rejects unknown filters and silly limits', async () => {
    expect((await inbox(a, '?filter=everything')).status).toBe(422);
    expect((await inbox(a, '?limit=0')).status).toBe(422);
    expect((await inbox(a, '?limit=999')).status).toBe(422);
  });
});

describe('match notifications', () => {
  it('exist exactly once per person, and the database refuses a duplicate', async () => {
    expect(await rows(a.id, 'MATCH')).toHaveLength(1);
    expect(await rows(b.id, 'MATCH')).toHaveLength(1);
    await expect(pool.query(`INSERT INTO notifications (user_id, type, match_id) VALUES ($1, 'MATCH', $2)`, [a.id, matchId])).rejects.toMatchObject({ code: '23505' });
  });

  it('stay exactly one each when both people like each other at the same moment (repeated)', async () => {
    for (let i = 0; i < 10; i++) {
      const x = await createUser(pool, campus);
      const y = await createUser(pool, campus);
      await Promise.all([crush(x, y.id), crush(y, x.id), crush(x, y.id), crush(y, x.id)]);
      expect(await rows(x.id, 'MATCH')).toHaveLength(1);
      expect(await rows(y.id, 'MATCH')).toHaveLength(1);
    }
  });

  it('are never created for a one-sided crush, and the crush leaves no trace in the inbox', async () => {
    const before = (await pool.query('SELECT count(*)::int AS n FROM notifications')).rows[0].n;
    const r = await crush(c, a.id); // c likes a; a has not reciprocated
    expect(r.body).toEqual({ data: { status: 'sent' } });
    expect((await pool.query('SELECT count(*)::int AS n FROM notifications')).rows[0].n).toBe(before);
    for (const u of [a, c]) {
      const text = JSON.stringify((await inbox(u, '?filter=all')).body);
      expect(text).not.toMatch(/crush|liked|likes|admir/i);
      expect(text).not.toContain(c.id);
    }
  });
});

describe('message notifications', () => {
  it('notify the recipient only, once per conversation until it is read', async () => {
    await send(a, 'one');
    await send(a, 'two');
    await send(a, 'three');
    const mine = await rows(a.id, 'MESSAGE');
    expect(mine).toHaveLength(0); // the sender is never notified of their own message
    const theirs = await rows(b.id, 'MESSAGE');
    expect(theirs).toHaveLength(1);
    expect(theirs[0].event_count).toBe(3);
    const r = await inbox(b);
    expect(r.body.page.total).toBe(2); // the match + the conversation's new messages
    expect(r.body.data.find((n: any) => n.type === 'MESSAGE')).toMatchObject({ count: 3, matchId, partner: { nickname: 'alice_a' } });
    // The content of the message is never put in the inbox.
    expect(JSON.stringify(r.body)).not.toMatch(/one|two|three/);
  });

  it('a retried send (same clientId) does not notify twice', async () => {
    const id = randomUUID();
    expect((await send(a, 'hello', id)).status).toBe(201);
    expect((await send(a, 'hello', id)).status).toBe(200);
    const n = await rows(b.id, 'MESSAGE');
    expect(n).toHaveLength(1);
    expect(n[0].event_count).toBe(1);
  });

  it('concurrent messages fold into one notification with the right count', async () => {
    await Promise.all(Array.from({ length: 10 }, (_, i) => send(a, `m${i}`)));
    const n = await rows(b.id, 'MESSAGE');
    expect(n).toHaveLength(1);
    expect(n[0].event_count).toBe(10);
  });

  it('are cleared by reading the conversation; the next message creates a fresh one', async () => {
    await send(a, 'first');
    expect((await request(app).post(`/api/v1/matches/${matchId}/read`).set(b.h)).status).toBe(200);
    expect((await inbox(b)).body.data.filter((n: any) => n.type === 'MESSAGE')).toEqual([]);
    await send(a, 'second');
    const n = await rows(b.id, 'MESSAGE');
    expect(n).toHaveLength(2);
    expect(n.map((x) => x.read_at !== null)).toEqual([true, false]);
    expect(n[1].event_count).toBe(1);
  });

  it('are atomic with the message: if the notification cannot be written, the message is not stored, and a retry works once', async () => {
    await pool.query(`ALTER TABLE notifications ADD CONSTRAINT force_fail CHECK (type <> 'MESSAGE') NOT VALID`);
    const clientId = randomUUID();
    try {
      const failed = await send(a, 'will fail', clientId);
      expect(failed.status).toBe(500);
      expect((await pool.query('SELECT count(*)::int AS n FROM messages')).rows[0].n).toBe(0);
    } finally {
      await pool.query('ALTER TABLE notifications DROP CONSTRAINT force_fail');
    }
    const retry = await send(a, 'will fail', clientId);
    expect(retry.status).toBe(201);
    expect((await pool.query('SELECT count(*)::int AS n FROM messages')).rows[0].n).toBe(1);
    expect(await rows(b.id, 'MESSAGE')).toHaveLength(1);
  });
});

describe('visibility follows the conversation', () => {
  beforeEach(async () => {
    await send(a, 'ping');
  });
  const visible = async (u: TestUser) => (await inbox(u)).body;

  it('hides notifications once the conversation is unmatched', async () => {
    expect((await visible(b)).page.total).toBe(2);
    await request(app).post(`/api/v1/matches/${matchId}/unmatch`).set(a.h);
    expect(await visible(b)).toMatchObject({ data: [], page: { total: 0 } });
    expect(await visible(a)).toMatchObject({ data: [], page: { total: 0 } });
  });

  it('hides them when either person blocks the other', async () => {
    await request(app).post(`/api/v1/users/${b.id}/block`).set(a.h);
    expect((await visible(a)).data).toEqual([]);
    expect((await visible(b)).data).toEqual([]);
  });

  it('hides them when the other person is suspended or deleted', async () => {
    await pool.query(`UPDATE users SET account_status = 'SUSPENDED' WHERE id = $1`, [a.id]);
    expect((await visible(b)).data).toEqual([]);
  });
});

describe('POST /notifications/read', () => {
  it('marks everything read by default and reports how many', async () => {
    await send(a, 'x');
    const r = await request(app).post('/api/v1/notifications/read').set(b.h).send({});
    expect(r.body.data).toEqual({ marked: 2 });
    expect((await inbox(b)).body.page.total).toBe(0);
    // Repeating is harmless.
    expect((await request(app).post('/api/v1/notifications/read').set(b.h).send({})).body.data).toEqual({ marked: 0 });
  });

  it('can be limited to one type, so seeing a match never clears unread messages', async () => {
    await send(a, 'x');
    const r = await request(app).post('/api/v1/notifications/read').set(b.h).send({ type: 'MATCH' });
    expect(r.body.data).toEqual({ marked: 1 });
    const left = (await inbox(b)).body.data;
    expect(left.map((n: any) => n.type)).toEqual(['MESSAGE']);
  });

  it('can be limited to ids, and ignores ids that belong to somebody else', async () => {
    const mineB = (await inbox(b)).body.data[0].id;
    const theirs = (await inbox(a)).body.data[0].id;
    const r = await request(app).post('/api/v1/notifications/read').set(b.h).send({ ids: [theirs, randomUUID()] });
    expect(r.body.data).toEqual({ marked: 0 });
    expect((await inbox(a)).body.page.total).toBe(1);
    expect((await request(app).post('/api/v1/notifications/read').set(b.h).send({ ids: [mineB] })).body.data).toEqual({ marked: 1 });
  });

  it('validates its body', async () => {
    for (const body of [{ ids: [] }, { ids: ['nope'] }, { type: 'CRUSH' }, { everyone: true }, { userId: a.id }]) {
      expect((await request(app).post('/api/v1/notifications/read').set(b.h).send(body)).status, JSON.stringify(body)).toBe(422);
    }
  });

  it('never touches other people’s notifications', async () => {
    await request(app).post('/api/v1/notifications/read').set(b.h).send({});
    expect((await inbox(a)).body.page.total).toBe(1);
  });
});

describe('POST /notifications/:id/read', () => {
  it('marks one of your own', async () => {
    const id = (await inbox(a)).body.data[0].id;
    expect((await request(app).post(`/api/v1/notifications/${id}/read`).set(a.h)).status).toBe(200);
    expect((await inbox(a)).body.page.total).toBe(0);
    expect((await request(app).post(`/api/v1/notifications/${id}/read`).set(a.h)).status).toBe(200); // idempotent
  });

  it('answers 404 for someone else’s id and for an unknown one, identically', async () => {
    const theirs = (await inbox(a)).body.data[0].id;
    const r1 = await request(app).post(`/api/v1/notifications/${theirs}/read`).set(c.h);
    const r2 = await request(app).post(`/api/v1/notifications/${randomUUID()}/read`).set(c.h);
    expect(r1.status).toBe(404);
    expect(r1.body).toEqual(r2.body);
    expect((await inbox(a)).body.page.total).toBe(1);
    expect((await request(app).post('/api/v1/notifications/not-a-uuid/read').set(a.h)).status).toBe(422);
  });
});
