import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import sharp from 'sharp';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import os from 'node:os';
import { createApp } from '../src/app.js';
import { createPhotoService } from '../src/modules/photos/service.js';
import { LocalStorage } from '../src/modules/photos/storage.js';
import {
  createUser, insertPhotoRow, makeImage, resetDb, seedCampus, setupApp, STORAGE_DIR, testConfig, type TestUser,
} from './helpers.js';

const { pool, app, config } = setupApp();
afterAll(() => pool.end());

let campus: string;
let a: TestUser;
let b: TestUser;

beforeEach(async () => {
  await resetDb(pool);
  fs.rmSync(STORAGE_DIR, { recursive: true, force: true });
  fs.mkdirSync(STORAGE_DIR, { recursive: true });
  campus = await seedCampus(pool, { name: 'Test University' });
  a = await createUser(pool, campus, { nickname: 'alice_a', photos: 0 });
  b = await createUser(pool, campus, { nickname: 'bob_b', photos: 0 });
});

const upload = (u: TestUser, body: Buffer, type = 'image/jpeg') =>
  request(app).post('/api/v1/profiles/me/photos').set(u.h).set('Content-Type', type).send(body);
const list = (u: TestUser) => request(app).get('/api/v1/profiles/me/photos').set(u.h);
const files = (): string[] => {
  const out: string[] = [];
  const walk = (d: string) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) (e.isDirectory() ? walk(path.join(d, e.name)) : out.push(path.join(d, e.name)));
  };
  walk(STORAGE_DIR);
  return out;
};
const rows = async (u: TestUser) =>
  (await pool.query('SELECT id, display_order, is_primary FROM profile_photos WHERE user_id = $1 ORDER BY display_order', [u.id])).rows as {
    id: string; display_order: number; is_primary: boolean;
  }[];
/** Fetch an image through its signed link, the way a browser would. */
const fetchSigned = (url: string) => request(app).get(url.replace('http://api.test', ''));

describe('POST /profiles/me/photos — accepted images', () => {
  it.each(['jpeg', 'png', 'webp'] as const)('accepts %s, stores re-encoded WebP at two sizes, and returns signed links only', async (format) => {
    const res = await upload(a, await makeImage({ format, width: 2400, height: 3000 }), `image/${format}`);
    expect(res.status).toBe(201);
    const p = res.body.data;
    expect(Object.keys(p).sort()).toEqual(['height', 'id', 'isPrimary', 'order', 'thumbUrl', 'url', 'width']);
    expect(p).toMatchObject({ isPrimary: true, order: 0 });
    expect(Math.max(p.width, p.height)).toBeLessThanOrEqual(1600);
    expect(p.width).toBeLessThanOrEqual(1280);
    // The response never exposes the storage path or any account data.
    const raw = JSON.stringify(res.body);
    expect(raw).not.toContain(a.id);
    expect(raw).not.toContain(a.sub);
    expect(raw).not.toMatch(/storage_?path|bucket/i);

    const [full, thumb] = await Promise.all([fetchSigned(p.url), fetchSigned(p.thumbUrl)]);
    expect(full.status).toBe(200);
    expect(full.headers['content-type']).toBe('image/webp');
    expect(full.headers['cross-origin-resource-policy']).toBe('cross-origin');
    expect((await sharp(full.body).metadata()).format).toBe('webp');
    const tm = await sharp(thumb.body).metadata();
    expect(tm.format).toBe('webp');
    expect(Math.max(tm.width!, tm.height!)).toBeLessThanOrEqual(600);
    expect(files()).toHaveLength(2);
  });

  it('strips EXIF metadata (including GPS/copyright) and applies the rotation', async () => {
    const tagged = await sharp({ create: { width: 800, height: 400, channels: 3, background: '#f9a8d4' } })
      .jpeg()
      .withExif({ IFD0: { Copyright: 'SECRET-LOCATION-DATA' } })
      .withMetadata({ orientation: 6 })
      .toBuffer();
    const res = await upload(a, tagged);
    expect(res.status).toBe(201);
    expect(res.body.data.width).toBe(400); // rotated: 800x400 landscape became 400x800 portrait
    expect(res.body.data.height).toBe(800);
    const stored = fs.readFileSync(files().find((f) => !f.includes('_thumb'))!);
    const meta = await sharp(stored).metadata();
    expect(meta.exif).toBeUndefined();
    expect(stored.toString('latin1')).not.toContain('SECRET-LOCATION-DATA');
  });

  it('makes the first photo primary and numbers the rest in upload order', async () => {
    for (let i = 0; i < 3; i++) expect((await upload(a, await makeImage({ seed: i }))).status).toBe(201);
    const r = await rows(a);
    expect(r.map((x) => [x.display_order, x.is_primary])).toEqual([[0, true], [1, false], [2, false]]);
  });
});

describe('POST /profiles/me/photos — rejected input', () => {
  it('requires authentication, a verified identity and an active account', async () => {
    expect((await request(app).post('/api/v1/profiles/me/photos').set('Content-Type', 'image/jpeg').send(await makeImage())).status).toBe(401);
    const s = await createUser(pool, campus, { status: 'SUSPENDED', photos: 0 });
    expect((await upload(s, await makeImage())).status).toBe(403);
    expect(files()).toHaveLength(0);
  });

  it.each([
    ['GIF', async () => makeImage({ format: 'gif' })],
    ['TIFF', async () => makeImage({ format: 'tiff' })],
    ['SVG with a script', async () => Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><script>alert(1)</script></svg>')],
    ['HTML', async () => Buffer.from('<html><script>alert(1)</script></html>'.padEnd(200, ' '))],
    ['plain text', async () => Buffer.from('definitely not an image '.repeat(20))],
    ['a truncated JPEG', async () => (await makeImage()).subarray(0, 300)],
    ['random bytes with a JPEG header', async () => Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(4000, 7)])],
  ])('rejects %s even when it claims to be image/jpeg', async (_name, make) => {
    const res = await upload(a, await make(), 'image/jpeg');
    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('INVALID_IMAGE');
    expect(files()).toHaveLength(0);
    expect(await rows(a)).toHaveLength(0);
  });

  it('rejects unsupported content types and empty bodies', async () => {
    for (const type of ['image/gif', 'image/svg+xml', 'application/json', 'text/plain', 'application/octet-stream']) {
      const res = await upload(a, await makeImage(), type);
      expect(res.status, type).toBe(415);
      expect(res.body.error.code).toBe('UNSUPPORTED_MEDIA_TYPE');
    }
    expect((await upload(a, Buffer.alloc(0))).status).toBe(415);
    expect(files()).toHaveLength(0);
  });

  it('enforces the upload size limit', async () => {
    const res = await upload(a, Buffer.alloc(6 * 1024 * 1024 + 1024, 1));
    expect(res.status).toBe(413);
    expect(res.body.error.code).toBe('PAYLOAD_TOO_LARGE');
    expect(files()).toHaveLength(0);
  });

  it('enforces minimum and maximum dimensions', async () => {
    const small = await upload(a, await makeImage({ width: 200, height: 900 }));
    expect(small.status).toBe(422);
    expect(small.body.error.message).toMatch(/at least 300/);
    const huge = await upload(a, await makeImage({ width: 12500, height: 400 }));
    expect(huge.status).toBe(422);
    const tiny = await upload(a, await makeImage({ width: 300, height: 300 }));
    expect(tiny.status).toBe(201); // exactly the minimum is fine
    expect(files()).toHaveLength(2);
  });

  it('allows at most 6 photos and leaves no stray files behind', async () => {
    for (let i = 0; i < 6; i++) expect((await upload(a, await makeImage({ seed: i }))).status).toBe(201);
    const seventh = await upload(a, await makeImage({ seed: 9 }));
    expect(seventh.status).toBe(409);
    expect(seventh.body.error.code).toBe('PHOTO_LIMIT');
    expect(await rows(a)).toHaveLength(6);
    expect(files()).toHaveLength(12);
  });

  it('cannot exceed 6 photos under concurrent uploads, and never leaks files', async () => {
    const imgs = await Promise.all(Array.from({ length: 10 }, (_, i) => makeImage({ seed: i })));
    const results = await Promise.all(imgs.map((img) => upload(a, img)));
    const created = results.filter((r) => r.status === 201).length;
    expect(created).toBe(6);
    expect(results.filter((r) => r.status === 409)).toHaveLength(4);
    const r = await rows(a);
    expect(r).toHaveLength(6);
    expect(r.map((x) => x.display_order)).toEqual([0, 1, 2, 3, 4, 5]);
    expect(r.filter((x) => x.is_primary)).toHaveLength(1);
    expect(files()).toHaveLength(12);
  });

  it('removes already-written files when storing the thumbnail fails', async () => {
    const real = new LocalStorage(config.storage);
    const flaky = Object.assign(Object.create(real) as LocalStorage, {
      put: async (p: string, d: Buffer, t: string) => {
        if (p.includes('_thumb')) throw new Error('disk full');
        return real.put(p, d, t);
      },
    });
    const flakyApp = createApp({ pool, config, storage: flaky });
    const res = await request(flakyApp).post('/api/v1/profiles/me/photos').set(a.h).set('Content-Type', 'image/jpeg').send(await makeImage());
    expect(res.status).toBe(500);
    expect(await rows(a)).toHaveLength(0);
    expect(files()).toHaveLength(0);
  });
});

describe('GET /profiles/me/photos', () => {
  it('returns only the caller’s photos, in order', async () => {
    await upload(a, await makeImage({ seed: 1 }));
    await upload(a, await makeImage({ seed: 2 }));
    await upload(b, await makeImage({ seed: 3 }));
    const ra = await list(a);
    expect(ra.body.data.map((p: { order: number }) => p.order)).toEqual([0, 1]);
    expect(ra.body.data).toHaveLength(2);
    expect((await list(b)).body.data).toHaveLength(1);
    expect((await request(app).get('/api/v1/profiles/me/photos')).status).toBe(401);
  });
});

describe('PATCH /profiles/me/photos/reorder', () => {
  let ids: string[];
  beforeEach(async () => {
    ids = [];
    for (let i = 0; i < 3; i++) ids.push((await upload(a, await makeImage({ seed: i }))).body.data.id);
  });
  const reorder = (u: TestUser, photoIds: unknown) => request(app).patch('/api/v1/profiles/me/photos/reorder').set(u.h).send({ photoIds });

  it('applies a new order, including swaps, atomically', async () => {
    const res = await reorder(a, [ids[2], ids[0], ids[1]]);
    expect(res.status).toBe(200);
    expect(res.body.data.map((p: { id: string }) => p.id)).toEqual([ids[2], ids[0], ids[1]]);
    expect((await rows(a)).map((r) => r.id)).toEqual([ids[2], ids[0], ids[1]]);
    expect((await reorder(a, [ids[1], ids[0], ids[2]])).status).toBe(200);
    expect((await rows(a)).map((r) => r.id)).toEqual([ids[1], ids[0], ids[2]]);
  });

  it('does not change which photo is primary', async () => {
    await reorder(a, [ids[2], ids[1], ids[0]]);
    expect((await rows(a)).find((r) => r.is_primary)!.id).toBe(ids[0]);
  });

  it.each([
    ['a missing photo', (i: string[]) => [i[0], i[1]]],
    ['a duplicate', (i: string[]) => [i[0], i[0], i[1]]],
    ['an unknown photo', (i: string[]) => [i[0], i[1], randomUUID()]],
    ['too many ids', (i: string[]) => [...i, randomUUID()]],
    ['an empty list', () => []],
    ['non-uuids', () => ['a', 'b', 'c']],
  ])('rejects %s without changing anything', async (_name, make) => {
    const res = await reorder(a, make(ids));
    expect(res.status).toBe(422);
    expect((await rows(a)).map((r) => r.id)).toEqual(ids);
  });

  it('cannot reorder or touch someone else’s photos', async () => {
    const theirs = (await upload(b, await makeImage({ seed: 5 }))).body.data.id;
    const res = await reorder(a, [ids[0], ids[1], theirs]);
    expect(res.status).toBe(422);
    expect((await rows(b)).map((r) => r.id)).toEqual([theirs]);
    expect((await reorder(b, ids)).status).toBe(422); // and B cannot reorder A's
    expect((await rows(a)).map((r) => r.id)).toEqual(ids);
  });

  it('ignores any client-supplied user id', async () => {
    const res = await request(app).patch('/api/v1/profiles/me/photos/reorder').set(a.h).send({ photoIds: ids, userId: b.id });
    expect(res.status).toBe(422);
  });
});

describe('PATCH /profiles/me/photos/:photoId/primary', () => {
  it('moves the primary flag and keeps exactly one primary', async () => {
    const ids: string[] = [];
    for (let i = 0; i < 3; i++) ids.push((await upload(a, await makeImage({ seed: i }))).body.data.id);
    const res = await request(app).patch(`/api/v1/profiles/me/photos/${ids[2]}/primary`).set(a.h);
    expect(res.status).toBe(200);
    expect(res.body.data.filter((p: { isPrimary: boolean }) => p.isPrimary).map((p: { id: string }) => p.id)).toEqual([ids[2]]);
    expect((await rows(a)).filter((r) => r.is_primary)).toHaveLength(1);
    // Idempotent.
    expect((await request(app).patch(`/api/v1/profiles/me/photos/${ids[2]}/primary`).set(a.h)).status).toBe(200);
  });

  it('cannot set someone else’s photo (or a made-up one) as primary', async () => {
    await upload(a, await makeImage());
    const theirs = (await upload(b, await makeImage({ seed: 3 }))).body.data.id;
    for (const id of [theirs, randomUUID()]) {
      expect((await request(app).patch(`/api/v1/profiles/me/photos/${id}/primary`).set(a.h)).status).toBe(404);
    }
    expect((await rows(b)).find((r) => r.id === theirs)!.is_primary).toBe(true);
    expect((await request(app).patch('/api/v1/profiles/me/photos/not-a-uuid/primary').set(a.h)).status).toBe(422);
    expect((await request(app).patch(`/api/v1/profiles/me/photos/${theirs}/primary`)).status).toBe(401);
  });

  it('survives concurrent primary changes with exactly one primary left', async () => {
    const ids: string[] = [];
    for (let i = 0; i < 4; i++) ids.push((await upload(a, await makeImage({ seed: i }))).body.data.id);
    await Promise.all(ids.map((id) => request(app).patch(`/api/v1/profiles/me/photos/${id}/primary`).set(a.h)));
    expect((await rows(a)).filter((r) => r.is_primary)).toHaveLength(1);
  });
});

describe('DELETE /profiles/me/photos/:photoId', () => {
  it('deletes the row and both files, promotes a new primary and keeps the order contiguous', async () => {
    const ids: string[] = [];
    for (let i = 0; i < 3; i++) ids.push((await upload(a, await makeImage({ seed: i }))).body.data.id);
    expect(files()).toHaveLength(6);
    const res = await request(app).delete(`/api/v1/profiles/me/photos/${ids[0]}`).set(a.h); // the primary
    expect(res.status).toBe(200);
    expect(res.body.data.map((p: { id: string }) => p.id)).toEqual([ids[1], ids[2]]);
    const r = await rows(a);
    expect(r.map((x) => [x.id, x.display_order, x.is_primary])).toEqual([[ids[1], 0, true], [ids[2], 1, false]]);
    expect(files()).toHaveLength(4);
    expect((await pool.query('SELECT 1 FROM storage_cleanup')).rowCount).toBe(0);
    // A slot is free again.
    expect((await upload(a, await makeImage({ seed: 8 }))).status).toBe(201);
    expect((await rows(a)).map((x) => x.display_order)).toEqual([0, 1, 2]);
  });

  it('can delete the only photo', async () => {
    const id = (await upload(a, await makeImage())).body.data.id;
    expect((await request(app).delete(`/api/v1/profiles/me/photos/${id}`).set(a.h)).body.data).toEqual([]);
    expect(files()).toHaveLength(0);
  });

  it('cannot delete someone else’s photo; their files stay', async () => {
    await upload(a, await makeImage());
    const theirs = (await upload(b, await makeImage({ seed: 4 }))).body.data;
    const res = await request(app).delete(`/api/v1/profiles/me/photos/${theirs.id}`).set(a.h);
    expect(res.status).toBe(404);
    expect((await rows(b))).toHaveLength(1);
    expect(files()).toHaveLength(4);
    expect((await fetchSigned(theirs.url)).status).toBe(200);
    expect((await request(app).delete(`/api/v1/profiles/me/photos/${theirs.id}`)).status).toBe(401);
    expect((await request(app).delete(`/api/v1/profiles/me/photos/${randomUUID()}`).set(a.h)).status).toBe(404);
  });

  it('queues files for retry when storage is unavailable, then cleans them up', async () => {
    const id = (await upload(a, await makeImage())).body.data.id;
    const real = new LocalStorage(config.storage);
    const down = Object.assign(Object.create(real) as LocalStorage, { remove: async () => { throw new Error('storage down'); } });
    const res = await request(createApp({ pool, config, storage: down })).delete(`/api/v1/profiles/me/photos/${id}`).set(a.h);
    expect(res.status).toBe(200); // the person's request still succeeds
    expect(await rows(a)).toHaveLength(0);
    expect((await pool.query('SELECT 1 FROM storage_cleanup')).rowCount).toBe(2);
    expect(files()).toHaveLength(2);
    expect(await createPhotoService(pool, real).flushCleanup()).toBe(2); // the retry job
    expect(files()).toHaveLength(0);
    expect((await pool.query('SELECT 1 FROM storage_cleanup')).rowCount).toBe(0);
  });
});

describe('account deletion', () => {
  it('removes photos, interests and files for the deleted account only', async () => {
    const c = await createUser(pool, campus, { photos: 0 });
    for (let i = 0; i < 2; i++) await upload(a, await makeImage({ seed: i }));
    await upload(c, await makeImage({ seed: 5 }));
    expect(files()).toHaveLength(6);
    const res = await request(app).delete('/api/v1/account').set(a.h).send({ confirm: 'DELETE' });
    expect(res.status).toBe(200);
    expect((await pool.query('SELECT 1 FROM profile_photos WHERE user_id = $1', [a.id])).rowCount).toBe(0);
    expect((await pool.query('SELECT 1 FROM user_interests WHERE user_id = $1', [a.id])).rowCount).toBe(0);
    expect(files()).toHaveLength(2);
    expect((await pool.query('SELECT 1 FROM profile_photos WHERE user_id = $1', [c.id])).rowCount).toBe(1);
    expect((await pool.query('SELECT 1 FROM storage_cleanup')).rowCount).toBe(0);
  });
});

describe('signed media links (local driver)', () => {
  it('serve images when the storage directory sits inside a dot-folder (the dev default is ./.storage)', async () => {
    const dotDir = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'hush-dot-')), '.storage');
    const dotApp = createApp({ pool, config: testConfig({}, dotDir) });
    const up = await request(dotApp).post('/api/v1/profiles/me/photos').set(a.h).set('Content-Type', 'image/png').send(await makeImage({ format: 'png' }));
    expect(up.status).toBe(201);
    for (const link of [up.body.data.url, up.body.data.thumbUrl] as string[]) {
      const media = await request(dotApp).get(link.replace('http://api.test', ''));
      expect(media.status, link).toBe(200);
      expect(media.headers['content-type']).toMatch(/image\/webp/);
      // The web app is on another origin, so the browser needs this to display the <img>.
      expect(media.headers['cross-origin-resource-policy']).toBe('cross-origin');
    }
    fs.rmSync(path.dirname(dotDir), { recursive: true, force: true });
  });


  it('serve only with a valid, unexpired signature for exactly that object', async () => {
    const p = (await upload(a, await makeImage())).body.data;
    const u = new URL(p.url);
    const base = u.pathname;
    const sig = u.searchParams.get('sig')!;
    const exp = u.searchParams.get('exp')!;
    expect((await request(app).get(`${base}?exp=${exp}&sig=${sig}`)).status).toBe(200);
    expect((await request(app).get(base)).status).toBe(404); // unsigned
    expect((await request(app).get(`${base}?exp=${exp}&sig=${'0'.repeat(64)}`)).status).toBe(404); // wrong signature
    expect((await request(app).get(`${base}?exp=${Number(exp) + 1000}&sig=${sig}`)).status).toBe(404); // extended expiry
    expect((await request(app).get(`${base}?exp=${Number(exp) - 99999}&sig=${sig}`)).status).toBe(404);
    const other = new URL((await upload(b, await makeImage({ seed: 3 }))).body.data.url);
    expect((await request(app).get(`${other.pathname}?exp=${exp}&sig=${sig}`)).status).toBe(404); // signature for a different object
    for (const evil of ['..%2F..%2Fetc%2Fpasswd', '%2e%2e/%2e%2e/etc/passwd', 'x.webp']) {
      expect((await request(app).get(`/api/v1/media/${evil}?exp=${exp}&sig=${sig}`)).status, evil).toBe(404);
    }
  });

  it('do not use up the API-wide rate limit (a page of cards loads many images)', async () => {
    const small = createApp({ pool, config: testConfig({ global: { windowMs: 60_000, max: 5 } }) });
    const p = (await upload(a, await makeImage())).body.data;
    const link = (p.thumbUrl as string).replace('http://api.test', '');
    for (let i = 0; i < 12; i++) expect((await request(small).get(link)).status, `image ${i}`).toBe(200);
    // ...while ordinary API calls from the same client are still limited by the small global budget.
    const codes: number[] = [];
    for (let i = 0; i < 8; i++) codes.push((await request(small).get('/api/v1/health')).status);
    expect(codes).toContain(429);
  });

  it('expire after the configured lifetime', async () => {
    const p = (await upload(a, await makeImage())).body.data;
    const exp = Number(new URL(p.url).searchParams.get('exp'));
    expect(exp - Math.floor(Date.now() / 1000)).toBeGreaterThan(config.storage.urlTtlSeconds - 30);
    expect(exp - Math.floor(Date.now() / 1000)).toBeLessThanOrEqual(config.storage.urlTtlSeconds);
  });

  it('are not minted for photos that are not visible to the viewer', async () => {
    // a is complete and discoverable; hidden/blocked/other-campus people never appear with photos.
    await upload(a, await makeImage());
    await upload(b, await makeImage({ seed: 3 }));
    const viewer = await createUser(pool, campus, { nickname: 'viewer_v' });
    const seen = async () => (await request(app).get('/api/v1/profiles/discover').set(viewer.h)).body.data as { id: string; photo: { url: string } | null }[];
    expect((await seen()).map((c) => c.id)).toContain(a.id);
    expect((await seen()).find((c) => c.id === a.id)!.photo?.url).toMatch(/\/media\//);

    await pool.query('UPDATE profiles SET discoverable = false WHERE user_id = $1', [a.id]);
    expect((await seen()).map((c) => c.id)).not.toContain(a.id);
    await pool.query('UPDATE profiles SET discoverable = true WHERE user_id = $1', [a.id]);
    await request(app).post(`/api/v1/users/${a.id}/block`).set(viewer.h);
    expect((await seen()).map((c) => c.id)).not.toContain(a.id);
    // Blocked in the other direction too.
    expect(JSON.stringify((await request(app).get('/api/v1/profiles/discover').set(a.h)).body)).not.toContain(viewer.id);

    const other = await seedCampus(pool, { name: 'Other U' });
    const stranger = await createUser(pool, other, { nickname: 'stranger_s' });
    expect(JSON.stringify((await request(app).get('/api/v1/profiles/discover').set(stranger.h)).body)).not.toContain(b.id);
  });
});

describe('database rules for profile_photos', () => {
  const insert = (u: TestUser, order: number, primary: boolean, extra: { storage?: string; thumb?: string } = {}) => {
    const id = randomUUID();
    return pool.query(
      `INSERT INTO profile_photos (id, user_id, storage_path, thumb_path, width, height, display_order, is_primary) VALUES ($1,$2,$3,$4,800,1000,$5,$6)`,
      [id, u.id, extra.storage ?? `${randomUUID()}/${id}.webp`, extra.thumb ?? `${randomUUID()}/${id}_thumb.webp`, order, primary],
    );
  };
  const code = async (p: Promise<unknown>) => ((await p.then(() => ({ code: 'ok' }), (e) => e)) as { code: string }).code;

  it('refuses a second primary photo', async () => {
    await insert(a, 0, true);
    expect(await code(insert(a, 1, true))).toBe('23505');
  });

  it('refuses slot 6+, duplicate slots, and bad paths', async () => {
    await insert(a, 0, true);
    expect(await code(insert(a, 6, false))).toBe('23514');
    expect(await code(insert(a, 0, false))).toBe('23505');
    expect(await code(insert(a, 1, false, { storage: '../../etc/passwd' }))).toBe('23514');
    expect(await code(insert(a, 1, false, { thumb: `${randomUUID()}/x.png` }))).toBe('23514');
  });

  it('refuses to commit a profile with photos but no primary', async () => {
    const c = await pool.connect();
    try {
      await c.query('BEGIN');
      const id = randomUUID();
      await c.query(
        `INSERT INTO profile_photos (id, user_id, storage_path, thumb_path, width, height, display_order, is_primary) VALUES ($1,$2,$3,$4,800,1000,0,false)`,
        [id, a.id, `${randomUUID()}/${id}.webp`, `${randomUUID()}/${id}_thumb.webp`],
      );
      await expect(c.query('COMMIT')).rejects.toMatchObject({ code: '23514' });
    } finally {
      await c.query('ROLLBACK').catch(() => undefined);
      c.release();
    }
  });

  it('cascades when the user row is removed', async () => {
    await insertPhotoRow(pool, b.id, 0);
    await pool.query('DELETE FROM users WHERE id = $1', [b.id]);
    expect((await pool.query('SELECT 1 FROM profile_photos WHERE user_id = $1', [b.id])).rowCount).toBe(0);
  });
});
