-- 0005: normalized interest catalog, profile photos, storage clean-up queue. Additive only.
--
-- * `interests` is the canonical catalog (stable text ids); `user_interests` links people to it.
--   Free-form `profiles.interests` is deprecated and no longer read or written (kept so earlier
--   migrations stay untouched).
-- * `profile_photos` stores metadata only. The image bytes live in private object storage.
-- * `storage_cleanup` is a queue of object paths whose rows were deleted; a worker removes the
--   files after commit (and retries on failure), so deleted photos never leave orphaned files.

-- ---------------------------------------------------------------------------------------------
-- Interest catalog
-- ---------------------------------------------------------------------------------------------
CREATE TABLE "interests" (
    "id" TEXT NOT NULL,
    "name" VARCHAR(40) NOT NULL,
    "category" VARCHAR(40) NOT NULL,
    "category_order" INTEGER NOT NULL DEFAULT 0,
    "sort_order" INTEGER NOT NULL DEFAULT 0,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    CONSTRAINT "interests_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "interests_id_format_chk" CHECK ("id" ~ '^[a-z0-9]+(-[a-z0-9]+)*$' AND char_length("id") <= 40)
);
CREATE UNIQUE INDEX "interests_name_lower_key" ON "interests" (lower("name"));
CREATE INDEX "interests_category_idx" ON "interests" ("category_order", "sort_order");

CREATE TABLE "user_interests" (
    "user_id" UUID NOT NULL,
    "interest_id" TEXT NOT NULL,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "user_interests_pkey" PRIMARY KEY ("user_id", "interest_id"),
    CONSTRAINT "user_interests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "user_interests_interest_id_fkey" FOREIGN KEY ("interest_id") REFERENCES "interests"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX "user_interests_interest_id_idx" ON "user_interests" ("interest_id");

-- At most 10 interests per person, enforced by the database. (The minimum of 3 applies to a
-- *complete* profile and is enforced by the API, because a person passes through 0..2 while
-- choosing.) Deferred so a replace-the-whole-set transaction is judged on its final state.
CREATE FUNCTION "user_interests_check_max"() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE n integer;
BEGIN
  SELECT count(*) INTO n FROM user_interests WHERE user_id = NEW.user_id;
  IF n > 10 THEN
    RAISE EXCEPTION 'a profile can have at most 10 interests (user %)', NEW.user_id
      USING ERRCODE = 'check_violation', CONSTRAINT = 'user_interests_max_10';
  END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER "user_interests_max_trg" AFTER INSERT ON "user_interests"
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION "user_interests_check_max"();

ALTER TABLE "interests" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "user_interests" ENABLE ROW LEVEL SECURITY;

INSERT INTO "interests" ("id", "name", "category", "category_order", "sort_order") VALUES
  ('pop', 'Pop', 'Music', 1, 10),
  ('indie', 'Indie', 'Music', 1, 20),
  ('bollywood', 'Bollywood', 'Music', 1, 30),
  ('hip-hop', 'Hip-hop', 'Music', 1, 40),
  ('classical', 'Classical', 'Music', 1, 50),
  ('live-concerts', 'Live concerts', 'Music', 1, 60),

  ('movies', 'Movies', 'Entertainment', 2, 10),
  ('anime', 'Anime', 'Entertainment', 2, 20),
  ('k-dramas', 'K-dramas', 'Entertainment', 2, 30),
  ('web-series', 'Web series', 'Entertainment', 2, 40),
  ('gaming', 'Gaming', 'Entertainment', 2, 50),
  ('memes', 'Memes', 'Entertainment', 2, 60),

  ('coffee', 'Coffee', 'Food', 3, 10),
  ('cafes', 'Cafes', 'Food', 3, 20),
  ('street-food', 'Street food', 'Food', 3, 30),
  ('desserts', 'Desserts', 'Food', 3, 40),
  ('cooking', 'Cooking', 'Food', 3, 50),
  ('new-restaurants', 'Trying new restaurants', 'Food', 3, 60),

  ('gym', 'Gym', 'Lifestyle', 4, 10),
  ('reading', 'Reading', 'Lifestyle', 4, 20),
  ('travelling', 'Travelling', 'Lifestyle', 4, 30),
  ('photography', 'Photography', 'Lifestyle', 4, 40),
  ('fashion', 'Fashion', 'Lifestyle', 4, 50),
  ('art', 'Art', 'Lifestyle', 4, 60),
  ('dancing', 'Dancing', 'Lifestyle', 4, 70),
  ('sports', 'Sports', 'Lifestyle', 4, 80),

  ('introvert', 'Introvert', 'Personality & social', 5, 10),
  ('extrovert', 'Extrovert', 'Personality & social', 5, 20),
  ('ambivert', 'Ambivert', 'Personality & social', 5, 30),
  ('deep-conversations', 'Deep conversations', 'Personality & social', 5, 40),
  ('spontaneous-plans', 'Spontaneous plans', 'Personality & social', 5, 50),
  ('quiet-dates', 'Quiet dates', 'Personality & social', 5, 60),
  ('late-night-talks', 'Late-night talks', 'Personality & social', 5, 70),
  ('study-dates', 'Study dates', 'Personality & social', 5, 80),

  ('coding', 'Coding', 'Academic & creative', 6, 10),
  ('startups', 'Startups', 'Academic & creative', 6, 20),
  ('design', 'Design', 'Academic & creative', 6, 30),
  ('ai-tech', 'AI and technology', 'Academic & creative', 6, 40),
  ('writing', 'Writing', 'Academic & creative', 6, 50),
  ('entrepreneurship', 'Entrepreneurship', 'Academic & creative', 6, 60);

-- ---------------------------------------------------------------------------------------------
-- Profile photos (metadata only)
-- ---------------------------------------------------------------------------------------------
CREATE TABLE "profile_photos" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "user_id" UUID NOT NULL,
    "storage_path" TEXT NOT NULL,
    "thumb_path" TEXT NOT NULL,
    "width" INTEGER NOT NULL,
    "height" INTEGER NOT NULL,
    "display_order" SMALLINT NOT NULL,
    "is_primary" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "profile_photos_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "profile_photos_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    -- Slots 0..5 plus UNIQUE(user_id, display_order) means a person can never hold more than 6 photos,
    -- even under concurrent uploads. Deferrable so a re-order can swap positions in one statement.
    CONSTRAINT "profile_photos_order_chk" CHECK ("display_order" BETWEEN 0 AND 5),
    CONSTRAINT "profile_photos_order_uniq" UNIQUE ("user_id", "display_order") DEFERRABLE INITIALLY IMMEDIATE,
    CONSTRAINT "profile_photos_size_chk" CHECK ("width" BETWEEN 1 AND 4096 AND "height" BETWEEN 1 AND 4096),
    -- Paths are server-generated `<user uuid>/<photo uuid>[_thumb].webp`; nothing else can be stored,
    -- which also rules out path traversal in any storage driver.
    CONSTRAINT "profile_photos_path_chk" CHECK (
      "storage_path" ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.webp$'
      AND "thumb_path" ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}_thumb\.webp$')
);
CREATE UNIQUE INDEX "profile_photos_storage_path_key" ON "profile_photos" ("storage_path");
CREATE UNIQUE INDEX "profile_photos_thumb_path_key" ON "profile_photos" ("thumb_path");
-- At most one primary photo per person.
CREATE UNIQUE INDEX "profile_photos_one_primary_idx" ON "profile_photos" ("user_id") WHERE "is_primary";

-- ...and exactly one whenever the person has any photos (checked at commit time).
CREATE FUNCTION "profile_photos_check_primary"() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE
  uid uuid := COALESCE(NEW.user_id, OLD.user_id);
  total integer;
  prim integer;
BEGIN
  SELECT count(*), count(*) FILTER (WHERE is_primary) INTO total, prim FROM profile_photos WHERE user_id = uid;
  IF total > 0 AND prim <> 1 THEN
    RAISE EXCEPTION 'user % must have exactly one primary photo (has %)', uid, prim
      USING ERRCODE = 'check_violation', CONSTRAINT = 'profile_photos_exactly_one_primary';
  END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER "profile_photos_primary_trg" AFTER INSERT OR UPDATE OR DELETE ON "profile_photos"
  DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION "profile_photos_check_primary"();

ALTER TABLE "profile_photos" ENABLE ROW LEVEL SECURITY;

-- ---------------------------------------------------------------------------------------------
-- Storage clean-up queue
-- ---------------------------------------------------------------------------------------------
CREATE TABLE "storage_cleanup" (
    "path" TEXT NOT NULL,
    "queued_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    CONSTRAINT "storage_cleanup_pkey" PRIMARY KEY ("path")
);
CREATE INDEX "storage_cleanup_queued_at_idx" ON "storage_cleanup" ("queued_at");
ALTER TABLE "storage_cleanup" ENABLE ROW LEVEL SECURITY;
