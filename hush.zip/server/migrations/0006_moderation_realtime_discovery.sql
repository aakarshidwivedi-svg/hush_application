-- 0006: moderation audit trail, idempotent + read-tracked messages, de-duplicated notifications,
-- server-side discovery history. Additive only; earlier migrations are never edited.

-- ---- Moderation audit log (append-only) --------------------------------------------------------
CREATE TABLE "moderation_actions" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "moderator_subject" TEXT NOT NULL,
    "action" TEXT NOT NULL,
    "target_user_id" UUID,
    "report_id" UUID,
    "detail" TEXT,
    "reason" VARCHAR(500) NOT NULL,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "moderation_actions_pkey" PRIMARY KEY ("id"),
    CONSTRAINT "moderation_actions_action_chk" CHECK ("action" IN
      ('REPORT_REVIEWING', 'REPORT_ACTIONED', 'REPORT_DISMISSED', 'SUSPEND', 'REINSTATE', 'VERIFY_AGE', 'VERIFY_CAMPUS')),
    CONSTRAINT "moderation_actions_reason_chk" CHECK (char_length(btrim("reason")) BETWEEN 1 AND 500),
    CONSTRAINT "moderation_actions_target_fkey" FOREIGN KEY ("target_user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "moderation_actions_report_fkey" FOREIGN KEY ("report_id") REFERENCES "reports"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE INDEX "moderation_actions_created_idx" ON "moderation_actions" ("created_at" DESC, "id" DESC);
CREATE INDEX "moderation_actions_target_idx" ON "moderation_actions" ("target_user_id", "created_at" DESC);
CREATE INDEX "moderation_actions_report_idx" ON "moderation_actions" ("report_id");
ALTER TABLE "moderation_actions" ENABLE ROW LEVEL SECURITY;

-- Rows can never be edited or removed. The only permitted change is the foreign-key SET NULL that the
-- retention purge triggers when it deletes an old tombstone/report (the audit row itself survives).
CREATE FUNCTION "moderation_actions_immutable"() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF TG_OP = 'UPDATE'
     AND NEW.id = OLD.id AND NEW.moderator_subject = OLD.moderator_subject AND NEW.action = OLD.action
     AND NEW.detail IS NOT DISTINCT FROM OLD.detail AND NEW.reason = OLD.reason AND NEW.created_at = OLD.created_at
     AND (NEW.target_user_id IS NOT DISTINCT FROM OLD.target_user_id OR NEW.target_user_id IS NULL)
     AND (NEW.report_id IS NOT DISTINCT FROM OLD.report_id OR NEW.report_id IS NULL) THEN
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'moderation_actions is append-only' USING ERRCODE = 'restrict_violation';
END $$;
CREATE TRIGGER "moderation_actions_no_change" BEFORE UPDATE OR DELETE ON "moderation_actions"
  FOR EACH ROW EXECUTE FUNCTION "moderation_actions_immutable"();

-- Moderator list filters (category + date range) use these.
CREATE INDEX "reports_reason_created_idx" ON "reports" ("reason", "created_at");

-- ---- Messages: idempotent sends and read tracking ----------------------------------------------
ALTER TABLE "messages" ADD COLUMN "client_id" UUID;
-- A retried send (same client-generated id) can never create a second message.
CREATE UNIQUE INDEX "messages_client_id_key" ON "messages" ("match_id", "sender_id", "client_id") WHERE "client_id" IS NOT NULL;

CREATE TABLE "message_reads" (
    "match_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "last_read_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "message_reads_pkey" PRIMARY KEY ("match_id", "user_id"),
    CONSTRAINT "message_reads_match_fkey" FOREIGN KEY ("match_id") REFERENCES "matches"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "message_reads_user_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
ALTER TABLE "message_reads" ENABLE ROW LEVEL SECURITY;

-- ---- Notifications: new message type, one row per event ---------------------------------------
ALTER TABLE "notifications" DROP CONSTRAINT "notifications_type_chk";
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_type_chk" CHECK ("type" IN ('MATCH', 'MESSAGE'));
-- Number of new messages folded into one unread MESSAGE notification.
ALTER TABLE "notifications" ADD COLUMN "event_count" INTEGER NOT NULL DEFAULT 1;
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_count_chk" CHECK ("event_count" >= 1);
-- A match is announced to each person at most once (retries cannot duplicate it).
CREATE UNIQUE INDEX "notifications_match_once_key" ON "notifications" ("user_id", "match_id") WHERE "type" = 'MATCH';
-- At most one *unread* message notification per conversation; further messages bump its count.
CREATE UNIQUE INDEX "notifications_message_unread_key" ON "notifications" ("user_id", "match_id") WHERE "type" = 'MESSAGE' AND "read_at" IS NULL;
CREATE INDEX "notifications_user_created_idx" ON "notifications" ("user_id", "created_at" DESC);

-- ---- Discovery history: people the viewer chose to skip ---------------------------------------
CREATE TABLE "discovery_skips" (
    "user_id" UUID NOT NULL,
    "target_id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "discovery_skips_pkey" PRIMARY KEY ("user_id", "target_id"),
    CONSTRAINT "discovery_skips_user_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "discovery_skips_target_fkey" FOREIGN KEY ("target_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "discovery_skips_self_chk" CHECK ("user_id" <> "target_id")
);
ALTER TABLE "discovery_skips" ENABLE ROW LEVEL SECURITY;
