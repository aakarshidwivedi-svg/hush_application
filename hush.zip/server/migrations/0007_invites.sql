-- 0007: consent-based invites. Each person can share one personal link; nothing is imported from contacts.
-- Privacy: the inviter only ever sees how many people joined through their link, never who. The invitee never
-- sees who invited them, and invites have no effect on discovery, ranking or matching.

CREATE TABLE "invite_codes" (
    "user_id" UUID NOT NULL,
    "code" TEXT NOT NULL,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "invite_codes_pkey" PRIMARY KEY ("user_id"),
    CONSTRAINT "invite_codes_user_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "invite_codes_format_chk" CHECK ("code" ~ '^[A-Z2-7]{10}$')
);
CREATE UNIQUE INDEX "invite_codes_code_key" ON "invite_codes" ("code");
ALTER TABLE "invite_codes" ENABLE ROW LEVEL SECURITY;

CREATE TABLE "referrals" (
    "invitee_id" UUID NOT NULL,
    "inviter_id" UUID NOT NULL,
    "created_at" TIMESTAMPTZ(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    -- A person can be credited to at most one inviter, once.
    CONSTRAINT "referrals_pkey" PRIMARY KEY ("invitee_id"),
    CONSTRAINT "referrals_invitee_fkey" FOREIGN KEY ("invitee_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "referrals_inviter_fkey" FOREIGN KEY ("inviter_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "referrals_not_self_chk" CHECK ("invitee_id" <> "inviter_id")
);
CREATE INDEX "referrals_inviter_idx" ON "referrals" ("inviter_id");
ALTER TABLE "referrals" ENABLE ROW LEVEL SECURITY;
