import type { Server } from 'socket.io';

/**
 * Thin publish interface between HTTP handlers/services and the Socket.IO server. Handlers call
 * `emitToUser` after a transaction commits; when no socket server is attached (tests of plain HTTP
 * behaviour, scripts) the calls are harmless no-ops. Payloads must only contain data the
 * *recipient* is allowed to see — the hub does no authorisation of its own.
 *
 * In-memory: rooms live in this process, so with several API instances an event only reaches
 * sockets connected to the instance that emitted it (see README, "Real-time messaging").
 */
export interface Hub {
  emitToUser(userId: string, event: string, payload?: unknown): void;
  /** Drop every live socket of a user (suspension, deletion). They may reconnect; per-event checks still apply. */
  disconnectUser(userId: string): void;
  bind(io: Server | null): void;
}

export const userRoom = (userId: string): string => `user:${userId}`;

export function createHub(): Hub {
  let io: Server | null = null;
  return {
    emitToUser(userId, event, payload) {
      io?.to(userRoom(userId)).emit(event, payload);
    },
    disconnectUser(userId) {
      io?.in(userRoom(userId)).disconnectSockets(true);
    },
    bind(server) {
      io = server;
    },
  };
}
