import type { Server as HttpServer } from 'node:http';
import type { Express } from 'express';
import { Server, type Socket } from 'socket.io';
import { z } from 'zod';
import type { RateLimit } from '../config/env.js';
import type { Ctx } from '../context.js';
import { AppError } from '../http/errors.js';
import { identify } from '../middleware/auth.js';
import { fetchCurrentUser } from '../middleware/user.js';
import { findActiveMatch } from '../modules/matches/service.js';
import { sendMessage, sendMessageSchema } from '../modules/messages/service.js';
import { eligibilityGaps, type CurrentUser } from '../modules/shared/eligibility.js';
import { userRoom } from './hub.js';
import { publishNewMessage } from './publish.js';

interface SocketData {
  userId: string;
  sub: string;
  /** Token expiry, epoch seconds. */
  exp: number | undefined;
  lastTypingAt: number;
}

type Ack = (r: { ok: true; message: unknown } | { ok: false; code: string; message: string }) => void;

const sendPayload = sendMessageSchema.extend({ matchId: z.string().uuid(), clientId: z.string().uuid() });
const typingPayload = z.object({ matchId: z.string().uuid(), typing: z.boolean() }).strict();

/** Small fixed-window limiter keyed by user id (in memory, like the HTTP limiter). */
export function createWindowLimiter(rl: RateLimit) {
  const hits = new Map<string, { count: number; resetAt: number }>();
  return {
    take(key: string, now = Date.now()): boolean {
      const h = hits.get(key);
      if (!h || h.resetAt <= now) {
        hits.set(key, { count: 1, resetAt: now + rl.windowMs });
        if (hits.size > 10_000) for (const [k, v] of hits) if (v.resetAt <= now) hits.delete(k);
        return true;
      }
      h.count += 1;
      return h.count <= rl.max;
    },
  };
}

const connectError = (code: string) => Object.assign(new Error(code), { data: { code } });

/**
 * Attach the Socket.IO server to the HTTP server.
 *
 * Authorisation model (nothing is trusted just because a socket is open):
 *  - Connecting needs a valid access token, verified by the same verifier as the REST API, for an
 *    active, eligible account.
 *  - EVERY event re-loads the account (suspension, deletion, eligibility) and re-checks the match
 *    (participant, ACTIVE, partner active, no block either way) before doing anything.
 *  - A socket is dropped when its token expires; the client reconnects with a fresh one.
 *  - Clients can only join their own `user:<id>` room, which the server does itself. There is no
 *    client-controlled "join room" event, so a guessed conversation id gives access to nothing.
 */
export function attachRealtime(server: HttpServer, app: Express): Server {
  const ctx = app.get('ctx') as Ctx;
  const { pool, config } = ctx;
  const io = new Server(server, {
    path: '/socket.io',
    serveClient: false,
    maxHttpBufferSize: 8 * 1024,
    connectTimeout: 10_000,
    cors: { origin: config.corsOrigins, methods: ['GET', 'POST'] },
  });
  ctx.hub.bind(io);
  const messageLimiter = createWindowLimiter(config.limits.message);
  // Typing hints are cheap but every one costs a database check, so they get their own ceiling.
  const typingLimiter = createWindowLimiter({ windowMs: 10_000, max: 30 });

  io.use(async (socket, next) => {
    const token: unknown = socket.handshake.auth?.token;
    if (typeof token !== 'string' || token.length === 0 || token.length > 4096) return next(connectError('UNAUTHENTICATED'));
    let identity;
    try {
      identity = await identify(ctx.verify, token);
    } catch {
      return next(connectError('INVALID_TOKEN'));
    }
    try {
      const user = await fetchCurrentUser(pool, identity.sub);
      if (!user || user.status !== 'ACTIVE' || eligibilityGaps(user).length > 0) return next(connectError('NOT_ELIGIBLE'));
      socket.data = { userId: user.id, sub: identity.sub, exp: identity.exp, lastTypingAt: 0 } satisfies SocketData;
      next();
    } catch {
      next(connectError('UNAVAILABLE')); // database trouble: the client may retry
    }
  });

  /**
   * The per-event check. Returns the live account, or null when it may no longer act; callers answer
   * the event first and then call `drop`, so the client still receives its refusal.
   */
  async function authorize(socket: Socket): Promise<CurrentUser | null> {
    const d = socket.data as SocketData;
    if (d.exp !== undefined && d.exp * 1000 <= Date.now()) {
      socket.emit('auth:expired');
      return null;
    }
    const user = await fetchCurrentUser(pool, d.sub);
    if (!user || user.status !== 'ACTIVE' || eligibilityGaps(user).length > 0) return null;
    return user;
  }
  const drop = (socket: Socket) => void socket.disconnect(true);

  io.on('connection', (socket) => {
    const d = socket.data as SocketData;
    void socket.join(userRoom(d.userId));

    // Stop trusting the connection when the token that opened it expires.
    let expiry: NodeJS.Timeout | undefined;
    if (d.exp !== undefined) {
      expiry = setTimeout(() => {
        socket.emit('auth:expired');
        socket.disconnect(true);
      }, Math.max(0, d.exp * 1000 - Date.now()));
      expiry.unref();
    }
    socket.on('disconnect', () => clearTimeout(expiry));

    socket.on('message:send', async (raw: unknown, ack?: Ack) => {
      const reply: Ack = typeof ack === 'function' ? ack : () => undefined;
      try {
        const user = await authorize(socket);
        if (!user) {
          reply({ ok: false, code: 'NOT_ELIGIBLE', message: 'You cannot send messages right now' });
          return drop(socket);
        }
        if (!messageLimiter.take(user.id)) return reply({ ok: false, code: 'RATE_LIMITED', message: 'You are sending messages too fast' });
        const parsed = sendPayload.safeParse(raw);
        if (!parsed.success) return reply({ ok: false, code: 'VALIDATION', message: 'Invalid message' });
        const { matchId, content, clientId } = parsed.data;
        const sent = await sendMessage(pool, user.id, matchId, content, clientId);
        publishNewMessage(ctx.hub, user.id, matchId, sent);
        reply({ ok: true, message: sent.message });
      } catch (err) {
        if (err instanceof AppError) reply({ ok: false, code: err.code, message: err.message });
        else reply({ ok: false, code: 'UNAVAILABLE', message: 'Could not send. Please try again.' }); // never log the payload
      }
    });

    // Typing events from one socket are handled strictly in arrival order. Each needs a database check, so
    // handling them concurrently could relay a late "started" after a "stopped" and leave the indicator stuck.
    let typingQueue: Promise<void> = Promise.resolve();
    const handleTyping = async (raw: unknown) => {
      try {
        const parsed = typingPayload.safeParse(raw);
        if (!parsed.success) return;
        const now = Date.now();
        // At most one "started typing" per second. A "stopped typing" ends the episode and re-arms the guard,
        // so someone who sends a message and immediately types again is still shown (the burst cap below bounds abuse).
        if (parsed.data.typing && now - d.lastTypingAt < 1000) return;
        if (parsed.data.typing) d.lastTypingAt = now;
        else d.lastTypingAt = 0;
        const user = await authorize(socket);
        if (!user) return drop(socket);
        if (!typingLimiter.take(user.id)) return;
        const match = await findActiveMatch(pool, parsed.data.matchId, user.id);
        if (!match) return; // silently ignored: not revealing whether the conversation exists
        ctx.hub.emitToUser(match.partner.id, 'typing', { matchId: parsed.data.matchId, typing: parsed.data.typing });
      } catch {
        /* typing hints are best-effort */
      }
    };
    socket.on('typing', (raw: unknown) => {
      typingQueue = typingQueue.then(() => handleTyping(raw));
    });
  });

  return io;
}
