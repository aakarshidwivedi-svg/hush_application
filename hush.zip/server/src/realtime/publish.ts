import type { SentMessage } from '../modules/messages/service.js';
import type { Hub } from './hub.js';

/**
 * Events are published only after the database transaction has committed, and each payload is built
 * for its recipient: the partner gets `mine: false`, the sender's other tabs get `mine: true`.
 * Nothing here ever mentions crushes — a one-sided crush produces no event at all.
 */
export function publishNewMessage(hub: Hub, senderId: string, matchId: string, sent: SentMessage): void {
  if (!sent.created) return; // a retried send was already delivered the first time
  hub.emitToUser(sent.partnerId, 'message:new', { matchId, message: { ...sent.message, mine: false } });
  hub.emitToUser(senderId, 'message:new', { matchId, message: sent.message, clientId: sent.clientId });
  hub.emitToUser(sent.partnerId, 'notifications:changed');
}

/** A match appeared, ended or changed for these people: they refetch their match list and inbox. */
export function publishMatchesChanged(hub: Hub, userIds: Iterable<string>): void {
  for (const id of new Set(userIds)) {
    hub.emitToUser(id, 'matches:changed');
    hub.emitToUser(id, 'notifications:changed');
  }
}
