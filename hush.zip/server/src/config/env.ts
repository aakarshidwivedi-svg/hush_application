import { randomBytes } from 'node:crypto';
import { z } from 'zod';

export interface RateLimit {
  windowMs: number;
  max: number;
}

export interface Limits {
  global: RateLimit;
  auth: RateLimit;
  crush: RateLimit;
  message: RateLimit;
  report: RateLimit;
  safety: RateLimit;
  /** Photo uploads and photo/interest edits (each upload runs image processing, so keep it modest). */
  upload: RateLimit;
}

export const defaultLimits: Limits = {
  global: { windowMs: 60_000, max: 300 },
  auth: { windowMs: 3_600_000, max: 20 },
  crush: { windowMs: 3_600_000, max: 60 },
  message: { windowMs: 60_000, max: 40 },
  report: { windowMs: 3_600_000, max: 10 },
  safety: { windowMs: 3_600_000, max: 60 },
  upload: { windowMs: 3_600_000, max: 60 },
};

export interface StorageConfig {
  driver: 'supabase' | 'local';
  /** Supabase Storage (server-side only; the service-role/secret key never reaches the browser). */
  supabaseUrl: string;
  serviceKey: string | undefined;
  bucket: string;
  /** Local-disk driver for development and tests. URLs are short-lived HMAC-signed links. */
  localDir: string;
  signingSecret: string;
  publicApiUrl: string;
  /** Lifetime of signed image URLs. */
  urlTtlSeconds: number;
}

export interface Config {
  env: 'development' | 'test' | 'production';
  port: number;
  logLevel: string;
  databaseUrl: string;
  directUrl: string | undefined;
  dbPoolMax: number;
  corsOrigins: string[];
  trustProxy: number;
  auth: {
    issuer: string;
    audience: string;
    hmacSecret: string | undefined;
    jwksUrl: string;
  };
  moderators: Set<string>;
  storage: StorageConfig;
  limits: Limits;
}

const csv = (v: string): string[] =>
  v
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  LOG_LEVEL: z.string().default('info'),
  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required'),
  DIRECT_URL: z.string().optional(),
  DB_POOL_MAX: z.coerce.number().int().positive().default(10),
  CORS_ORIGINS: z.string().default('http://localhost:5173'),
  TRUST_PROXY: z.coerce.number().int().min(0).default(0),
  SUPABASE_URL: z.string().url('SUPABASE_URL must be a URL'),
  SUPABASE_JWT_SECRET: z.string().min(16).optional(),
  MODERATOR_AUTH_SUBJECTS: z.string().default(''),
  /** Per-IP requests per minute across the API. Raise only for load tests or when many users share one IP (e.g. a campus NAT). */
  RATE_LIMIT_GLOBAL_MAX: z.coerce.number().int().min(10).optional(),
  STORAGE_DRIVER: z.enum(['supabase', 'local']).optional(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(20).optional(),
  PHOTO_BUCKET: z
    .string()
    .regex(/^[a-z0-9][a-z0-9_-]{2,62}$/, 'PHOTO_BUCKET must be a valid bucket name')
    .default('profile-photos'),
  LOCAL_STORAGE_DIR: z.string().default('./.storage'),
  MEDIA_SIGNING_SECRET: z.string().min(16).optional(),
  PUBLIC_API_URL: z.string().url().optional(),
  PHOTO_URL_TTL_SECONDS: z.coerce.number().int().min(60).max(86_400).default(3600),
});

/**
 * Parse and validate environment variables. Throws a readable error on misconfiguration
 * so the API never starts with missing auth settings.
 */
export function loadConfig(
  source: Record<string, string | undefined> = process.env,
  overrides: { limits?: Partial<Limits> } = {},
): Config {
  // Treat empty strings (e.g. `SUPABASE_JWT_SECRET=`) as unset.
  const cleaned = Object.fromEntries(Object.entries(source).filter(([, v]) => v !== undefined && v !== ''));
  const parsed = envSchema.safeParse(cleaned);
  if (!parsed.success) {
    const msg = parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ');
    throw new Error(`Invalid environment configuration: ${msg}`);
  }
  const e = parsed.data;
  const base = e.SUPABASE_URL.replace(/\/+$/, '');

  // Image storage. Supabase Storage whenever a server key is configured; the local driver is only
  // an implicit default outside production. Production must opt in explicitly and set a secret.
  const driver = e.STORAGE_DRIVER ?? (e.SUPABASE_SERVICE_ROLE_KEY ? 'supabase' : 'local');
  if (driver === 'supabase' && !e.SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('Invalid environment configuration: SUPABASE_SERVICE_ROLE_KEY is required when STORAGE_DRIVER=supabase');
  }
  if (driver === 'local' && e.NODE_ENV === 'production' && !(e.STORAGE_DRIVER === 'local' && e.MEDIA_SIGNING_SECRET && e.PUBLIC_API_URL)) {
    throw new Error(
      'Invalid environment configuration: production needs Supabase Storage (SUPABASE_SERVICE_ROLE_KEY) or an explicit STORAGE_DRIVER=local with MEDIA_SIGNING_SECRET and PUBLIC_API_URL',
    );
  }
  return {
    env: e.NODE_ENV,
    port: e.PORT,
    logLevel: e.LOG_LEVEL,
    databaseUrl: e.DATABASE_URL,
    directUrl: e.DIRECT_URL,
    dbPoolMax: e.DB_POOL_MAX,
    corsOrigins: csv(e.CORS_ORIGINS),
    trustProxy: e.TRUST_PROXY,
    auth: {
      issuer: `${base}/auth/v1`,
      audience: 'authenticated',
      hmacSecret: e.SUPABASE_JWT_SECRET,
      jwksUrl: `${base}/auth/v1/.well-known/jwks.json`,
    },
    moderators: new Set(csv(e.MODERATOR_AUTH_SUBJECTS)),
    storage: {
      driver,
      supabaseUrl: base,
      serviceKey: e.SUPABASE_SERVICE_ROLE_KEY,
      bucket: e.PHOTO_BUCKET,
      localDir: e.LOCAL_STORAGE_DIR,
      // Without a configured secret, a per-process random one is used (links die on restart, which is fine for dev).
      signingSecret: e.MEDIA_SIGNING_SECRET ?? randomBytes(32).toString('hex'),
      publicApiUrl: (e.PUBLIC_API_URL ?? `http://localhost:${e.PORT}/api/v1`).replace(/\/+$/, ''),
      urlTtlSeconds: e.PHOTO_URL_TTL_SECONDS,
    },
    limits: {
      ...defaultLimits,
      ...(e.RATE_LIMIT_GLOBAL_MAX ? { global: { ...defaultLimits.global, max: e.RATE_LIMIT_GLOBAL_MAX } } : {}),
      ...overrides.limits,
    },
  };
}
