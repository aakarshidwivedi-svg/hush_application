import { loadConfig } from '../config/env.js';
import { purgeDeletedAccounts } from '../modules/account/service.js';
import { createPhotoService } from '../modules/photos/service.js';
import { createStorage } from '../modules/photos/storage.js';
import { createPool } from './pool.js';

const config = loadConfig();
const pool = createPool(config.databaseUrl, 2);
try {
  console.log('purged', await purgeDeletedAccounts(pool));
  // Retry any image files that could not be deleted when their photo or account was removed.
  const photos = createPhotoService(pool, createStorage(config.storage));
  let removed = 0;
  for (let n = await photos.flushCleanup(); n > 0; n = await photos.flushCleanup()) removed += n;
  console.log('removed stored files', removed);
} finally {
  await pool.end();
}
