import { Router } from 'express';
import type { Ctx } from '../../context.js';
import { asyncHandler } from '../../http/errors.js';
import { ok, okPage } from '../../http/respond.js';
import { matchParams } from '../matches/routes.js';
import { publishNewMessage } from '../../realtime/publish.js';
import { listMessages, listMessagesQuerySchema, markRead, sendMessage, sendMessageSchema } from './service.js';

/** Mounted under /matches so the paths are /matches/:matchId/messages. */
export function messagesRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw } = ctx;

  r.get(
    '/:matchId/messages',
    mw.authenticate,
    mw.loadUser,
    mw.requireEligible,
    asyncHandler(async (req, res) => {
      const { matchId } = matchParams.parse(req.params);
      const q = listMessagesQuerySchema.parse(req.query);
      const { messages, nextCursor } = await listMessages(ctx.pool, req.user!.id, matchId, q);
      okPage(res, messages, { nextCursor });
    }),
  );

  r.post(
    '/:matchId/messages',
    mw.authenticate,
    ctx.limit.message,
    mw.loadUser,
    mw.requireEligible,
    asyncHandler(async (req, res) => {
      const { matchId } = matchParams.parse(req.params);
      const { content, clientId } = sendMessageSchema.parse(req.body);
      const sent = await sendMessage(ctx.pool, req.user!.id, matchId, content, clientId);
      publishNewMessage(ctx.hub, req.user!.id, matchId, sent);
      ok(res, sent.message, sent.created ? 201 : 200);
    }),
  );

  r.post(
    '/:matchId/read',
    mw.authenticate,
    mw.loadUser,
    mw.requireEligible,
    asyncHandler(async (req, res) => {
      const { matchId } = matchParams.parse(req.params);
      await markRead(ctx.pool, req.user!.id, matchId);
      ctx.hub.emitToUser(req.user!.id, 'notifications:changed'); // their other tabs update the badge
      ok(res, { status: 'read' });
    }),
  );

  return r;
}
