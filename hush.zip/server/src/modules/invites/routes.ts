import { Router } from 'express';
import type { Ctx } from '../../context.js';
import { asyncHandler } from '../../http/errors.js';
import { ok } from '../../http/respond.js';
import { myInvite } from './service.js';

export function invitesRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw } = ctx;

  // The caller's own invite code and a count. Never who joined: the count cannot be turned into a list.
  r.get(
    '/invites/me',
    mw.authenticate,
    mw.loadUser,
    mw.requireActive,
    ctx.limit.auth,
    asyncHandler(async (req, res) => {
      ok(res, await myInvite(ctx.pool, req.user!.id));
    }),
  );

  return r;
}
