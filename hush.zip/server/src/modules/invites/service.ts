import { randomBytes } from 'node:crypto';
import type { Db } from '../../db/pool.js';

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; // base32: no look-alike digits, 32 symbols so a byte maps evenly
export const INVITE_CODE_RE = /^[A-Z2-7]{10}$/;

export function newInviteCode(): string {
  const bytes = randomBytes(10);
  return Array.from(bytes, (b) => ALPHABET[b % 32]).join('');
}

/** Normalise user-supplied text (links get copied with spaces/lowercase). Returns null when it cannot be a code. */
export function normaliseInviteCode(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const c = raw.trim().toUpperCase();
  return INVITE_CODE_RE.test(c) ? c : null;
}

/** The caller's own link code (created on first use) and how many people joined through it. */
export async function myInvite(db: Db, userId: string): Promise<{ code: string; joined: number }> {
  for (let attempt = 0; attempt < 5; attempt++) {
    const existing = await db.query<{ code: string }>('SELECT code FROM invite_codes WHERE user_id = $1', [userId]);
    let code = existing.rows[0]?.code;
    if (!code) {
      const ins = await db.query<{ code: string }>(
        // Another request may have created it meanwhile (primary key) or the code may collide (unique): try again.
        'INSERT INTO invite_codes (user_id, code) VALUES ($1, $2) ON CONFLICT DO NOTHING RETURNING code',
        [userId, newInviteCode()],
      );
      code = ins.rows[0]?.code;
    }
    if (code) {
      const n = await db.query<{ n: number }>(
        `SELECT count(*)::int AS n
           FROM referrals r JOIN users u ON u.id = r.invitee_id
          WHERE r.inviter_id = $1 AND u.account_status <> 'DELETED'`,
        [userId],
      );
      return { code, joined: n.rows[0]!.n };
    }
  }
  throw new Error('Could not create an invite code');
}

/** Credit `inviteeId` to the owner of `rawCode`. Unknown codes, self-invites and repeats are silently ignored. */
export async function recordReferral(db: Db, inviteeId: string, rawCode: unknown): Promise<void> {
  const code = normaliseInviteCode(rawCode);
  if (!code) return;
  await db.query(
    `INSERT INTO referrals (invitee_id, inviter_id)
     SELECT $1, ic.user_id FROM invite_codes ic
      JOIN users u ON u.id = ic.user_id AND u.account_status = 'ACTIVE'
      WHERE ic.code = $2 AND ic.user_id <> $1
     ON CONFLICT DO NOTHING`,
    [inviteeId, code],
  );
}
