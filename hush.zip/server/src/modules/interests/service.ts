import { z } from 'zod';
import { withTx, type Db } from '../../db/pool.js';
import type { Pool } from 'pg';
import { validation } from '../../http/errors.js';

export const MIN_INTERESTS = 3;
export const MAX_INTERESTS = 10;

export interface InterestRef {
  id: string;
  name: string;
}
export interface InterestCategory {
  category: string;
  interests: InterestRef[];
}

/** Canonical interest ids only: lowercase slugs from the catalog. Duplicates are rejected, not silently merged. */
export const setInterestsSchema = z
  .object({
    interestIds: z
      .array(z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'Not a valid interest id').max(40))
      .min(MIN_INTERESTS, `Pick at least ${MIN_INTERESTS} interests`)
      .max(MAX_INTERESTS, `Pick up to ${MAX_INTERESTS} interests`),
  })
  .strict()
  .superRefine((v, ctx) => {
    if (new Set(v.interestIds).size !== v.interestIds.length) {
      ctx.addIssue({ code: 'custom', path: ['interestIds'], message: 'Each interest can only be picked once' });
    }
  });

/** The active catalog grouped by category, in display order. */
export async function listCatalog(db: Db): Promise<InterestCategory[]> {
  const { rows } = await db.query<{ id: string; name: string; category: string }>(
    'SELECT id, name, category FROM interests WHERE is_active ORDER BY category_order, sort_order, name',
  );
  const order: string[] = [];
  const byCat = new Map<string, InterestRef[]>();
  for (const r of rows) {
    if (!byCat.has(r.category)) {
      byCat.set(r.category, []);
      order.push(r.category);
    }
    byCat.get(r.category)!.push({ id: r.id, name: r.name });
  }
  return order.map((category) => ({ category, interests: byCat.get(category)! }));
}

/** Interests for people the caller has already been authorised to see. Inactive catalog entries are hidden. */
export async function interestsFor(db: Db, userIds: string[]): Promise<Map<string, InterestRef[]>> {
  const out = new Map<string, InterestRef[]>(userIds.map((id) => [id, []]));
  if (userIds.length === 0) return out;
  const { rows } = await db.query<{ user_id: string; id: string; name: string }>(
    `SELECT ui.user_id, i.id, i.name
       FROM user_interests ui JOIN interests i ON i.id = ui.interest_id AND i.is_active
      WHERE ui.user_id = ANY($1::uuid[])
      ORDER BY i.category_order, i.sort_order, i.name`,
    [userIds],
  );
  for (const r of rows) out.get(r.user_id)?.push({ id: r.id, name: r.name });
  return out;
}

/** Replace the caller's whole interest set atomically. */
export async function setMyInterests(pool: Pool, userId: string, interestIds: string[]): Promise<void> {
  await withTx(pool, async (c) => {
    await c.query('SELECT 1 FROM users WHERE id = $1 FOR UPDATE', [userId]); // serialise concurrent edits
    const known = await c.query<{ id: string }>('SELECT id FROM interests WHERE id = ANY($1::text[]) AND is_active', [interestIds]);
    if (known.rowCount !== interestIds.length) {
      const ok = new Set(known.rows.map((r) => r.id));
      const bad = interestIds.filter((id) => !ok.has(id));
      throw validation('Some interests are not available', [{ path: 'interestIds', message: `Unknown interest: ${bad.slice(0, 3).join(', ')}` }]);
    }
    await c.query('DELETE FROM user_interests WHERE user_id = $1 AND interest_id <> ALL($2::text[])', [userId, interestIds]);
    await c.query(
      'INSERT INTO user_interests (user_id, interest_id) SELECT $1, unnest($2::text[]) ON CONFLICT DO NOTHING',
      [userId, interestIds],
    );
  });
}
