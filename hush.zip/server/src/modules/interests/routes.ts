import { Router } from 'express';
import type { Ctx } from '../../context.js';
import { asyncHandler } from '../../http/errors.js';
import { ok } from '../../http/respond.js';
import { loadMe } from '../profiles/service.js';
import { listCatalog, setInterestsSchema, setMyInterests } from './service.js';

export function interestsRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw, pool } = ctx;

  // The catalog is not private, but it is only useful to signed-in people, so it needs a valid token.
  r.get(
    '/interests',
    mw.authenticate,
    asyncHandler(async (_req, res) => {
      res.set('Cache-Control', 'private, max-age=300');
      ok(res, await listCatalog(pool));
    }),
  );

  r.put(
    '/profiles/me/interests',
    mw.authenticate,
    ctx.limit.upload,
    mw.loadUser,
    mw.requireActive,
    asyncHandler(async (req, res) => {
      const { interestIds } = setInterestsSchema.parse(req.body);
      await setMyInterests(pool, req.user!.id, interestIds); // identity from the token, never the body
      ok(res, await loadMe(ctx, req.user!));
    }),
  );

  return r;
}
