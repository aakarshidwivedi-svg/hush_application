import path from 'node:path';
import express, { Router } from 'express';
import { z } from 'zod';
import type { Ctx } from '../../context.js';
import { AppError, asyncHandler, notFound } from '../../http/errors.js';
import { ok } from '../../http/respond.js';
import { MAX_UPLOAD_BYTES, processImage } from './processing.js';
import { LocalStorage } from './storage.js';

const photoParam = z.object({ photoId: z.string().uuid() });
const reorderSchema = z
  .object({ photoIds: z.array(z.string().uuid()).min(1).max(6) })
  .strict()
  .refine((v) => new Set(v.photoIds).size === v.photoIds.length, { message: 'Each photo can only be listed once', path: ['photoIds'] });

export function photosRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw, photos, storage } = ctx;
  const guard = [mw.authenticate, ctx.limit.upload, mw.loadUser, mw.requireActive];

  r.get(
    '/profiles/me/photos',
    mw.authenticate,
    mw.loadUser,
    asyncHandler(async (req, res) => {
      ok(res, await photos.listOwn(req.user!.id));
    }),
  );

  // The body is the image itself (Content-Type: image/jpeg | image/png | image/webp). The declared type
  // only selects the body parser; the real format is decided from the bytes in processImage().
  r.post(
    '/profiles/me/photos',
    ...guard,
    express.raw({ type: ['image/jpeg', 'image/png', 'image/webp'], limit: MAX_UPLOAD_BYTES }),
    asyncHandler(async (req, res) => {
      if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
        throw new AppError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Upload a JPEG, PNG or WebP image as the request body.');
      }
      const processed = await processImage(req.body);
      ok(res, await photos.add(req.user!.id, processed), 201);
    }),
  );

  r.patch(
    '/profiles/me/photos/reorder',
    ...guard,
    asyncHandler(async (req, res) => {
      const { photoIds } = reorderSchema.parse(req.body);
      await photos.reorder(req.user!.id, photoIds);
      ok(res, await photos.listOwn(req.user!.id));
    }),
  );

  r.patch(
    '/profiles/me/photos/:photoId/primary',
    ...guard,
    asyncHandler(async (req, res) => {
      const { photoId } = photoParam.parse(req.params);
      await photos.setPrimary(req.user!.id, photoId);
      ok(res, await photos.listOwn(req.user!.id));
    }),
  );

  r.delete(
    '/profiles/me/photos/:photoId',
    ...guard,
    asyncHandler(async (req, res) => {
      const { photoId } = photoParam.parse(req.params);
      await photos.remove(req.user!.id, photoId);
      ok(res, await photos.listOwn(req.user!.id));
    }),
  );

  // Local-disk driver only: serves objects for short-lived signed links. (Supabase serves its own.)
  if (storage instanceof LocalStorage) {
    r.get('/media/:folder/:file', (req, res, next) => {
      const exp = Number(req.query.exp);
      const sig = typeof req.query.sig === 'string' ? req.query.sig : '';
      const file = storage.verify(`${req.params.folder}/${req.params.file}`, exp, sig);
      if (!file) return next(notFound('Not found')); // bad, expired and missing links look the same
      // `root` + a relative path: dotfile rules then apply to the object path only, not to where the
      // storage directory happens to live (the development default is the dot-folder ./.storage).
      res.sendFile(
        path.relative(storage.rootDir, file),
        {
          root: storage.rootDir,
          dotfiles: 'deny',
          headers: {
            'Content-Type': 'image/webp',
            'Cache-Control': 'private, max-age=3600',
            // The client app lives on another origin; helmet's default would block the <img>.
            'Cross-Origin-Resource-Policy': 'cross-origin',
          },
        },
        (err) => {
          if (err && !res.headersSent) next(notFound('Not found'));
        },
      );
    });
  }

  return r;
}
