import { randomUUID } from 'node:crypto';
import type { Pool } from 'pg';
import { withTx, type Db } from '../../db/pool.js';
import { AppError, notFound } from '../../http/errors.js';
import type { ProcessedImage } from './processing.js';
import type { PhotoStorage } from './storage.js';

export const MAX_PHOTOS = 6;

export interface PhotoRef {
  url: string;
  thumbUrl: string;
  width: number;
  height: number;
}
export interface OwnPhoto extends PhotoRef {
  id: string;
  isPrimary: boolean;
  order: number;
}

interface PhotoRow {
  id: string;
  user_id: string;
  storage_path: string;
  thumb_path: string;
  width: number;
  height: number;
  display_order: number;
  is_primary: boolean;
}

/**
 * Photo operations. Everything is scoped by the authenticated user id passed in by the route
 * (never taken from the request), and other people's photo ids simply look like they don't exist.
 */
export function createPhotoService(pool: Pool, storage: PhotoStorage) {
  async function sign(rows: PhotoRow[]): Promise<Map<string, string>> {
    return storage.signedUrls(rows.flatMap((r) => [r.storage_path, r.thumb_path]));
  }

  const ref = (r: PhotoRow, urls: Map<string, string>): PhotoRef | null => {
    const url = urls.get(r.storage_path);
    const thumbUrl = urls.get(r.thumb_path);
    return url && thumbUrl ? { url, thumbUrl, width: r.width, height: r.height } : null;
  };

  async function listOwn(userId: string): Promise<OwnPhoto[]> {
    const { rows } = await pool.query<PhotoRow>(
      'SELECT id, user_id, storage_path, thumb_path, width, height, display_order, is_primary FROM profile_photos WHERE user_id = $1 ORDER BY display_order',
      [userId],
    );
    const urls = await sign(rows);
    return rows.flatMap((r) => {
      const p = ref(r, urls);
      return p ? [{ id: r.id, ...p, isPrimary: r.is_primary, order: r.display_order }] : [];
    });
  }

  /**
   * Primary photos for people the *caller has already been authorised to see* (discovery results,
   * the caller's own active matches, the caller themself). Never call this with ids taken from a request.
   */
  async function primaryFor(userIds: string[], db: Db = pool): Promise<Map<string, PhotoRef>> {
    const out = new Map<string, PhotoRef>();
    if (userIds.length === 0) return out;
    const { rows } = await db.query<PhotoRow>(
      'SELECT id, user_id, storage_path, thumb_path, width, height, display_order, is_primary FROM profile_photos WHERE is_primary AND user_id = ANY($1::uuid[])',
      [userIds],
    );
    let urls: Map<string, string>;
    try {
      urls = await sign(rows);
    } catch {
      return out; // photos are decoration: a storage hiccup must not take Discover down
    }
    for (const r of rows) {
      const p = ref(r, urls);
      if (p) out.set(r.user_id, p);
    }
    return out;
  }

  async function lockUser(c: Db, userId: string): Promise<void> {
    await c.query('SELECT 1 FROM users WHERE id = $1 FOR UPDATE', [userId]);
  }

  async function add(userId: string, img: ProcessedImage): Promise<OwnPhoto> {
    // Cheap pre-check so we don't write to storage for an obviously full profile.
    const pre = await pool.query<{ n: string }>('SELECT count(*) AS n FROM profile_photos WHERE user_id = $1', [userId]);
    if (Number(pre.rows[0]!.n) >= MAX_PHOTOS) throw new AppError(409, 'PHOTO_LIMIT', `You can have up to ${MAX_PHOTOS} photos. Delete one to add another.`);

    const id = randomUUID();
    // The folder is random, not derived from the user: signed URLs embed this path, and it should
    // say nothing about whose photo it is.
    const folder = randomUUID();
    const storagePath = `${folder}/${id}.webp`;
    const thumbPath = `${folder}/${id}_thumb.webp`;
    await storage.put(storagePath, img.full, 'image/webp');
    try {
      await storage.put(thumbPath, img.thumb, 'image/webp');
      await withTx(pool, async (c) => {
        await lockUser(c, userId); // serialise concurrent uploads for this person
        const { rows } = await c.query<{ slot: number | null; n: string }>(
          `SELECT (SELECT min(s) FROM generate_series(0, ${MAX_PHOTOS - 1}) s
                    WHERE NOT EXISTS (SELECT 1 FROM profile_photos WHERE user_id = $1 AND display_order = s)) AS slot,
                  (SELECT count(*) FROM profile_photos WHERE user_id = $1) AS n`,
          [userId],
        );
        const { slot, n } = rows[0]!;
        if (slot === null || Number(n) >= MAX_PHOTOS) throw new AppError(409, 'PHOTO_LIMIT', `You can have up to ${MAX_PHOTOS} photos. Delete one to add another.`);
        await c.query(
          `INSERT INTO profile_photos (id, user_id, storage_path, thumb_path, width, height, display_order, is_primary)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
          [id, userId, storagePath, thumbPath, img.width, img.height, slot, Number(n) === 0],
        );
      });
    } catch (err) {
      // Never leave files behind for a photo that was not recorded.
      await storage.remove([storagePath, thumbPath]).catch(() => undefined);
      throw err;
    }
    const created = (await listOwn(userId)).find((p) => p.id === id);
    if (!created) throw new Error('photo vanished after insert');
    return created;
  }

  async function reorder(userId: string, orderedIds: string[]): Promise<void> {
    await withTx(pool, async (c) => {
      await lockUser(c, userId);
      const { rows } = await c.query<{ id: string }>('SELECT id FROM profile_photos WHERE user_id = $1', [userId]);
      const have = new Set(rows.map((r) => r.id));
      if (orderedIds.length !== have.size || orderedIds.some((id) => !have.has(id))) {
        throw new AppError(422, 'VALIDATION_ERROR', 'List every one of your photos exactly once.', [{ path: 'photoIds', message: 'Must contain each of your photos exactly once' }]);
      }
      await c.query('SET CONSTRAINTS profile_photos_order_uniq DEFERRED');
      await c.query(
        `UPDATE profile_photos p SET display_order = v.ord
           FROM unnest($1::uuid[], $2::int[]) AS v(id, ord)
          WHERE p.id = v.id AND p.user_id = $3`,
        [orderedIds, orderedIds.map((_, i) => i), userId],
      );
    });
  }

  async function setPrimary(userId: string, photoId: string): Promise<void> {
    await withTx(pool, async (c) => {
      await lockUser(c, userId);
      const owned = await c.query('SELECT 1 FROM profile_photos WHERE id = $1 AND user_id = $2', [photoId, userId]);
      if (owned.rowCount === 0) throw notFound('Photo not found');
      await c.query('UPDATE profile_photos SET is_primary = false WHERE user_id = $1 AND is_primary', [userId]);
      await c.query('UPDATE profile_photos SET is_primary = true WHERE id = $1 AND user_id = $2', [photoId, userId]);
    });
  }

  async function remove(userId: string, photoId: string): Promise<void> {
    await withTx(pool, async (c) => {
      await lockUser(c, userId);
      const gone = await c.query<{ storage_path: string; thumb_path: string; is_primary: boolean }>(
        'DELETE FROM profile_photos WHERE id = $1 AND user_id = $2 RETURNING storage_path, thumb_path, is_primary',
        [photoId, userId],
      );
      const row = gone.rows[0];
      if (!row) throw notFound('Photo not found');
      await c.query('INSERT INTO storage_cleanup (path) VALUES ($1), ($2) ON CONFLICT DO NOTHING', [row.storage_path, row.thumb_path]);
      await c.query('SET CONSTRAINTS profile_photos_order_uniq DEFERRED');
      // Keep slots contiguous and make sure somebody is primary.
      await c.query(
        `UPDATE profile_photos p SET display_order = r.rn
           FROM (SELECT id, (row_number() OVER (ORDER BY display_order) - 1)::int AS rn FROM profile_photos WHERE user_id = $1) r
          WHERE p.id = r.id`,
        [userId],
      );
      if (row.is_primary) {
        await c.query(
          `UPDATE profile_photos SET is_primary = true
            WHERE id = (SELECT id FROM profile_photos WHERE user_id = $1 ORDER BY display_order LIMIT 1)`,
          [userId],
        );
      }
    });
    await flushCleanup();
  }

  /**
   * Delete queued objects from storage. Rows leave the queue only once the storage call succeeded,
   * so a failure is retried on the next flush (and by the daily `db:purge` job).
   */
  async function flushCleanup(limit = 100): Promise<number> {
    const { rows } = await pool.query<{ path: string }>('SELECT path FROM storage_cleanup ORDER BY queued_at LIMIT $1', [limit]);
    if (rows.length === 0) return 0;
    const paths = rows.map((r) => r.path);
    try {
      await storage.remove(paths);
    } catch {
      await pool.query('UPDATE storage_cleanup SET attempts = attempts + 1 WHERE path = ANY($1::text[])', [paths]);
      return 0;
    }
    await pool.query('DELETE FROM storage_cleanup WHERE path = ANY($1::text[])', [paths]);
    return paths.length;
  }

  return { listOwn, primaryFor, add, reorder, setPrimary, remove, flushCleanup };
}

export type PhotoService = ReturnType<typeof createPhotoService>;
