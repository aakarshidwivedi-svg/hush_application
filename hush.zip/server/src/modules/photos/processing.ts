import sharp from 'sharp';
import { AppError } from '../../http/errors.js';

/** Raw upload ceiling. The browser downsizes first, so honest uploads are far smaller. */
export const MAX_UPLOAD_BYTES = 6 * 1024 * 1024;
export const MIN_SIDE = 300;
export const MAX_SIDE = 12_000;
const MAX_PIXELS = 50_000_000; // decompression-bomb guard
export const FULL_BOX = { width: 1280, height: 1600 };
export const THUMB_BOX = { width: 480, height: 600 };

const invalid = (message: string) => new AppError(422, 'INVALID_IMAGE', message);

/** Identify the real format from the bytes — never from the declared Content-Type or file name. */
function sniff(b: Buffer): 'jpeg' | 'png' | 'webp' | null {
  if (b.length > 12 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpeg';
  if (b.length > 12 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (b.length > 12 && b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP') return 'webp';
  return null;
}

export interface ProcessedImage {
  full: Buffer;
  thumb: Buffer;
  width: number;
  height: number;
}

/**
 * Validate and normalise an uploaded photo:
 *  - magic-byte check (JPEG / PNG / WebP only; SVG, GIF, HEIC, TIFF, scripts renamed to .jpg … are refused),
 *  - dimension and pixel-count limits,
 *  - auto-rotate, then re-encode to WebP at two sizes. Re-encoding drops EXIF/GPS and any
 *    payload hidden in metadata, and means only bytes *we* produced are ever stored or served.
 */
export async function processImage(input: Buffer): Promise<ProcessedImage> {
  if (!sniff(input)) throw invalid('Only JPEG, PNG and WebP images are accepted.');
  const open = () => sharp(input, { limitInputPixels: MAX_PIXELS, failOn: 'error' });

  const meta = await open().metadata().catch(() => null);
  if (!meta) throw invalid('That image could not be read. Try a different file.');
  if ((meta.pages ?? 1) > 1) throw invalid('Animated images are not supported.');
  const rotated = (meta.orientation ?? 1) >= 5; // EXIF orientations 5–8 swap width and height
  const w = (rotated ? meta.height : meta.width) ?? 0;
  const h = (rotated ? meta.width : meta.height) ?? 0;
  if (Math.min(w, h) < MIN_SIDE) throw invalid(`Photos must be at least ${MIN_SIDE}×${MIN_SIDE} pixels.`);
  if (Math.max(w, h) > MAX_SIDE) throw invalid(`Photos can be at most ${MAX_SIDE} pixels on a side.`);

  try {
    const full = await open().rotate().resize({ ...FULL_BOX, fit: 'inside', withoutEnlargement: true }).webp({ quality: 82 }).toBuffer({ resolveWithObject: true });
    const thumb = await open().rotate().resize({ ...THUMB_BOX, fit: 'inside', withoutEnlargement: true }).webp({ quality: 78 }).toBuffer();
    return { full: full.data, thumb, width: full.info.width, height: full.info.height };
  } catch {
    throw invalid('That image could not be processed. Try a different file.');
  }
}
