import { Router } from 'express';
import type { Ctx } from '../../context.js';
import { asyncHandler } from '../../http/errors.js';
import { ok } from '../../http/respond.js';
import { activePartnerIds } from '../matches/service.js';
import { publishMatchesChanged } from '../../realtime/publish.js';
import { deleteAccount, deleteAccountSchema } from './service.js';

export function accountRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw } = ctx;

  // Deliberately available to suspended accounts too: people can always leave.
  r.delete(
    '/account',
    mw.authenticate,
    ctx.limit.safety,
    mw.loadUser,
    asyncHandler(async (req, res) => {
      deleteAccountSchema.parse(req.body);
      const partners = await activePartnerIds(ctx.pool, req.user!.id); // before the matches are ended
      await deleteAccount(ctx.pool, req.user!.id);
      ctx.hub.disconnectUser(req.user!.id);
      publishMatchesChanged(ctx.hub, partners);
      // Remove the queued image files now; a failure is retried by the next flush / `db:purge`.
      await ctx.photos.flushCleanup().catch(() => undefined);
      ok(res, { status: 'deleted' });
    }),
  );

  return r;
}
