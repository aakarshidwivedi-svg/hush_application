import { Router } from 'express';
import { z } from 'zod';
import type { Ctx } from '../../context.js';
import { AppError, asyncHandler } from '../../http/errors.js';
import { ok } from '../../http/respond.js';
import { publishMatchesChanged } from '../../realtime/publish.js';
import { sendCrush, withdrawCrush } from './service.js';

const params = z.object({ userId: z.string().uuid() });

export function crushesRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw } = ctx;
  const guard = [mw.authenticate, ctx.limit.crush, mw.loadUser, mw.requireEligible];

  // There is deliberately no GET/list endpoint: crush records are write-only for clients.

  r.post(
    '/:userId',
    ...guard,
    mw.requireCompleteProfile,
    asyncHandler(async (req, res) => {
      const { userId } = params.parse(req.params);
      const sender = req.user!; // sender identity comes only from the verified token
      if (userId === sender.id) throw new AppError(422, 'CANNOT_CRUSH_SELF', 'You cannot send a crush to yourself');
      const created = await sendCrush(ctx.pool, sender, userId);
      // Only a committed, mutual match produces an event; one-sided interest never does.
      if (created) publishMatchesChanged(ctx.hub, [sender.id, userId]);
      // Identical for one-sided interest, a new match, a repeat, or a silently-ignored crush.
      ok(res, { status: 'sent' });
    }),
  );

  r.delete(
    '/:userId',
    ...guard,
    asyncHandler(async (req, res) => {
      const { userId } = params.parse(req.params);
      await withdrawCrush(ctx.pool, req.user!, userId);
      ok(res, { status: 'withdrawn' });
    }),
  );

  return r;
}
