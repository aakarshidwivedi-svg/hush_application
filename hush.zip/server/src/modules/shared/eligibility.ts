export interface CampusConfig {
  /** Email domains (and their subdomains) accepted for campus verification. */
  emailDomains?: string[];
  /** When true, self-attested age is not enough: a moderator must mark the user VERIFIED. */
  requireVerifiedAge?: boolean;
}

/** A profile needs at least this many interests (and one photo) to appear in Discover. */
export const MIN_INTERESTS = 3;

export type AgeStatus = 'UNVERIFIED' | 'SELF_ATTESTED' | 'VERIFIED';
export type CampusStatus = 'UNVERIFIED' | 'VERIFIED';
export type AccountStatus = 'ACTIVE' | 'SUSPENDED' | 'DELETED';

export interface CurrentUser {
  id: string;
  authSubject: string;
  campusId: string;
  campusName: string;
  campusActive: boolean;
  campusConfig: CampusConfig;
  ageStatus: AgeStatus;
  campusStatus: CampusStatus;
  status: AccountStatus;
}

/** Which eligibility requirements a user is still missing (empty = eligible). */
export function eligibilityGaps(u: CurrentUser): string[] {
  const gaps: string[] = [];
  if (u.status !== 'ACTIVE') gaps.push('account_not_active');
  if (!u.campusActive) gaps.push('campus_inactive');
  if (u.campusStatus !== 'VERIFIED') gaps.push('campus_verification');
  const ageOk = u.ageStatus === 'VERIFIED' || (u.ageStatus === 'SELF_ATTESTED' && u.campusConfig.requireVerifiedAge !== true);
  if (!ageOk) gaps.push('age_verification');
  return gaps;
}

/**
 * SQL predicate equivalent to `eligibilityGaps(...).length === 0` for a users row `u` joined
 * to its campus `c`. Keep the two in sync: discovery and crush targets use the SQL form.
 */
export function eligibleUserSql(u = 'u', c = 'c'): string {
  return `(${u}.account_status = 'ACTIVE'
    AND ${u}.campus_status = 'VERIFIED'
    AND ${c}.is_active
    AND (${u}.age_status = 'VERIFIED'
         OR (${u}.age_status = 'SELF_ATTESTED'
             AND COALESCE(${c}.verification_config->>'requireVerifiedAge', 'false') <> 'true')))`;
}

/** True when `email`'s domain equals, or is a subdomain of, one of the campus domains. */
export function emailMatchesCampus(email: string | undefined, config: CampusConfig): boolean {
  if (!email) return false;
  const at = email.lastIndexOf('@');
  if (at < 1) return false;
  const domain = email.slice(at + 1).toLowerCase();
  return (config.emailDomains ?? []).some((raw) => {
    const d = raw.toLowerCase().replace(/^@/, '');
    return domain === d || domain.endsWith(`.${d}`);
  });
}

/**
 * SQL predicate: the person's profile is complete (>= 1 photo and >= MIN_INTERESTS active interests).
 * Used with `eligibleUserSql` wherever someone could be shown to, or targeted by, another person.
 */
export function completeProfileSql(u = 'u'): string {
  return `(EXISTS (SELECT 1 FROM profile_photos ph WHERE ph.user_id = ${u}.id)
    AND (SELECT count(*) FROM user_interests ui JOIN interests i ON i.id = ui.interest_id AND i.is_active
          WHERE ui.user_id = ${u}.id) >= ${MIN_INTERESTS})`;
}
