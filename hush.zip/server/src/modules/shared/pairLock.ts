import type { PoolClient } from 'pg';

/**
 * Transaction-scoped advisory lock keyed on the *unordered* pair of users.
 *
 * Why: under READ COMMITTED, if A→B and B→A are processed concurrently, each transaction can
 * insert its own crush and then fail to see the other's uncommitted row — so neither creates a
 * match and the mutual interest is silently lost. Taking this lock first serialises every
 * operation touching the pair (crush, withdraw, block, unmatch), so the second transaction
 * always sees the first one's committed crush. Unique constraints and canonical (user_a < user_b)
 * ordering remain as a database-level backstop.
 */
export const PAIR_LOCK_SQL = `SELECT pg_advisory_xact_lock(
  hashtextextended(LEAST($1::uuid, $2::uuid)::text || ':' || GREATEST($1::uuid, $2::uuid)::text, 0))`;

export async function lockPair(client: PoolClient, a: string, b: string): Promise<void> {
  await client.query(PAIR_LOCK_SQL, [a, b]);
}
