import { Router } from 'express';
import { z } from 'zod';
import type { Ctx } from '../../context.js';
import { AppError, asyncHandler } from '../../http/errors.js';
import { ok } from '../../http/respond.js';
import { publishMatchesChanged } from '../../realtime/publish.js';
import { blockUser, listBlocked, unblockUser } from './service.js';

const params = z.object({ userId: z.string().uuid() });

export function blocksRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw } = ctx;
  // Blocking must stay available to any live account, even one that is not yet fully eligible.
  const guard = [mw.authenticate, ctx.limit.safety, mw.loadUser, mw.requireActive];

  r.post(
    '/users/:userId/block',
    ...guard,
    asyncHandler(async (req, res) => {
      const { userId } = params.parse(req.params);
      if (userId === req.user!.id) throw new AppError(422, 'CANNOT_BLOCK_SELF', 'You cannot block yourself');
      await blockUser(ctx.pool, req.user!, userId);
      publishMatchesChanged(ctx.hub, [req.user!.id, userId]);
      ok(res, { status: 'blocked' });
    }),
  );

  r.delete(
    '/users/:userId/block',
    ...guard,
    asyncHandler(async (req, res) => {
      const { userId } = params.parse(req.params);
      await unblockUser(ctx.pool, req.user!, userId);
      ok(res, { status: 'unblocked' });
    }),
  );

  r.get(
    '/blocks',
    mw.authenticate,
    mw.loadUser,
    mw.requireActive,
    asyncHandler(async (req, res) => {
      ok(res, await listBlocked(ctx.pool, req.user!.id));
    }),
  );

  return r;
}
