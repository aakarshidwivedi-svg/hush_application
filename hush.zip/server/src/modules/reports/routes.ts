import { Router } from 'express';
import { z } from 'zod';
import type { Ctx } from '../../context.js';
import { AppError, asyncHandler } from '../../http/errors.js';
import { ok, okPage } from '../../http/respond.js';
import { activePartnerIds } from '../matches/service.js';
import {
  createReportSchema,
  fileReport,
  getReport,
  listAudit,
  listAuditQuerySchema,
  listReports,
  listReportsQuerySchema,
  moderateUser,
  moderateUserSchema,
  reviewReport,
  reviewReportSchema,
  type ModerationAction,
} from './service.js';

const idParam = z.object({ id: z.string().uuid() });
const userParam = z.object({ userId: z.string().uuid() });

export function reportsRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw } = ctx;

  r.post(
    '/reports',
    mw.authenticate,
    ctx.limit.report,
    mw.loadUser,
    mw.requireActive,
    asyncHandler(async (req, res) => {
      const input = createReportSchema.parse(req.body);
      if (input.targetId === req.user!.id) throw new AppError(422, 'CANNOT_REPORT_SELF', 'You cannot report yourself');
      await fileReport(ctx.pool, req.user!.id, input);
      ok(res, { status: 'received' }, 201);
    }),
  );

  // ---- Moderators only. Everyone else gets a plain 404, so these routes are not advertised. ----
  // The moderator list lives in server configuration and is matched against the *verified* token
  // subject; nothing the browser sends (role claims, ids, headers) can grant access.
  const mod = [mw.authenticate, mw.requireModerator, ctx.limit.safety];

  /** Lets the dashboard ask "am I a moderator?". Non-moderators get the same 404 as any hidden route. */
  r.get('/moderation/me', ...mod, (_req, res) => {
    ok(res, { moderator: true });
  });

  r.get(
    '/moderation/reports',
    ...mod,
    asyncHandler(async (req, res) => {
      const q = listReportsQuerySchema.parse(req.query);
      const { items, total } = await listReports(ctx.pool, q);
      okPage(res, items, { nextCursor: null, total, limit: q.limit, offset: q.offset });
    }),
  );

  r.get(
    '/moderation/reports/:id',
    ...mod,
    asyncHandler(async (req, res) => {
      const { id } = idParam.parse(req.params);
      ok(res, await getReport(ctx.pool, id));
    }),
  );

  r.patch(
    '/moderation/reports/:id',
    ...mod,
    asyncHandler(async (req, res) => {
      const { id } = idParam.parse(req.params);
      await reviewReport(ctx.pool, id, req.auth!.sub, reviewReportSchema.parse(req.body));
      ok(res, { status: 'updated' });
    }),
  );

  r.get(
    '/moderation/audit',
    ...mod,
    asyncHandler(async (req, res) => {
      const q = listAuditQuerySchema.parse(req.query);
      const { items, total } = await listAudit(ctx.pool, q);
      okPage(res, items, { nextCursor: null, total, limit: q.limit, offset: q.offset });
    }),
  );

  for (const action of ['suspend', 'reinstate', 'verify-age', 'verify-campus'] as ModerationAction[]) {
    r.post(
      `/moderation/users/:userId/${action}`,
      ...mod,
      asyncHandler(async (req, res) => {
        const { userId } = userParam.parse(req.params);
        const input = moderateUserSchema.parse(req.body);
        // Partners are looked up first: after suspension the match is no longer "active" for them.
        const partners = action === 'suspend' ? await activePartnerIds(ctx.pool, userId) : [];
        const changed = await moderateUser(ctx.pool, userId, action, req.auth!.sub, input, ctx.config.moderators);
        if (changed && action === 'suspend') {
          ctx.hub.disconnectUser(userId);
          for (const p of partners) ctx.hub.emitToUser(p, 'matches:changed');
        } else if (changed && action === 'reinstate') {
          for (const p of await activePartnerIds(ctx.pool, userId)) ctx.hub.emitToUser(p, 'matches:changed');
        }
        ok(res, { status: 'updated' });
      }),
    );
  }

  return r;
}
