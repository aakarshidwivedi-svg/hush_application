import type { Pool } from 'pg';
import { z } from 'zod';
import { withTx, type Db } from '../../db/pool.js';
import { AppError, notFound } from '../../http/errors.js';
import { text } from '../../lib/sanitize.js';

export const REPORT_REASONS = ['HARASSMENT', 'SPAM', 'FAKE_PROFILE', 'INAPPROPRIATE_CONTENT', 'UNDERAGE', 'OTHER'] as const;
export const REPORT_STATUSES = ['OPEN', 'REVIEWING', 'ACTIONED', 'DISMISSED'] as const;

export const createReportSchema = z
  .object({
    targetId: z.string().uuid(),
    reason: z.enum(REPORT_REASONS),
    details: text(1, 1000, true).optional(),
  })
  .strict();

/**
 * File a report. The caller always gets the same acknowledgement, whether the report was stored,
 * merged into an existing open report, or the target id did not exist — so reporting cannot be
 * used to enumerate accounts, and repeat clicks cannot flood moderators.
 */
export async function fileReport(
  pool: Pool,
  reporterId: string,
  input: { targetId: string; reason: (typeof REPORT_REASONS)[number]; details?: string | undefined },
): Promise<void> {
  const target = await pool.query(`SELECT 1 FROM users WHERE id = $1 AND account_status <> 'DELETED'`, [input.targetId]);
  if (target.rowCount === 0) return;
  // One live (OPEN/REVIEWING) report per reporter+target; the partial unique index makes this race-safe.
  await pool.query(
    `INSERT INTO reports (reporter_id, target_id, reason, details)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (reporter_id, target_id) WHERE status IN ('OPEN', 'REVIEWING') DO NOTHING`,
    [reporterId, input.targetId, input.reason, input.details ?? null],
  );
}

// ---- Moderator-only operations -------------------------------------------------------------

const dateInput = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD');

export const listReportsQuerySchema = z.object({
  status: z.enum(REPORT_STATUSES).optional(),
  /** "Category" in the dashboard. */
  reason: z.enum(REPORT_REASONS).optional(),
  /** Inclusive day range on the report's creation date (UTC). */
  from: dateInput.optional(),
  to: dateInput.optional(),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).max(10_000).default(0),
});

/** Why a moderator did something. Stored in the audit log, never shown to ordinary users. */
const reasonField = text(1, 500, true);

export const reviewReportSchema = z
  .object({
    status: z.enum(['REVIEWING', 'ACTIONED', 'DISMISSED']),
    /** Required when closing a report, so every decision carries a reason. */
    note: reasonField.optional(),
  })
  .strict()
  .refine((v) => v.status === 'REVIEWING' || v.note !== undefined, { message: 'A reason is required to close a report', path: ['note'] });

export const moderateUserSchema = z.object({ reason: reasonField, reportId: z.string().uuid().optional() }).strict();

export interface ModerationReport {
  id: string;
  reason: string;
  details: string | null;
  status: string;
  createdAt: Date;
  reporter: { id: string; nickname: string | null };
  target: {
    id: string;
    nickname: string | null;
    bio: string | null;
    accountStatus: string;
    campusStatus: string;
    ageStatus: string;
    /** Totals only; who filed or who blocked is never listed here. */
    reportsReceived: number;
    blockedByCount: number;
  };
  reviewedAt: Date | null;
  /** Short, non-reversible label of the reviewing moderator (first 8 chars of their auth subject). */
  reviewedBy: string | null;
  resolutionNote: string | null;
}

const REPORT_SELECT = `
  SELECT r.id, r.reason, r.details, r.status, r.created_at, r.reviewed_at, r.reviewed_by, r.resolution_note,
         r.reporter_id, rp.nickname AS reporter_nickname,
         r.target_id, tp.nickname AS target_nickname, tp.bio AS target_bio,
         tu.account_status AS target_status, tu.campus_status AS target_campus, tu.age_status AS target_age,
         (SELECT count(*) FROM reports x WHERE x.target_id = r.target_id)::int AS reports_received,
         (SELECT count(*) FROM blocks b WHERE b.blocked_id = r.target_id)::int AS blocked_by_count
    FROM reports r
    JOIN users tu ON tu.id = r.target_id
    LEFT JOIN profiles rp ON rp.user_id = r.reporter_id
    LEFT JOIN profiles tp ON tp.user_id = r.target_id`;

function toReport(r: Record<string, any>): ModerationReport {
  return {
    id: r.id,
    reason: r.reason,
    details: r.details,
    status: r.status,
    createdAt: r.created_at,
    reporter: { id: r.reporter_id, nickname: r.reporter_nickname },
    target: {
      id: r.target_id,
      nickname: r.target_nickname,
      bio: r.target_bio,
      accountStatus: r.target_status,
      campusStatus: r.target_campus,
      ageStatus: r.target_age,
      reportsReceived: r.reports_received,
      blockedByCount: r.blocked_by_count,
    },
    reviewedAt: r.reviewed_at,
    reviewedBy: r.reviewed_by ? String(r.reviewed_by).slice(0, 8) : null,
    resolutionNote: r.resolution_note,
  };
}

/** Oldest first, so the queue is worked in order. Filters are all optional and parameterised. */
export async function listReports(
  db: Db,
  q: { status?: string | undefined; reason?: string | undefined; from?: string | undefined; to?: string | undefined; limit: number; offset: number },
): Promise<{ items: ModerationReport[]; total: number }> {
  const where = `WHERE ($1::"ReportStatus" IS NULL OR r.status = $1::"ReportStatus")
       AND ($2::"ReportReason" IS NULL OR r.reason = $2::"ReportReason")
       AND ($3::date IS NULL OR r.created_at >= $3::date)
       AND ($4::date IS NULL OR r.created_at < ($4::date + 1))`;
  const filters = [q.status ?? null, q.reason ?? null, q.from ?? null, q.to ?? null];
  const [rows, count] = await Promise.all([
    db.query(`${REPORT_SELECT} ${where} ORDER BY r.created_at ASC, r.id ASC LIMIT $5 OFFSET $6`, [...filters, q.limit, q.offset]),
    db.query<{ n: number }>(`SELECT count(*)::int AS n FROM reports r ${where}`, filters),
  ]);
  return { items: rows.rows.map(toReport), total: count.rows[0]!.n };
}

export interface AuditEntry {
  id: string;
  action: string;
  reason: string;
  detail: string | null;
  createdAt: Date;
  /** First 8 characters of the moderator's auth subject. */
  moderator: string;
  targetId: string | null;
  reportId: string | null;
}

export async function listAudit(db: Db, q: { targetId?: string | undefined; reportId?: string | undefined; limit: number; offset: number }): Promise<{ items: AuditEntry[]; total: number }> {
  const where = `WHERE ($1::uuid IS NULL OR target_user_id = $1) AND ($2::uuid IS NULL OR report_id = $2)`;
  const f = [q.targetId ?? null, q.reportId ?? null];
  const [rows, count] = await Promise.all([
    db.query(
      `SELECT id, action, reason, detail, created_at, moderator_subject, target_user_id, report_id
         FROM moderation_actions ${where} ORDER BY created_at DESC, id DESC LIMIT $3 OFFSET $4`,
      [...f, q.limit, q.offset],
    ),
    db.query<{ n: number }>(`SELECT count(*)::int AS n FROM moderation_actions ${where}`, f),
  ]);
  return {
    items: rows.rows.map((r) => ({
      id: r.id,
      action: r.action,
      reason: r.reason,
      detail: r.detail,
      createdAt: r.created_at,
      moderator: String(r.moderator_subject).slice(0, 8),
      targetId: r.target_user_id,
      reportId: r.report_id,
    })),
    total: count.rows[0]!.n,
  };
}

export const listAuditQuerySchema = z.object({
  targetId: z.string().uuid().optional(),
  reportId: z.string().uuid().optional(),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  offset: z.coerce.number().int().min(0).max(10_000).default(0),
});

export async function getReport(db: Db, id: string): Promise<{ report: ModerationReport; history: AuditEntry[] }> {
  const { rows } = await db.query(`${REPORT_SELECT} WHERE r.id = $1`, [id]);
  if (!rows[0]) throw notFound('Report not found');
  const report = toReport(rows[0]);
  const history = await listAudit(db, { targetId: report.target.id, limit: 20, offset: 0 });
  return { report, history: history.items };
}

const REVIEW_ACTION = { REVIEWING: 'REPORT_REVIEWING', ACTIONED: 'REPORT_ACTIONED', DISMISSED: 'REPORT_DISMISSED' } as const;

/** Update a report and write the audit row in one transaction: a decision is never recorded without its trail. */
export async function reviewReport(
  pool: Pool,
  reportId: string,
  moderatorSubject: string,
  input: { status: 'REVIEWING' | 'ACTIONED' | 'DISMISSED'; note?: string | undefined },
): Promise<void> {
  await withTx(pool, async (c) => {
    const r = await c.query<{ target_id: string }>(
      `UPDATE reports SET status = $2, reviewed_by = $3, reviewed_at = now(), resolution_note = $4
        WHERE id = $1 RETURNING target_id`,
      [reportId, input.status, moderatorSubject, input.note ?? null],
    );
    if (r.rowCount === 0) throw notFound('Report not found');
    await c.query(
      `INSERT INTO moderation_actions (moderator_subject, action, target_user_id, report_id, reason)
       VALUES ($1, $2, $3, $4, $5)`,
      [moderatorSubject, REVIEW_ACTION[input.status], r.rows[0]!.target_id, reportId, input.note ?? 'Marked as under review'],
    );
  });
}

export type ModerationAction = 'suspend' | 'reinstate' | 'verify-age' | 'verify-campus';

const ACTION_SQL: Record<ModerationAction, { audit: string; sql: string }> = {
  suspend: { audit: 'SUSPEND', sql: `UPDATE users SET account_status = 'SUSPENDED' WHERE id = $1 AND account_status = 'ACTIVE'` },
  reinstate: { audit: 'REINSTATE', sql: `UPDATE users SET account_status = 'ACTIVE' WHERE id = $1 AND account_status = 'SUSPENDED'` },
  'verify-age': { audit: 'VERIFY_AGE', sql: `UPDATE users SET age_status = 'VERIFIED' WHERE id = $1 AND account_status <> 'DELETED' AND age_status <> 'VERIFIED'` },
  'verify-campus': { audit: 'VERIFY_CAMPUS', sql: `UPDATE users SET campus_status = 'VERIFIED' WHERE id = $1 AND account_status <> 'DELETED' AND campus_status <> 'VERIFIED'` },
};

/**
 * Account-level moderation. DELETED tombstones are never touched, and a moderator account cannot be
 * suspended through this path (a compromised or mistaken action must not lock moderators out).
 * Returns whether anything changed; only real changes are written to the audit log.
 */
export async function moderateUser(
  pool: Pool,
  userId: string,
  action: ModerationAction,
  moderatorSubject: string,
  input: { reason: string; reportId?: string | undefined },
  moderators: ReadonlySet<string>,
): Promise<boolean> {
  return withTx(pool, async (c) => {
    const u = await c.query<{ auth_subject: string }>(
      `SELECT auth_subject FROM users WHERE id = $1 AND account_status <> 'DELETED' FOR UPDATE`,
      [userId],
    );
    if (u.rowCount === 0) throw notFound('User not found');
    if (action === 'suspend' && moderators.has(u.rows[0]!.auth_subject)) {
      throw new AppError(422, 'CANNOT_MODERATE_MODERATOR', 'Moderator accounts cannot be suspended here');
    }
    if (input.reportId) {
      const own = await c.query('SELECT 1 FROM reports WHERE id = $1 AND target_id = $2', [input.reportId, userId]);
      if (own.rowCount === 0) throw notFound('Report not found');
    }
    const spec = ACTION_SQL[action];
    const changed = ((await c.query(spec.sql, [userId])).rowCount ?? 0) > 0;
    if (changed) {
      await c.query(
        `INSERT INTO moderation_actions (moderator_subject, action, target_user_id, report_id, reason)
         VALUES ($1, $2, $3, $4, $5)`,
        [moderatorSubject, spec.audit, userId, input.reportId ?? null, input.reason],
      );
    }
    return changed;
  });
}
