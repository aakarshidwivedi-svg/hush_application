import type { Ctx } from '../../context.js';
import { pgConstraint, pgErrorCode, type Db } from '../../db/pool.js';
import { conflict } from '../../http/errors.js';
import { eligibilityGaps, MIN_INTERESTS, type CurrentUser } from '../shared/eligibility.js';
import { interestsFor } from '../interests/service.js';
import type { UpdateProfileInput } from './schemas.js';

interface ProfileRow {
  user_id: string;
  nickname: string;
  bio: string;
  discoverable: boolean;
  updated_at: Date;
}

const PROFILE_COLUMNS = 'user_id, nickname, bio, discoverable, updated_at';

export async function getProfileRow(db: Db, userId: string): Promise<ProfileRow | null> {
  const { rows } = await db.query<ProfileRow>(`SELECT ${PROFILE_COLUMNS} FROM profiles WHERE user_id = $1`, [userId]);
  return rows[0] ?? null;
}

export interface ProfileCounts {
  photos: number;
  interests: number;
}

export async function profileCounts(db: Db, userId: string): Promise<ProfileCounts> {
  const { rows } = await db.query<{ photos: string; interests: string }>(
    `SELECT (SELECT count(*) FROM profile_photos WHERE user_id = $1) AS photos,
            (SELECT count(*) FROM user_interests ui JOIN interests i ON i.id = ui.interest_id AND i.is_active WHERE ui.user_id = $1) AS interests`,
    [userId],
  );
  return { photos: Number(rows[0]!.photos), interests: Number(rows[0]!.interests) };
}

/** What a profile still needs before it may appear in Discover or send crushes. Empty = complete. */
export function profileGaps(c: ProfileCounts): ('photos' | 'interests')[] {
  const gaps: ('photos' | 'interests')[] = [];
  if (c.photos < 1) gaps.push('photos');
  if (c.interests < MIN_INTERESTS) gaps.push('interests');
  return gaps;
}

/**
 * The caller's own view of their profile and verification state. Never includes email or auth ids,
 * and the primary photo is signed for the caller only.
 */
export async function loadMe(ctx: Ctx, user: CurrentUser) {
  const [row, counts, interests, primary] = await Promise.all([
    getProfileRow(ctx.pool, user.id),
    profileCounts(ctx.pool, user.id),
    interestsFor(ctx.pool, [user.id]),
    ctx.photos.primaryFor([user.id]),
  ]);
  if (!row) return null;
  const missing = eligibilityGaps(user);
  const profileMissing = profileGaps(counts);
  return {
    id: user.id,
    nickname: row.nickname,
    bio: row.bio,
    discoverable: row.discoverable,
    updatedAt: row.updated_at,
    interests: interests.get(user.id) ?? [],
    photo: primary.get(user.id) ?? null,
    photoCount: counts.photos,
    campus: { id: user.campusId, name: user.campusName },
    profile: { complete: profileMissing.length === 0, missing: profileMissing },
    account: {
      status: user.status,
      ageStatus: user.ageStatus,
      campusStatus: user.campusStatus,
      eligible: missing.length === 0,
      missing,
    },
  };
}

export async function updateProfile(db: Db, userId: string, patch: UpdateProfileInput): Promise<void> {
  const sets: string[] = [];
  const values: unknown[] = [];
  const set = (column: string, value: unknown) => {
    values.push(value);
    sets.push(`${column} = $${values.length}`);
  };
  if (patch.nickname !== undefined) {
    set('nickname', patch.nickname);
    set('nickname_key', patch.nickname.toLowerCase());
  }
  if (patch.bio !== undefined) set('bio', patch.bio);
  if (patch.discoverable !== undefined) set('discoverable', patch.discoverable);
  sets.push('updated_at = now()');
  values.push(userId);
  try {
    await db.query(`UPDATE profiles SET ${sets.join(', ')} WHERE user_id = $${values.length}`, values);
  } catch (err) {
    if (pgErrorCode(err) === '23505' && pgConstraint(err) === 'profiles_nickname_key_key') {
      throw conflict('NICKNAME_TAKEN', 'That nickname is already taken');
    }
    throw err;
  }
}
