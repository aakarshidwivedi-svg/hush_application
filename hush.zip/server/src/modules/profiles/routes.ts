import { Router } from 'express';
import type { Ctx } from '../../context.js';
import { asyncHandler, notFound } from '../../http/errors.js';
import { ok, okPage } from '../../http/respond.js';
import { z } from 'zod';
import { discover, discoverQuerySchema, resetSkips, skipProfile } from './discover.js';
import { updateProfileSchema } from './schemas.js';
import { loadMe, updateProfile } from './service.js';

export function profilesRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw } = ctx;

  r.get(
    '/discover',
    mw.authenticate,
    mw.loadUser,
    mw.requireEligible,
    mw.requireCompleteProfile,
    asyncHandler(async (req, res) => {
      const { limit, cursor } = discoverQuerySchema.parse(req.query);
      const { cards, nextCursor } = await discover(ctx.pool, ctx.photos, req.user!, limit, cursor);
      okPage(res, cards, { nextCursor });
    }),
  );

  const skipParams = z.object({ userId: z.string().uuid() });

  // "Not now": a private note to self. Nobody else can ever see it, and it says nothing about interest.
  r.post(
    '/discover/skips/:userId',
    mw.authenticate,
    mw.loadUser,
    mw.requireEligible,
    ctx.limit.crush,
    asyncHandler(async (req, res) => {
      const { userId } = skipParams.parse(req.params);
      await skipProfile(ctx.pool, req.user!.id, userId);
      ok(res, { status: 'skipped' });
    }),
  );

  r.delete(
    '/discover/skips',
    mw.authenticate,
    mw.loadUser,
    mw.requireEligible,
    ctx.limit.crush,
    asyncHandler(async (req, res) => {
      await resetSkips(ctx.pool, req.user!.id);
      ok(res, { status: 'reset' });
    }),
  );

  r.get(
    '/me',
    mw.authenticate,
    mw.loadUser,
    asyncHandler(async (req, res) => {
      const me = await loadMe(ctx, req.user!);
      if (!me) throw notFound('Profile not found');
      ok(res, me);
    }),
  );

  r.patch(
    '/me',
    mw.authenticate,
    mw.loadUser,
    mw.requireActive,
    asyncHandler(async (req, res) => {
      const user = req.user!; // identity comes from the verified token, never from the body
      const patch = updateProfileSchema.parse(req.body);
      await updateProfile(ctx.pool, user.id, patch);
      ok(res, await loadMe(ctx, user));
    }),
  );

  return r;
}
