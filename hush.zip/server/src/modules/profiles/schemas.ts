import { z } from 'zod';
import { text } from '../../lib/sanitize.js';

const RESERVED = new Set(['admin', 'administrator', 'moderator', 'mod', 'hush', 'hushteam', 'support', 'staff', 'system', 'anonymous']);

export const nicknameSchema = z
  .string()
  .trim()
  .regex(/^[A-Za-z0-9_.]{3,24}$/, 'Use 3–24 characters: letters, numbers, "_" or "."')
  .refine((n) => !RESERVED.has(n.toLowerCase()), 'That nickname is reserved');

export const bioSchema = text(0, 280, true);

/**
 * Step 2 of onboarding creates the account record. Photos and interests are added afterwards through
 * their own endpoints, and the profile only reaches Discover once both are in place.
 */
export const completeProfileSchema = z
  .object({
    campusId: z.string().uuid(),
    nickname: nicknameSchema,
    bio: bioSchema.default(''),
    discoverable: z.boolean().default(true),
    /** Optional personal invite code from a friend's link. Unknown or malformed codes are ignored, never an error. */
    inviteCode: z
      .unknown()
      .optional()
      .transform((v) => (typeof v === 'string' && v.length <= 64 ? v : undefined)),
    ageAttestation: z.literal(true, { errorMap: () => ({ message: 'You must confirm that you are 18 or older' }) }),
  })
  .strict();

/** PATCH body: only these fields are editable. Anything else (status, campusId, ...) is rejected. */
export const updateProfileSchema = z
  .object({
    nickname: nicknameSchema,
    bio: bioSchema,
    discoverable: z.boolean(),
  })
  .partial()
  .strict()
  .refine((o) => Object.keys(o).length > 0, 'Provide at least one field to update');

export type CompleteProfileInput = z.infer<typeof completeProfileSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
