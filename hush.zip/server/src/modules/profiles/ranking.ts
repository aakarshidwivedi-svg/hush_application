/**
 * Discovery ranking: pure functions, no database, no randomness, so every rule can be unit-tested.
 *
 * What the score may depend on (and nothing else):
 *   - the interests the viewer chose,
 *   - the interests the candidate chose to show on their profile,
 *   - which of those the two of them share.
 * It never looks at who has crushed on whom, who has viewed whom, or how popular anyone is, so a score can
 * never leak a secret crush.
 *
 * score = shared interests × 100 + shared categories × 20 + overlap (Jaccard) × 50   (integer, 0..~1170)
 * Shared interests dominate; sharing across more categories (music AND food) is a bonus; overlap as a share
 * of everything either person picked keeps a huge, scattered profile from outranking a close fit.
 */

export const WEIGHTS = { sharedInterest: 100, sharedCategory: 20, overlap: 50 } as const;

export interface ScoreInput {
  /** How many interests the viewer has. */
  viewerCount: number;
  /** How many interests the candidate has. */
  candidateCount: number;
  /** How many of them both have. */
  sharedCount: number;
  /** How many distinct categories those shared interests fall in. */
  sharedCategories: number;
}

export function scoreCandidate(i: ScoreInput): number {
  if (i.sharedCount <= 0) return 0;
  const union = i.viewerCount + i.candidateCount - i.sharedCount;
  const jaccard = union > 0 ? i.sharedCount / union : 0;
  return i.sharedCount * WEIGHTS.sharedInterest + i.sharedCategories * WEIGHTS.sharedCategory + Math.round(jaccard * WEIGHTS.overlap);
}

/** A ranked candidate: higher score first, then a stable per-viewer pseudo-random key, then id. */
export interface RankKey {
  /** The viewer already sent this person a crush (the viewer's own data): these go after everyone new. */
  crushed: boolean;
  score: number;
  /** md5(viewerId + candidateId): stable for one viewer, different across viewers, unrelated to popularity. */
  tie: string;
  id: string;
}

export function compareRank(a: RankKey, b: RankKey): number {
  if (a.crushed !== b.crushed) return a.crushed ? 1 : -1;
  if (a.score !== b.score) return b.score - a.score;
  if (a.tie !== b.tie) return a.tie < b.tie ? -1 : 1;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

// ---- Opaque keyset cursor: "<crushed 0|1>_<score>_<tie>_<id>" ---------------------------------------

export const CURSOR_RE = /^[01]_\d{1,6}_[0-9a-f]{32}_[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

export const encodeCursor = (k: RankKey): string => `${k.crushed ? 1 : 0}_${k.score}_${k.tie}_${k.id}`;

export function decodeCursor(cursor: string): RankKey | null {
  if (!CURSOR_RE.test(cursor)) return null;
  const [c, score, tie, id] = cursor.split('_') as [string, string, string, string];
  return { crushed: c === '1', score: Number(score), tie, id };
}

/**
 * One page of an already-sorted list, strictly after `cursor`. Keyset (not offset) paging, so a person who
 * is skipped, blocked or matched between requests never shifts the rest of the list.
 */
export function pageAfter<T extends RankKey>(sorted: T[], cursor: RankKey | null, limit: number): { items: T[]; next: string | null } {
  const start = cursor ? sorted.findIndex((x) => compareRank(x, cursor) > 0) : 0;
  const rest = start < 0 ? [] : sorted.slice(start);
  const items = rest.slice(0, limit);
  const last = items[items.length - 1];
  return { items, next: rest.length > limit && last ? encodeCursor(last) : null };
}

/**
 * "You share an interest in Movies and Coffee." Only interests both people chose to show are named; at most
 * three, then a count. Returns null when nothing is shared (the card then shows no explanation at all).
 */
export function explainShared(sharedNames: string[]): string | null {
  const names = sharedNames.filter((n) => n.trim().length > 0);
  if (names.length === 0) return null;
  const shown = names.slice(0, 3);
  const more = names.length - shown.length;
  const list =
    shown.length === 1
      ? shown[0]!
      : `${shown.slice(0, -1).join(', ')} and ${shown[shown.length - 1]}`;
  if (more > 0) return `You share interests in ${shown.join(', ')} and ${more} more.`;
  return shown.length === 1 ? `You share an interest in ${list}.` : `You share interests in ${list}.`;
}
