import { z } from 'zod';
import type { Db } from '../../db/pool.js';
import type { CurrentUser } from '../shared/eligibility.js';
import { completeProfileSql, eligibleUserSql } from '../shared/eligibility.js';
import { interestsFor, type InterestRef } from '../interests/service.js';
import { CURSOR_RE, compareRank, decodeCursor, explainShared, pageAfter, scoreCandidate } from './ranking.js';
import type { PhotoRef, PhotoService } from '../photos/service.js';

export const discoverQuerySchema = z.object({
  limit: z.coerce.number().int().min(1).max(50).default(20),
  cursor: z.string().regex(CURSOR_RE, 'Invalid cursor').optional(),
});

/** Upper bound on candidates ranked per request (one campus; far above realistic size, keeps a request bounded). */
const MAX_CANDIDATES = 5000;

export interface DiscoverCard {
  id: string;
  nickname: string;
  bio: string;
  interests: InterestRef[];
  /** Primary photo (short-lived signed URLs), or null. */
  photo: PhotoRef | null;
  /** Whether the *caller* already sent this person a crush. Only the caller's own data. */
  crushed: boolean;
  /** Interests both people chose to show. Derived only from the two public interest lists. */
  sharedInterestIds: string[];
  /** Plain-language explanation of the ranking ("You share interests in Movies and Coffee."), or null. */
  reason: string | null;
}

interface Row {
  id: string;
  nickname: string;
  bio: string;
  crushed: boolean;
  tie: string;
  candidate_count: number;
  shared_count: number;
  shared_categories: number;
}

/**
 * Discovery feed. Public fields only, same campus, eligible + active + discoverable, minus anyone
 * blocked in either direction, already matched with the caller, or skipped by the caller.
 *
 * Ranking is explainable and interest-based (see ranking.ts). Privacy: nothing here depends on who has
 * crushed on the caller. The only crush-related input is the caller's OWN crushes (sent ones sort last).
 */
export async function discover(
  db: Db,
  photos: PhotoService,
  viewer: CurrentUser,
  limit: number,
  cursor: string | undefined,
): Promise<{ cards: DiscoverCard[]; nextCursor: string | null }> {
  const after = cursor ? decodeCursor(cursor) : null;
  const mine = (await interestsFor(db, [viewer.id])).get(viewer.id) ?? [];
  const mineIds = mine.map((i) => i.id);

  const { rows } = await db.query<Row>(
    `SELECT u.id, p.nickname, p.bio,
            EXISTS (SELECT 1 FROM crushes cr WHERE cr.sender_id = $1 AND cr.receiver_id = u.id) AS crushed,
            md5($1::text || u.id::text) AS tie,
            x.total AS candidate_count, x.shared AS shared_count, x.shared_categories
       FROM users u
       JOIN profiles p ON p.user_id = u.id
       JOIN campuses c ON c.id = u.campus_id
       CROSS JOIN LATERAL (
         SELECT count(*)::int AS total,
                (count(*) FILTER (WHERE ui.interest_id = ANY($3::text[])))::int AS shared,
                (count(DISTINCT i.category) FILTER (WHERE ui.interest_id = ANY($3::text[])))::int AS shared_categories
           FROM user_interests ui JOIN interests i ON i.id = ui.interest_id AND i.is_active
          WHERE ui.user_id = u.id
       ) x
      WHERE u.id <> $1
        AND u.campus_id = $2
        AND p.discoverable
        AND ${eligibleUserSql('u', 'c')}
        AND ${completeProfileSql('u')}
        AND NOT EXISTS (SELECT 1 FROM blocks b
                         WHERE (b.blocker_id = $1 AND b.blocked_id = u.id)
                            OR (b.blocker_id = u.id AND b.blocked_id = $1))
        AND NOT EXISTS (SELECT 1 FROM matches m
                         WHERE m.user_a = LEAST($1::uuid, u.id) AND m.user_b = GREATEST($1::uuid, u.id))
        AND NOT EXISTS (SELECT 1 FROM discovery_skips s WHERE s.user_id = $1 AND s.target_id = u.id)
      LIMIT $4`,
    [viewer.id, viewer.campusId, mineIds, MAX_CANDIDATES],
  );

  const ranked = rows
    .map((r) => ({
      row: r,
      id: r.id,
      crushed: r.crushed,
      tie: r.tie,
      score: scoreCandidate({
        viewerCount: mineIds.length,
        candidateCount: r.candidate_count,
        sharedCount: r.shared_count,
        sharedCategories: r.shared_categories,
      }),
    }))
    .sort(compareRank);

  const { items, next } = pageAfter(ranked, after, limit);

  // Everyone on this page has just passed the visibility query above, so their photos may be signed for the viewer.
  const ids = items.map((r) => r.id);
  const [interests, primary] = await Promise.all([interestsFor(db, ids), photos.primaryFor(ids, db)]);
  const mineSet = new Set(mineIds);
  return {
    cards: items.map(({ row: r }) => {
      const theirs = interests.get(r.id) ?? [];
      const shared = theirs.filter((i) => mineSet.has(i.id));
      return {
        id: r.id,
        nickname: r.nickname,
        bio: r.bio,
        interests: theirs,
        photo: primary.get(r.id) ?? null,
        crushed: r.crushed,
        sharedInterestIds: shared.map((i) => i.id),
        reason: explainShared(shared.map((i) => i.name)),
      };
    }),
    nextCursor: next,
  };
}

/** Remember that the caller does not want to see this person again (private; never visible to the other person). */
export async function skipProfile(db: Db, viewerId: string, targetId: string): Promise<void> {
  if (viewerId === targetId) return;
  // An unknown id violates the foreign key; that is treated exactly like success so the endpoint can't be used to probe ids.
  await db
    .query('INSERT INTO discovery_skips (user_id, target_id) SELECT $1, id FROM users WHERE id = $2 ON CONFLICT DO NOTHING', [viewerId, targetId])
    .catch(() => undefined);
}

/** Bring everyone the caller skipped back into their feed. */
export async function resetSkips(db: Db, viewerId: string): Promise<void> {
  await db.query('DELETE FROM discovery_skips WHERE user_id = $1', [viewerId]);
}
