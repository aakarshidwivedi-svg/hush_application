import { z } from 'zod';
import type { Db } from '../../db/pool.js';
import { notFound } from '../../http/errors.js';

export const listQuerySchema = z.object({
  /** `unread` (default) is what the badge and the celebration use; `all` also returns read items. */
  filter: z.enum(['unread', 'all']).default('unread'),
  limit: z.coerce.number().int().min(1).max(50).default(30),
});

export const markReadSchema = z
  .object({
    ids: z.array(z.string().uuid()).min(1).max(100).optional(),
    type: z.enum(['MATCH', 'MESSAGE']).optional(),
  })
  .strict();

export interface NotificationView {
  id: string;
  type: 'MATCH' | 'MESSAGE';
  matchId: string;
  createdAt: Date;
  read: boolean;
  /** For MESSAGE: how many new messages this one notification stands for. */
  count: number;
  /** The other person, as they appear in the shared conversation. Nothing else about them. */
  partner: { nickname: string };
}

/**
 * A notification is shown only while the viewer may still see the conversation it points to: the match
 * is ACTIVE, the other person's account is ACTIVE, and neither person has blocked the other. The same rule
 * as `findActiveMatch`, so an ended or blocked conversation never leaves a trace in the inbox.
 */
const VISIBLE = `
  FROM notifications n
  JOIN matches m ON m.id = n.match_id AND m.status = 'ACTIVE'
  JOIN users up ON up.id = CASE WHEN m.user_a = n.user_id THEN m.user_b ELSE m.user_a END AND up.account_status = 'ACTIVE'
  JOIN profiles p ON p.user_id = up.id
 WHERE n.user_id = $1
   AND NOT EXISTS (SELECT 1 FROM blocks b
                    WHERE (b.blocker_id = n.user_id AND b.blocked_id = up.id)
                       OR (b.blocker_id = up.id AND b.blocked_id = n.user_id))`;

export async function listNotifications(db: Db, userId: string, q: { filter: 'unread' | 'all'; limit: number }) {
  const [rows, unread] = await Promise.all([
    db.query(
      `SELECT n.id, n.type, n.match_id, n.created_at, n.read_at, n.event_count, p.nickname ${VISIBLE}
          ${q.filter === 'unread' ? 'AND n.read_at IS NULL' : ''}
        ORDER BY n.created_at DESC, n.id DESC LIMIT $2`,
      [userId, q.limit],
    ),
    db.query<{ n: number }>(`SELECT count(*)::int AS n ${VISIBLE} AND n.read_at IS NULL`, [userId]),
  ]);
  const items: NotificationView[] = rows.rows.map((r) => ({
    id: r.id,
    type: r.type,
    matchId: r.match_id,
    createdAt: r.created_at,
    read: r.read_at !== null,
    count: r.event_count,
    partner: { nickname: r.nickname },
  }));
  return { items, unreadCount: unread.rows[0]!.n };
}

/** Mark the caller's own unread notifications read (all of them, one type, or specific ids). Idempotent. */
export async function markNotificationsRead(db: Db, userId: string, sel: { ids?: string[] | undefined; type?: string | undefined }): Promise<number> {
  const r = await db.query(
    `UPDATE notifications SET read_at = now()
      WHERE user_id = $1 AND read_at IS NULL
        AND ($2::uuid[] IS NULL OR id = ANY($2::uuid[]))
        AND ($3::text IS NULL OR type = $3::text)`,
    [userId, sel.ids ?? null, sel.type ?? null],
  );
  return r.rowCount ?? 0;
}

/** One notification, owner only: somebody else's id looks exactly like one that does not exist. */
export async function markOneRead(db: Db, userId: string, id: string): Promise<void> {
  const r = await db.query('UPDATE notifications SET read_at = COALESCE(read_at, now()) WHERE id = $1 AND user_id = $2', [id, userId]);
  if (r.rowCount === 0) throw notFound('Notification not found');
}
