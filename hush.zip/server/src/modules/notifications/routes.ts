import { Router } from 'express';
import { z } from 'zod';
import type { Ctx } from '../../context.js';
import { asyncHandler } from '../../http/errors.js';
import { ok, okPage } from '../../http/respond.js';
import { listNotifications, listQuerySchema, markNotificationsRead, markOneRead, markReadSchema } from './service.js';

const idParam = z.object({ id: z.string().uuid() });

/**
 * In-app inbox: new matches and new messages. A row is written in the same transaction as the event it
 * announces, so a notification can never describe something that did not commit, and a retried
 * request cannot create a second one (see the unique indexes in migration 0006). Nothing here ever
 * mentions a one-sided crush: only committed, mutual matches and real messages have notifications.
 */
export function notificationsRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw, pool } = ctx;
  const guard = [mw.authenticate, mw.loadUser, mw.requireEligible];

  r.get(
    '/',
    ...guard,
    asyncHandler(async (req, res) => {
      const { items, unreadCount } = await listNotifications(pool, req.user!.id, listQuerySchema.parse(req.query));
      // `total` is the caller's unread count, for the badge.
      okPage(res, items, { nextCursor: null, total: unreadCount });
    }),
  );

  r.post(
    '/read',
    ...guard,
    asyncHandler(async (req, res) => {
      const sel = markReadSchema.parse(req.body ?? {});
      const marked = await markNotificationsRead(pool, req.user!.id, sel);
      ctx.hub.emitToUser(req.user!.id, 'notifications:changed'); // keep the user's other tabs in step
      ok(res, { marked });
    }),
  );

  r.post(
    '/:id/read',
    ...guard,
    asyncHandler(async (req, res) => {
      const { id } = idParam.parse(req.params);
      await markOneRead(pool, req.user!.id, id);
      ctx.hub.emitToUser(req.user!.id, 'notifications:changed');
      ok(res, { status: 'read' });
    }),
  );

  return r;
}
