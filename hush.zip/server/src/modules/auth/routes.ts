import { Router } from 'express';
import type { Ctx } from '../../context.js';
import { pgConstraint, pgErrorCode, withTx } from '../../db/pool.js';
import { asyncHandler, conflict, forbidden, validation } from '../../http/errors.js';
import { ok } from '../../http/respond.js';
import { fetchCurrentUser } from '../../middleware/user.js';
import { completeProfileSchema } from '../profiles/schemas.js';
import { loadMe } from '../profiles/service.js';
import { recordReferral } from '../invites/service.js';
import { emailMatchesCampus, type CampusConfig } from '../shared/eligibility.js';

export function authRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw, pool } = ctx;

  /** Public list of campuses so the sign-up form can offer a choice. */
  r.get(
    '/campuses',
    asyncHandler(async (_req, res) => {
      const { rows } = await pool.query<{ id: string; name: string; verification_config: CampusConfig | null }>(
        'SELECT id, name, verification_config FROM campuses WHERE is_active ORDER BY name',
      );
      ok(
        res,
        rows.map((c) => ({ id: c.id, name: c.name, emailDomains: c.verification_config?.emailDomains ?? [] })),
      );
    }),
  );

  /**
   * Onboarding. Campus status is derived on the server from the *verified* email claim in the
   * token and the campus configuration — never from client input. Age is self-attested here;
   * campuses that set `requireVerifiedAge` keep the account ineligible until a moderator
   * upgrades it to VERIFIED. A college email alone is not treated as proof of age.
   */
  r.post(
    '/auth/complete-profile',
    mw.authenticate,
    ctx.limit.auth,
    asyncHandler(async (req, res) => {
      const auth = req.auth!;
      const input = completeProfileSchema.parse(req.body);

      const { rows } = await pool.query<{ verification_config: CampusConfig | null }>(
        'SELECT verification_config FROM campuses WHERE id = $1 AND is_active',
        [input.campusId],
      );
      const campus = rows[0];
      if (!campus) throw validation('Unknown or inactive campus');
      if (!auth.email || !auth.emailVerified) throw forbidden('EMAIL_NOT_VERIFIED', 'Please verify your email address first');
      // Any verified email (e.g. a personal Google account) may create an account, but only an
      // address issued by the chosen campus makes the account campus-VERIFIED. Everyone else stays
      // UNVERIFIED: hidden from Discover and unable to send crushes until a moderator verifies the
      // campus (see `eligibilityGaps`). The status is derived here, never taken from the client.
      const campusStatus = emailMatchesCampus(auth.email, campus.verification_config ?? {}) ? 'VERIFIED' : 'UNVERIFIED';

      try {
        await withTx(pool, async (c) => {
          const u = await c.query<{ id: string }>(
            `INSERT INTO users (auth_subject, campus_id, age_status, campus_status)
             VALUES ($1, $2, 'SELF_ATTESTED', $3) RETURNING id`,
            [auth.sub, input.campusId, campusStatus],
          );
          await c.query(
            `INSERT INTO profiles (user_id, nickname, nickname_key, bio, discoverable)
             VALUES ($1, $2, $3, $4, $5)`,
            [u.rows[0]!.id, input.nickname, input.nickname.toLowerCase(), input.bio, input.discoverable],
          );
          await recordReferral(c, u.rows[0]!.id, input.inviteCode);
        });
      } catch (err) {
        if (pgErrorCode(err) === '23505') {
          const constraint = pgConstraint(err);
          if (constraint === 'users_auth_subject_key') throw conflict('ALREADY_ONBOARDED', 'Your profile is already set up');
          if (constraint === 'profiles_nickname_key_key') throw conflict('NICKNAME_TAKEN', 'That nickname is already taken');
        }
        throw err;
      }

      const user = (await fetchCurrentUser(pool, auth.sub))!;
      ok(res, await loadMe(ctx, user), 201);
    }),
  );

  return r;
}
