import { Router } from 'express';
import { z } from 'zod';
import type { Ctx } from '../../context.js';
import { asyncHandler, notFound } from '../../http/errors.js';
import { ok } from '../../http/respond.js';
import { publishMatchesChanged } from '../../realtime/publish.js';
import { findActiveMatch, listMatches, unmatch, withPartnerProfiles } from './service.js';

export const matchParams = z.object({ matchId: z.string().uuid() });

export function matchesRouter(ctx: Ctx): Router {
  const r = Router();
  const { mw } = ctx;
  const guard = [mw.authenticate, mw.loadUser, mw.requireEligible];

  r.get(
    '/',
    ...guard,
    asyncHandler(async (req, res) => {
      ok(res, await withPartnerProfiles(ctx.pool, ctx.photos, await listMatches(ctx.pool, req.user!.id)));
    }),
  );

  r.get(
    '/:matchId',
    ...guard,
    asyncHandler(async (req, res) => {
      const { matchId } = matchParams.parse(req.params);
      const match = await findActiveMatch(ctx.pool, matchId, req.user!.id);
      if (!match) throw notFound('Match not found'); // same answer for "not yours", "unmatched" and "never existed"
      ok(res, (await withPartnerProfiles(ctx.pool, ctx.photos, [match]))[0]);
    }),
  );

  r.post(
    '/:matchId/unmatch',
    mw.authenticate,
    ctx.limit.safety,
    mw.loadUser,
    mw.requireEligible,
    asyncHandler(async (req, res) => {
      const { matchId } = matchParams.parse(req.params);
      const partnerId = await unmatch(ctx.pool, req.user!.id, matchId);
      publishMatchesChanged(ctx.hub, [req.user!.id, partnerId]);
      ok(res, { status: 'unmatched' });
    }),
  );

  return r;
}
