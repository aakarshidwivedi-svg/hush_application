import type { Pool } from 'pg';
import { withTx, type Db } from '../../db/pool.js';
import { notFound } from '../../http/errors.js';
import { interestsFor, type InterestRef } from '../interests/service.js';
import type { PhotoRef, PhotoService } from '../photos/service.js';
import { lockPair } from '../shared/pairLock.js';

export interface PartnerCard {
  id: string;
  nickname: string;
  bio: string;
}

export interface MatchView {
  id: string;
  createdAt: Date;
  partner: PartnerCard;
  lastMessage: { preview: string; createdAt: Date; mine: boolean } | null;
  /** Messages from the other person that this caller has not opened yet. */
  unreadCount: number;
}

/** A match as the API returns it: the partner's approved public profile, including photo and interests. */
export interface MatchResponse extends Omit<MatchView, 'partner'> {
  partner: PartnerCard & { interests: InterestRef[]; photo: PhotoRef | null };
}

interface MatchRow {
  id: string;
  created_at: Date;
  partner_id: string;
  nickname: string;
  bio: string;
  last_content: string | null;
  last_at: Date | null;
  last_mine: boolean | null;
  unread_count: number;
}

/**
 * The single definition of "this user may see this match":
 *  - the caller is a participant,
 *  - the match is ACTIVE (unmatched conversations vanish),
 *  - the other person's account is ACTIVE (not suspended/deleted),
 *  - neither person has blocked the other.
 * Every match, message and unmatch request goes through it, so authorisation is re-checked
 * on each call and cannot be bypassed by guessing ids.
 */
const VISIBLE_MATCH_SQL = `
  FROM matches m
  JOIN users up ON up.id = CASE WHEN m.user_a = $1 THEN m.user_b ELSE m.user_a END
  JOIN profiles p ON p.user_id = up.id
  LEFT JOIN LATERAL (
    SELECT content, created_at, sender_id FROM messages
     WHERE match_id = m.id ORDER BY created_at DESC, id DESC LIMIT 1
  ) lm ON true
 WHERE m.status = 'ACTIVE'
   AND (m.user_a = $1 OR m.user_b = $1)
   AND up.account_status = 'ACTIVE'
   AND NOT EXISTS (SELECT 1 FROM blocks b
                    WHERE (b.blocker_id = $1 AND b.blocked_id = up.id)
                       OR (b.blocker_id = up.id AND b.blocked_id = $1))`;

const SELECT_COLUMNS = `
  SELECT m.id, m.created_at, up.id AS partner_id, p.nickname, p.bio,
         lm.content AS last_content, lm.created_at AS last_at, (lm.sender_id = $1) AS last_mine,
         (SELECT count(*)::int FROM messages um
           WHERE um.match_id = m.id AND um.sender_id <> $1
             AND um.created_at > COALESCE((SELECT r.last_read_at FROM message_reads r WHERE r.match_id = m.id AND r.user_id = $1), '-infinity'::timestamptz)) AS unread_count`;

function toView(r: MatchRow): MatchView {
  return {
    id: r.id,
    createdAt: r.created_at,
    partner: { id: r.partner_id, nickname: r.nickname, bio: r.bio },
    lastMessage:
      r.last_content !== null && r.last_at !== null
        ? { preview: Array.from(r.last_content).slice(0, 80).join(''), createdAt: r.last_at, mine: r.last_mine === true }
        : null,
    unreadCount: r.unread_count,
  };
}

export async function listMatches(db: Db, userId: string): Promise<MatchView[]> {
  const { rows } = await db.query<MatchRow>(
    `${SELECT_COLUMNS} ${VISIBLE_MATCH_SQL} ORDER BY COALESCE(lm.created_at, m.created_at) DESC LIMIT 100`,
    [userId],
  );
  return rows.map(toView);
}

/** Returns the match only if `userId` may currently see it; otherwise null (callers answer 404). */
export async function findActiveMatch(db: Db, matchId: string, userId: string): Promise<MatchView | null> {
  const { rows } = await db.query<MatchRow>(`${SELECT_COLUMNS} ${VISIBLE_MATCH_SQL} AND m.id = $2`, [userId, matchId]);
  return rows[0] ? toView(rows[0]) : null;
}

export async function unmatch(pool: Pool, userId: string, matchId: string): Promise<string> {
  const match = await findActiveMatch(pool, matchId, userId);
  if (!match) throw notFound('Match not found');
  await withTx(pool, async (c) => {
    await lockPair(c, userId, match.partner.id);
    const r = await c.query(
      `UPDATE matches SET status = 'UNMATCHED', unmatched_at = now(), unmatched_by = $2
        WHERE id = $1 AND status = 'ACTIVE'`,
      [matchId, userId],
    );
    if (r.rowCount === 0) throw notFound('Match not found');
  });
  return match.partner.id;
}

/**
 * Add each partner's interests and primary photo. Only ever called on views that came out of
 * `listMatches` / `findActiveMatch`, i.e. people the caller is currently allowed to see.
 */
export async function withPartnerProfiles(db: Db, photos: PhotoService, matches: MatchView[]): Promise<MatchResponse[]> {
  const ids = matches.map((m) => m.partner.id);
  const [interests, primary] = await Promise.all([interestsFor(db, ids), photos.primaryFor(ids, db)]);
  return matches.map((m) => ({
    ...m,
    partner: { ...m.partner, interests: interests.get(m.partner.id) ?? [], photo: primary.get(m.partner.id) ?? null },
  }));
}

/** Everyone the user currently has an ACTIVE match with (used to tell them a conversation changed). */
export async function activePartnerIds(db: Db, userId: string): Promise<string[]> {
  const { rows } = await db.query<{ id: string }>(
    `SELECT CASE WHEN user_a = $1 THEN user_b ELSE user_a END AS id
       FROM matches WHERE status = 'ACTIVE' AND (user_a = $1 OR user_b = $1)`,
    [userId],
  );
  return rows.map((r) => r.id);
}
