import type { CurrentUser } from '../modules/shared/eligibility.js';

export interface AuthContext {
  /** Supabase user id (`sub`) from a server-verified token. Never exposed to other users. */
  sub: string;
  email: string | undefined;
  emailVerified: boolean;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AuthContext;
      user?: CurrentUser;
    }
  }
}
