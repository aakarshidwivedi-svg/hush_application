import type { RequestHandler } from 'express';
import type { Pool } from 'pg';
import type { Db } from '../db/pool.js';
import type { Config } from '../config/env.js';
import { AppError, asyncHandler } from '../http/errors.js';
import { profileCounts, profileGaps } from '../modules/profiles/service.js';
import { eligibilityGaps, type CampusConfig, type CurrentUser } from '../modules/shared/eligibility.js';

interface UserRow {
  id: string;
  auth_subject: string;
  campus_id: string;
  campus_name: string;
  campus_active: boolean;
  verification_config: CampusConfig | null;
  age_status: CurrentUser['ageStatus'];
  campus_status: CurrentUser['campusStatus'];
  account_status: CurrentUser['status'];
}

/** Fetch an account (joined with its campus) by verified auth subject. */
export async function fetchCurrentUser(db: Db, authSubject: string): Promise<CurrentUser | null> {
  const { rows } = await db.query<UserRow>(
    `SELECT u.id, u.auth_subject, u.campus_id, c.name AS campus_name, c.is_active AS campus_active,
            c.verification_config, u.age_status, u.campus_status, u.account_status
       FROM users u JOIN campuses c ON c.id = u.campus_id
      WHERE u.auth_subject = $1`,
    [authSubject],
  );
  const r = rows[0];
  if (!r) return null;
  return {
    id: r.id,
    authSubject: r.auth_subject,
    campusId: r.campus_id,
    campusName: r.campus_name,
    campusActive: r.campus_active,
    campusConfig: r.verification_config ?? {},
    ageStatus: r.age_status,
    campusStatus: r.campus_status,
    status: r.account_status,
  };
}

/** Loads the caller's account from the DB using the verified auth subject (never a client-supplied id). */
export function loadUser(pool: Pool): RequestHandler {
  return asyncHandler(async (req, _res, next) => {
    if (!req.auth) throw new AppError(401, 'UNAUTHENTICATED', 'Authentication required');
    const user = await fetchCurrentUser(pool, req.auth.sub);
    if (!user) throw new AppError(403, 'ONBOARDING_REQUIRED', 'Complete your profile to continue');
    if (user.status === 'DELETED') throw new AppError(401, 'INVALID_TOKEN', 'Invalid or expired token');
    req.user = user;
    next();
  });
}

/** Account must not be suspended. */
export const requireActive: RequestHandler = (req, _res, next) => {
  if (!req.user) return next(new AppError(401, 'UNAUTHENTICATED', 'Authentication required'));
  if (req.user.status === 'SUSPENDED') return next(new AppError(403, 'ACCOUNT_SUSPENDED', 'This account is suspended'));
  next();
};

/** Account must be active AND have completed campus + age verification. */
export const requireEligible: RequestHandler = (req, _res, next) => {
  if (!req.user) return next(new AppError(401, 'UNAUTHENTICATED', 'Authentication required'));
  if (req.user.status === 'SUSPENDED') return next(new AppError(403, 'ACCOUNT_SUSPENDED', 'This account is suspended'));
  const gaps = eligibilityGaps(req.user);
  if (gaps.length > 0) {
    return next(new AppError(403, 'NOT_ELIGIBLE', 'Your account has not completed verification yet', { missing: gaps }));
  }
  next();
};

/** Moderators are configured server-side by auth subject; no client claim can grant this. */
export function requireModerator(config: Config): RequestHandler {
  return (req, _res, next) => {
    if (!req.auth) return next(new AppError(401, 'UNAUTHENTICATED', 'Authentication required'));
    if (!config.moderators.has(req.auth.sub)) {
      // 404 rather than 403 so the existence of moderation endpoints is not advertised.
      return next(new AppError(404, 'NOT_FOUND', 'Route not found'));
    }
    next();
  };
}

/** The caller's own profile needs a photo and enough interests before they can browse or send crushes. */
export function requireCompleteProfile(pool: Pool): RequestHandler {
  return asyncHandler(async (req, _res, next) => {
    if (!req.user) throw new AppError(401, 'UNAUTHENTICATED', 'Authentication required');
    const missing = profileGaps(await profileCounts(pool, req.user.id));
    if (missing.length > 0) throw new AppError(403, 'PROFILE_INCOMPLETE', 'Finish your profile to start discovering', { missing });
    next();
  });
}
