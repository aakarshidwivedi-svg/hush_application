import type { RequestHandler } from 'express';
import { createRemoteJWKSet, jwtVerify, type JWTVerifyResult } from 'jose';
import type { Config } from '../config/env.js';
import { AppError } from '../http/errors.js';

export type TokenVerifier = (token: string) => Promise<JWTVerifyResult>;

/**
 * Build the access-token verifier. Signatures, issuer, audience and expiry are all checked
 * on the server, and the accepted algorithms are pinned to prevent algorithm-confusion attacks:
 * HS256 only when a legacy shared secret is configured, otherwise asymmetric keys from the
 * Supabase JWKS endpoint.
 */
export function createTokenVerifier(auth: Config['auth']): TokenVerifier {
  const { issuer, audience } = auth;
  if (auth.hmacSecret) {
    const key = new TextEncoder().encode(auth.hmacSecret);
    return (token) => jwtVerify(token, key, { algorithms: ['HS256'], issuer, audience });
  }
  const jwks = createRemoteJWKSet(new URL(auth.jwksUrl));
  return (token) => jwtVerify(token, jwks, { algorithms: ['ES256', 'RS256'], issuer, audience });
}

const BEARER = /^Bearer ([A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)$/;

export interface Identity {
  sub: string;
  email: string | undefined;
  emailVerified: boolean;
  /** Token expiry (seconds since epoch); long-lived sockets use it to stop trusting an old token. */
  exp: number | undefined;
}

/** Verify a raw access token and return the identity it proves. Throws on any problem. */
export async function identify(verify: TokenVerifier, token: string): Promise<Identity> {
  const { payload } = await verify(token);
  if (typeof payload.sub !== 'string' || payload.sub === '' || payload.role !== 'authenticated') {
    throw new Error('unexpected claims');
  }
  const meta = payload.user_metadata as { email_verified?: unknown } | undefined;
  return {
    sub: payload.sub,
    email: typeof payload.email === 'string' ? payload.email.toLowerCase() : undefined,
    emailVerified: payload.email_verified === true || meta?.email_verified === true,
    exp: typeof payload.exp === 'number' ? payload.exp : undefined,
  };
}

/** Authenticates the caller and sets `req.auth`. Identity only ever comes from the verified token. */
export function authenticate(verify: TokenVerifier): RequestHandler {
  return async (req, _res, next) => {
    const match = BEARER.exec(req.headers.authorization ?? '');
    if (!match) return next(new AppError(401, 'UNAUTHENTICATED', 'Authentication required'));
    try {
      const id = await identify(verify, match[1]!);
      req.auth = { sub: id.sub, email: id.email, emailVerified: id.emailVerified };
      next();
    } catch {
      next(new AppError(401, 'INVALID_TOKEN', 'Invalid or expired token'));
    }
  };
}
