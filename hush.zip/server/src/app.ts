import cors from 'cors';
import express, { Router, type Express } from 'express';
import helmet from 'helmet';
import { pino, type Logger } from 'pino';
import { pinoHttp } from 'pino-http';
import type { Pool } from 'pg';
import type { Config } from './config/env.js';
import { createCtx } from './context.js';
import { errorHandler, notFoundHandler } from './http/errors.js';
import { limiter } from './middleware/rateLimit.js';
import type { TokenVerifier } from './middleware/auth.js';
import { accountRouter } from './modules/account/routes.js';
import { authRouter } from './modules/auth/routes.js';
import { blocksRouter } from './modules/blocks/routes.js';
import { interestsRouter } from './modules/interests/routes.js';
import { invitesRouter } from './modules/invites/routes.js';
import { photosRouter } from './modules/photos/routes.js';
import type { PhotoStorage } from './modules/photos/storage.js';
import { crushesRouter } from './modules/crushes/routes.js';
import { matchesRouter } from './modules/matches/routes.js';
import { messagesRouter } from './modules/messages/routes.js';
import { notificationsRouter } from './modules/notifications/routes.js';
import { profilesRouter } from './modules/profiles/routes.js';
import { reportsRouter } from './modules/reports/routes.js';

export interface AppDeps {
  pool: Pool;
  config: Config;
  logger?: Logger;
  /** Override token verification (tests). Production uses the Supabase-configured verifier. */
  verify?: TokenVerifier;
  /** Override image storage (tests). Production uses the driver chosen in the config. */
  storage?: PhotoStorage;
}

export function createApp({ pool, config, logger, verify, storage }: AppDeps): Express {
  const log =
    logger ??
    pino({
      level: config.env === 'test' ? 'silent' : config.logLevel,
      redact: ['req.headers.authorization', 'req.headers.cookie'],
    });
  const ctx = createCtx(pool, config, verify, storage);

  const app = express();
  app.set('ctx', ctx); // read by the real-time server (attachRealtime)
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);

  // Secure logging: method, path (no query string), status. Never bodies, tokens or message text.
  app.use(
    pinoHttp({
      logger: log,
      serializers: {
        req: (req: { method: string; url: string }) => ({ method: req.method, url: req.url.split('?')[0] }),
        res: (res: { statusCode: number }) => ({ statusCode: res.statusCode }),
      },
    }),
  );
  app.use(helmet());
  app.use(
    cors({
      origin: (origin, cb) => cb(null, !origin || config.corsOrigins.includes(origin)),
      methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE'],
      allowedHeaders: ['Authorization', 'Content-Type'],
      maxAge: 600,
    }),
  );
  app.use(express.json({ limit: '16kb' }));
  // Image links are unforgeable signed URLs and a single page of cards loads many of them, so they get their
  // own, higher budget instead of eating into the API's global limit.
  const isMedia = (req: { path: string }) => req.path.startsWith('/api/v1/media/');
  app.use(limiter(config.limits.global, 'global', isMedia));
  app.use(limiter({ windowMs: 60_000, max: config.limits.global.max * 6 }, 'media', (req) => !isMedia(req)));

  const api = Router();
  api.get('/health', (_req, res) => {
    res.json({ data: { status: 'ok' } });
  });
  api.use(authRouter(ctx)); // GET /campuses, POST /auth/complete-profile
  api.use(photosRouter(ctx)); // /profiles/me/photos*, /media/* (local driver)
  api.use(interestsRouter(ctx)); // GET /interests, PUT /profiles/me/interests
  api.use(invitesRouter(ctx)); // GET /invites/me
  api.use('/profiles', profilesRouter(ctx));
  api.use('/crushes', crushesRouter(ctx));
  api.use('/matches', matchesRouter(ctx));
  api.use('/matches', messagesRouter(ctx));
  api.use('/notifications', notificationsRouter(ctx));
  api.use(blocksRouter(ctx)); // POST/DELETE /users/:id/block, GET /blocks
  api.use(reportsRouter(ctx)); // POST /reports, /moderation/* (moderators only)
  api.use(accountRouter(ctx)); // DELETE /account
  app.use('/api/v1', api);

  app.use(notFoundHandler);
  app.use(errorHandler(log));
  return app;
}
