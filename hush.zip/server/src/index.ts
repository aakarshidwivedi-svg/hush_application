import { createApp } from './app.js';
import { loadConfig } from './config/env.js';
import { createPool } from './db/pool.js';
import { attachRealtime } from './realtime/socket.js';

const config = loadConfig();
const pool = createPool(config.databaseUrl, config.dbPoolMax);
const app = createApp({ pool, config });

const server = app.listen(config.port, () => {
  console.log(`Hush API listening on :${config.port} (${config.env})`);
});

const io = attachRealtime(server, app);

function shutdown(signal: string) {
  console.log(`${signal} received, shutting down`);
  // Closing Socket.IO also closes the HTTP server and drops live connections so shutdown is not held up.
  void io.close(() => {
    void pool.end().finally(() => process.exit(0));
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
