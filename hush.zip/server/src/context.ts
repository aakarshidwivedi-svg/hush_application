import type { RequestHandler } from 'express';
import type { Pool } from 'pg';
import type { Config } from './config/env.js';
import { authenticate, createTokenVerifier, type TokenVerifier } from './middleware/auth.js';
import { limiter } from './middleware/rateLimit.js';
import { loadUser, requireActive, requireCompleteProfile, requireEligible, requireModerator } from './middleware/user.js';
import { createHub, type Hub } from './realtime/hub.js';
import { createPhotoService, type PhotoService } from './modules/photos/service.js';
import { createStorage, type PhotoStorage } from './modules/photos/storage.js';

/** Shared dependencies handed to every module router. */
export interface Ctx {
  pool: Pool;
  config: Config;
  storage: PhotoStorage;
  photos: PhotoService;
  verify: TokenVerifier;
  hub: Hub;
  mw: {
    authenticate: RequestHandler;
    loadUser: RequestHandler;
    requireActive: RequestHandler;
    requireEligible: RequestHandler;
    requireCompleteProfile: RequestHandler;
    requireModerator: RequestHandler;
  };
  limit: {
    auth: RequestHandler;
    crush: RequestHandler;
    message: RequestHandler;
    report: RequestHandler;
    safety: RequestHandler;
    upload: RequestHandler;
  };
}

export function createCtx(
  pool: Pool,
  config: Config,
  verify: TokenVerifier = createTokenVerifier(config.auth),
  storage: PhotoStorage = createStorage(config.storage),
): Ctx {
  return {
    pool,
    config,
    storage,
    photos: createPhotoService(pool, storage),
    verify,
    hub: createHub(),
    mw: {
      authenticate: authenticate(verify),
      loadUser: loadUser(pool),
      requireActive,
      requireEligible,
      requireCompleteProfile: requireCompleteProfile(pool),
      requireModerator: requireModerator(config),
    },
    limit: {
      auth: limiter(config.limits.auth, 'auth'),
      crush: limiter(config.limits.crush, 'crush'),
      message: limiter(config.limits.message, 'message'),
      report: limiter(config.limits.report, 'report'),
      safety: limiter(config.limits.safety, 'safety'),
      upload: limiter(config.limits.upload, 'upload'),
    },
  };
}
